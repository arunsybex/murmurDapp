(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _component_home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./component/home/home.component */ "./src/app/component/home/home.component.ts");
/* harmony import */ var _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./component/aboutus/aboutus.component */ "./src/app/component/aboutus/aboutus.component.ts");
/* harmony import */ var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./component/navbar/navbar.component */ "./src/app/component/navbar/navbar.component.ts");







const routes = [
    {
        path: 'Home',
        component: _component_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"],
    },
    {
        path: 'About',
        component: _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_3__["AboutusComponent"]
    },
    {
        path: 'Navbar',
        component: _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__["NavbarComponent"]
    },
    { path: '', redirectTo: '/Home', pathMatch: 'full' }
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./component/navbar/navbar.component */ "./src/app/component/navbar/navbar.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




class AppComponent {
    constructor() {
        this.title = 'murmurDapp';
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 2, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-navbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
    } }, directives: [_component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__["NavbarComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]], styles: ["nav[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  .nav-heading[_ngcontent-%COMP%] {\n    width: 29.7px;\n    height: 19.3px;\n    color: #7000d3;\n    font-family: Poppins;\n  }\n  .HOME[_ngcontent-%COMP%] {\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration:none;\n  }\n  .ABOUT-US[_ngcontent-%COMP%] {\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration:none;\n  }\n  .CONTACT[_ngcontent-%COMP%] {\n    width: 97px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #fcc13c;\n    text-decoration:none;\n  }\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 46px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 580px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Download-App[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    background-color: #8069ff;\n    margin-right: 10%;\n  }\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    background-color: #fcc13c;\n  }\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .We-believe[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  .Use-Murmur[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  \n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  .sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #8069ff;\n    width: 78px;\n  }\n  .Path-9[_ngcontent-%COMP%] {\n    color: white;\n    font-size: 28px;\n    \n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkVBQUU7SUFDRSxjQUFjO0VBQ2hCO0VBQ0E7SUFDRSxjQUFjO0VBQ2hCO0VBRUE7SUFDRSxhQUFhO0lBQ2IsY0FBYztJQUNkLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsb0JBQW9CO0VBQ3RCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG9CQUFvQjtFQUN0QjtFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLGlCQUFpQjtFQUNuQjtFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCx5QkFBeUI7RUFDM0I7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztFQUNoQjtFQUVBO0lBQ0Usb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUVBOztLQUVHO0VBRUg7SUFDRSxvQ0FBNEI7WUFBNUIsNEJBQTRCO0lBQzVCLGdDQUF3QjtZQUF4Qix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixVQUFVO0lBQ1Y7aUJBQ2E7SUFDYixXQUFXO0lBQ1gsOEJBQXNCO1lBQXRCLHNCQUFzQjtJQUN0QiwyQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLFdBQVcsRUFBRSxZQUFZO0lBQ3pCLGdDQUFnQztFQUNsQztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7RUFkQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGO0VBQ0Y7RUFDRSwrQkFBdUI7VUFBdkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsdUJBQXVCO0VBQ3ZCLDhCQUFzQjtVQUF0QixzQkFBc0I7O0FBRXhCO0VBQ0U7O0lBRUUsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLEtBQUssV0FBVyxFQUFFLFlBQVksQ0FBQztFQUNqQztFQUpBOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBRUE7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0VBQ2I7RUFFQTtJQUNFLFlBQVk7SUFDWixlQUFlOztFQUVqQiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiICBuYXYgdWwgbGkgYTpob3ZlciB7XG4gICAgY29sb3I6ICMwMjIyNWI7XG4gIH1cbiAgbmF2IGE6aG92ZXIge1xuICAgIGNvbG9yOiAjMDIyMjViO1xuICB9XG5cbiAgLm5hdi1oZWFkaW5nIHtcbiAgICB3aWR0aDogMjkuN3B4O1xuICAgIGhlaWdodDogMTkuM3B4O1xuICAgIGNvbG9yOiAjNzAwMGQzO1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICB9XG5cbiAgLkhPTUUge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOm5vbmU7XG4gIH1cblxuICAuQUJPVVQtVVMge1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjpub25lO1xuICB9XG5cbiAgLkNPTlRBQ1Qge1xuICAgIHdpZHRoOiA5N3B4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmY2MxM2M7XG4gICAgdGV4dC1kZWNvcmF0aW9uOm5vbmU7XG4gIH1cblxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDZweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDU4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS45NDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMCU7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDE5NXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICB9XG5cbiAgLldoeS1NdXJtdXIge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLldlLWJlbGlldmUge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLk11cm11ci1pcy1hLXJld2FyZGluZyB7XG4gICAgd2lkdGg6IDMwNHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuQ3VycmVudC1QYXJ0bmVycyB7XG4gICAgd2lkdGg6IDQ2N3B4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWZvci1tb2JpbGUge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAuVXNlLU11cm11ciB7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjc1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgfVxuXG4gIC5JbW1lZGlhdGUtYmxvY2tjaGFpbi1pZC1jcmVhdGlvbi1Oby13YWl0LXRpbWUge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAvKiAubWFpbl9pbWcge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH0gKi9cblxuICAucm90YXRlIHtcbiAgICBhbmltYXRpb246IHJvdGF0aW9uIHJlbGF0aXZlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiByb3RhdGlvbjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNDBweDtcbiAgICB0b3A6IDM1NXB4O1xuICAgIC8qIGxlZnQ6IC0xMjVweDtcbiAgICB0b3A6IDI3MHB4OyAqL1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogNHM7XG4gICAgYW5pbWF0aW9uLWRlbGF5OiAxcztcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpOyAqL1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhdGlvbiB7XG4gICAgZnJvbSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZXooLTE4MGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgd2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7XG4gICAgfVxuICAgIHRvIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbi5zdWJfaW1ne1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIFxufVxuICBAa2V5ZnJhbWVzIHN1Yl9pbWcge1xuICAgIFxuICAgIGZyb20ge3dpZHRoOiAxMCU7IGhlaWdodDogMTAlO31cbiAgICB0byB7IHdpZHRoOiAxMTAlOyBoZWlnaHQ6IDExMCU7fVxuICB9XG4gIC5XZS1hcmUtaW1hZ2luaW5nIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyMTBweDtcbiAgICBvcGFjaXR5OiAwLjk7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSm9pbi10aGUtbmV3LXdheS1vZi10aGUtd29ybGQge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjkge1xuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG5cbiAgLlJlY3RhbmdsZS0zMCB7XG4gICAgXG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgd2lkdGg6IDc4cHg7XG4gIH1cblxuICAuUGF0aC05IHtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIFxuICB9Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.css']
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./component/home/home.component */ "./src/app/component/home/home.component.ts");
/* harmony import */ var _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./component/aboutus/aboutus.component */ "./src/app/component/aboutus/aboutus.component.ts");
/* harmony import */ var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./component/navbar/navbar.component */ "./src/app/component/navbar/navbar.component.ts");








class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
        _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__["HomeComponent"],
        _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__["AboutusComponent"],
        _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                    _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__["HomeComponent"],
                    _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__["AboutusComponent"],
                    _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"]
                ],
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]
                ],
                providers: [],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/component/aboutus/aboutus.component.ts":
/*!********************************************************!*\
  !*** ./src/app/component/aboutus/aboutus.component.ts ***!
  \********************************************************/
/*! exports provided: AboutusComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutusComponent", function() { return AboutusComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");



function AboutusComponent_div_150_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_150_div_3_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r4.twitter(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AboutusComponent_div_150_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_150_div_4_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r6.twitter(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AboutusComponent_div_150_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_150_Template_input_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r8.iconchange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, AboutusComponent_div_150_div_3_Template, 3, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, AboutusComponent_div_150_div_4_Template, 3, 0, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.iconstatus);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.iconstatus);
} }
function AboutusComponent_div_151_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_151_Template_div_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r10.statuschange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Thanks or subscribing!");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class AboutusComponent {
    constructor() {
        this.subscribe = "subscribe";
        this.status = false;
        this.iconstatus = false;
    }
    ngOnInit() {
    }
    twitter() {
        this.status = true;
    }
    statuschange() {
        this.status = false;
        this.iconstatus = false;
    }
    iconchange() {
        this.iconstatus = true;
    }
}
AboutusComponent.ɵfac = function AboutusComponent_Factory(t) { return new (t || AboutusComponent)(); };
AboutusComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AboutusComponent, selectors: [["app-aboutus"]], decls: 178, vars: 2, consts: [[1, "container-sm"], [1, "row", 2, "padding-top", "10%", "padding-bottom", "5%", "padding-left", "35px"], [1, "col-sm-6"], [1, "row"], [1, "About-us"], [1, "Murmur-aims"], [1, "row", 2, "padding-top", "5%"], [1, "Rectangle-11"], [1, "Download-App"], [1, "Rectangle-10"], [1, "Learn-more"], ["src", "../assets/images/about us-01.png", "width", "95%", "height", "100%", 1, "main_img"], [1, "container-fluid", 2, "background-color", "#f1f2f9", "padding-top", "2%"], [1, "container-sm", 2, "padding-top", "10%"], ["src", "../assets/images/user rewards_Prancheta 1 copy.png", 1, "murmur-rewards_Prancheta-1-copy"], [1, "How-do-we-reward-users"], [1, "This-is-where"], ["href", "#", 1, "Read-More"], [1, "container-fluid"], [1, "row", 2, "padding-top", "10%", "margin-left", "1%"], [1, "Development-Partners"], ["src", "../assets/images/download.jpg", 1, "download"], [1, "Chainflux-is-an-end"], [1, "Visit-Site"], [1, "text-style-1"], [1, "Total-supply-1billion-Decibels"], [1, "Decibels-are-given"], [1, "row", 2, "padding-top", "180px"], [1, "col-sm-3"], [1, "col-sm-7"], [1, "Roadmap-to-launch"], [1, "col-sm-2"], ["src", "../assets/images/murmur  rewards-03.png", 1, "murmur-rewards-03"], [1, "container-fluid", "Rectangle-40"], [1, "container-sm", 2, "padding-top", "7%"], [1, "row", 2, "margin-bottom", "80px"], [1, "col-sm-10"], [1, "Frequently-asked-Questions"], [1, "col-sm-12"], [1, "card", "Rectangle-46"], [1, "card-body"], [1, "Current-state-of-Murmur"], [1, "Murmur-is-currently-running-on-the-Telos-Blockchain"], [1, "card", "Rectangle-47"], [1, "How-is-the-reputation-score-calculated"], [1, "What-is-the-difference-between-MUR-and-Decibels-DCBL"], [1, "Why-two-tokens"], [1, "Why-two-platforms-MUR-on-Ethereum-and-Decibels-on-Matic"], [1, "What-are-the-Token-economics-for-MUR"], [1, "What-are-the-Token-economics-for-Decibels"], [1, "Is-there-a-Decibels-MUR-pair-How-does-the-swap-work"], [1, "Where-are-my-transactions-stored"], [1, "Where-are-my-private-keys-stored"], [1, "row", 2, "padding-top", "12%", "padding-left", "42%"], [1, "Rectangle-12"], [1, "Load-more"], [1, "container-fluid", 2, "padding-top", "2%", "border", "solid 1px #707070", "background-color", "#8069ff", "padding-bottom", "10%"], [1, "We-are-imagining"], [1, "row", 2, "padding-top", "2%"], [1, "Join-the-new-way-of-the-world"], ["src", "../assets/images/Path 8.png", "width", "95%"], ["class", "input-group mb-3", "style", "width: 95%;", 4, "ngIf"], [1, "container-fluid", 2, "padding-top", "10%"], ["src", "../assets/images/about us@2x.png", 1, "murmur-03"], [1, "col-sm-5"], [1, "Forums-Blog-Docs-Token-Economics"], ["src", "../assets/images/Google+Play.png", 1, "GooglePlay"], ["src", "../assets/images/i os.png", 1, "i-os"], [1, "Murmur-All-rights-reserved"], [1, "input-group", "mb-3", 2, "width", "95%"], ["type", "text", "placeholder", "Subscribe", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 1, "form-control", "Rectangle-29", 3, "click"], [1, "input-group-append"], ["class", "input-group-text Rectangle-30", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["class", "input-group-text Rectangle-33", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-30", 3, "click"], [1, "fa", "fa-paper-plane", "Path-9"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-33", 3, "click"], [1, "Rectangle-28", 3, "click"], [1, "Thanks-or-subscribing"], [1, "fa", "fa-paper-plane", "Path-8"]], template: function AboutusComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "About us");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Murmur aims to be the most rewarding social media platform.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Download App");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Learn more");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "How do we reward users?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "This is where SoFi, or Social Finance meets DeFi, decentralized finance. Users of Murmur have a say in MIPs (Murmur Improvement Proposals), governance of MurSwap, as well as the reward mechanism in MurSwap. Decibels (DCBL) is the token given as incentive to LPs. Decibels is given as incentive to Murmur social media users for governance of the network. Decibel holders can develop a reputation score based on their social media activity. Decibel holders can request for Decibel collateralized loans for ETH or any ERC20 token. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "a", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Read More");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "span", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "Development Partners");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](41, "img", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "span", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "Chainflux is an end-to-end blockchain project development company that helps build efficient, agile, and trust-based businesses.'");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "a", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "Visit Site");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "span", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Total supply:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "span", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "1billion Decibels");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "span", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Decibels are given out every week based on a given formula. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](57, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, " Decibels are also the reward Token given out to LPs in MURSwap. They are rewarded in DCBL (Decibels), which enables voting on MIPs as well as suggests improvements to the Murmur ecosystem. Decibel holders who have developed a reputation score can request for decibel collateralized loans in exchange for ETH or any ERC20 Token. Decibels can also be exchanged on a lending platform for any other Ethereum based asset. The transaction fees ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "a", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "Read More");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "span", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, " Roadmap to launch ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](68, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "span", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](77, " Frequently asked Questions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "span", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "Current state of Murmur?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](84, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](85, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "span", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](87, "Murmur is currently running on the Telos Blockchain.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "span", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](91, "How is the reputation score calculated?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "span", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](95, "What is the difference between MUR and Decibels (DCBL)?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "span", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, "Why two tokens?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "span", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](103, "Why two platforms \u2013 MUR on Ethereum and Decibels on Matic?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "span", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](107, "What are the Token economics for MUR?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "span", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](111, "What are the Token economics for Decibels? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "span", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](115, "Is there a Decibels \u2013 MUR pair? How does the swap work?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "span", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Where are my transactions stored?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "span", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123, "Where are my private keys stored?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "div", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "span", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](127, "Load more");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](131, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "span", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](134, " We are imagining a world where social media is trustworthy, rewarding and liberating. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](135, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](137, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "span", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](140, " Join the new way of the world! ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](141, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](143, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](144, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](145, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](146, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](148, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](149, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](150, AboutusComponent_div_150_Template, 5, 2, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](151, AboutusComponent_div_151_Template, 5, 0, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](152, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](157, "img", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](160, " Forums ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](161, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](163, "Blog");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](164, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](165, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](166, "Docs");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](167, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](168, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](169, "Token Economics");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](170, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](171, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](172, "img", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](173, "img", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](174, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](175, "span", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](176, " \u00A9 2020 Murmur. All rights reserved. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](177, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](150);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.status);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]], styles: [".About-us[_ngcontent-%COMP%] {\n    width: 248px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Murmur-aims[_ngcontent-%COMP%] {\n    width: 420px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n  .Rectangle-12[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 2%;\n    cursor: pointer;\n  }\n  \n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  padding-left: 13%;\n  cursor: pointer;\n  }\n  \n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 20%;\n  cursor: pointer;\n  \n  }\n  \n  .How-do-we-reward-users[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .This-is-where[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Read-More[_ngcontent-%COMP%] {\n    \n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2.05;\n  letter-spacing: normal;\n  text-align: left;\n  color: #8069ff;\n  padding-top: 50px;\n}\n  \n  .murmur-rewards_Prancheta-1-copy[_ngcontent-%COMP%] {\n    width:100%;\n    height:100%;\n   \n  }\n  \n  .Development-Partners[_ngcontent-%COMP%] {\n    \n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    margin-bottom: 30px;\n    color: #000000;\n  }\n  \n  .download[_ngcontent-%COMP%] {\n    width: 67%;\n    height: 100%;\n    margin-bottom: 30px;\n  }\n  \n  .Chainflux-is-an-end[_ngcontent-%COMP%] {\n    width: 428px;\n    height: 85px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-bottom: 30px;\n  }\n  \n  .Visit-Site[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  \n  .Total-supply-1billion-Decibels[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  \n  .Roadmap-to-launch[_ngcontent-%COMP%] {\n    width: 552px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .murmur-rewards-03[_ngcontent-%COMP%] {\n    height: 100%;\n    width: 100%;\n    \n    margin-top: 8%;\n    margin-bottom: 12%;\n    position: relative;\n    overflow-x:auto;\n    overflow-y:auto;\n  }\n  \n  .Rectangle-40[_ngcontent-%COMP%] {\n   \n    padding-bottom: 10%;\n    background-color: #f1f2f9;\n    padding-top: 2%;\n  }\n  \n  .Rectangle-46[_ngcontent-%COMP%] {\n   \n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n  \n  .Frequently-asked-Questions[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    \n\n  }\n  \n  .Current-state-of-Murmur[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n    \n  }\n  \n  .Murmur-is-currently-running-on-the-Telos-Blockchain[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 30px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    \n    color: #000000;\n  }\n  \n  .Rectangle-47[_ngcontent-%COMP%] {\n    margin-top: 37px;\n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n  \n  .How-is-the-reputation-score-calculated[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n   \n  }\n  \n  .What-is-the-difference-between-MUR-and-Decibels-DCBL[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Why-two-tokens[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Why-two-platforms-MUR-on-Ethereum-and-Decibels-on-Matic[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .What-are-the-Token-economics-for-MUR[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .What-are-the-Token-economics-for-Decibels[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Is-there-a-Decibels-MUR-pair-How-does-the-swap-work[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Where-are-my-transactions-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Where-are-my-private-keys-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Load-more[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 20%;\n  }\n  \n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n  \n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n  \n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n  \n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n  \n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n  \n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n  \n  .text-style-1[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Decibels-are-given[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n  \n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  \n  .Use-Murmur[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  \n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  \n  \n  \n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n  \n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  \n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  \n  .sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  \n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  \n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  \n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #ffffff;\n  }\n  \n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n  }\n  \n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  \n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n  \n  \n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #00cd9b;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n  \n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n    color: #00cd9b;\n    font-size: 28px;\n    cursor: pointer;\n  }\n  \n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n  \n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n  \n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n  \n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n}\n  \n  .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L2Fib3V0dXMvYWJvdXR1cy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0VBRUU7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Y7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixvQkFBb0I7RUFDcEI7O0VBR0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBQ0E7SUFDRTtpQkFDYTtFQUNmLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtBQUNuQjs7RUFDRTtJQUNFLFVBQVU7SUFDVixXQUFXOztFQUViOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLG1CQUFtQjtJQUNuQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsVUFBVTtJQUNWLFlBQVk7SUFDWixtQkFBbUI7RUFDckI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBR0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxtQkFBbUI7SUFDbkIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixVQUFVO0lBQ1Ysd0JBQXdCO0lBQ3hCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFO21CQUNlO0lBQ2Ysb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QseUJBQXlCOztFQUUzQjs7RUFDQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjOztFQUVoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjs7SUFFaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixVQUFVO0lBQ1Ysd0JBQXdCO0lBQ3hCLGlCQUFpQjtFQUNuQjs7RUFHQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjOztFQUVoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBR0E7SUFDRSxhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFHQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBR0E7SUFDRSxhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBR0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGlCQUFpQjtFQUNuQjs7RUFHQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTs7RUFFakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFHQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFzQkE7SUFDRTtvQkFDZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFRQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7O0tBRUc7O0VBRUg7SUFDRSxvQ0FBNEI7WUFBNUIsNEJBQTRCO0lBQzVCLGdDQUF3QjtZQUF4Qix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixVQUFVO0lBQ1Y7aUJBQ2E7SUFDYixXQUFXO0lBQ1gsOEJBQXNCO1lBQXRCLHNCQUFzQjtJQUN0QiwyQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLFdBQVcsRUFBRSxZQUFZO0lBQ3pCLGdDQUFnQztFQUNsQzs7RUFFQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGOztFQWRBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7O0VBQ0Y7RUFDRSwrQkFBdUI7VUFBdkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsdUJBQXVCO0VBQ3ZCLDhCQUFzQjtVQUF0QixzQkFBc0I7O0FBRXhCOztFQUNFOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7O0VBSkE7O0lBRUUsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLEtBQUssV0FBVyxFQUFFLFlBQVksQ0FBQztFQUNqQzs7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0VBQ2I7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7Ozs7Ozs7Ozs7O0tBV0c7O0VBR0g7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtBQUNoQzs7RUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsMEJBQTBCO0VBQzFCLDZCQUE2QjtBQUMvQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9hYm91dHVzL2Fib3V0dXMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuICBcbiAgLkFib3V0LXVzIHtcbiAgICB3aWR0aDogMjQ4cHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cbiAgXG4gIC5NdXJtdXItYWltcyB7XG4gICAgd2lkdGg6IDQyMHB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG4gIFxuICAuUmVjdGFuZ2xlLTEwIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEwOmhvdmVyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTEge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICAgIHBhZGRpbmctdG9wOiAyJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIHBhZGRpbmctbGVmdDogMTMlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMjAlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIGNvbG9yOiAjMDAwMDAwOyAqL1xuICB9XG5cblxuICAuSG93LWRvLXdlLXJld2FyZC11c2VycyB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMTUwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5UaGlzLWlzLXdoZXJle1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cbiAgLlJlYWQtTW9yZSB7XG4gICAgLyogd2lkdGg6IDExMHB4O1xuICBoZWlnaHQ6IDI4cHg7ICovXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAyLjA1O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzgwNjlmZjtcbiAgcGFkZGluZy10b3A6IDUwcHg7XG59XG4gIC5tdXJtdXItcmV3YXJkc19QcmFuY2hldGEtMS1jb3B5IHtcbiAgICB3aWR0aDoxMDAlO1xuICAgIGhlaWdodDoxMDAlO1xuICAgXG4gIH1cblxuICAuRGV2ZWxvcG1lbnQtUGFydG5lcnMge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICAvKiBoZWlnaHQ6IDE1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5kb3dubG9hZCB7XG4gICAgd2lkdGg6IDY3JTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgfVxuXG4gIC5DaGFpbmZsdXgtaXMtYW4tZW5kIHtcbiAgICB3aWR0aDogNDI4cHg7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgfVxuXG4gIC5WaXNpdC1TaXRlIHtcbiAgICB3aWR0aDogMTEwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMi4wNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICM4MDY5ZmY7XG4gIH1cblxuICAuVG90YWwtc3VwcGx5LTFiaWxsaW9uLURlY2liZWxzIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cblxuICAuUm9hZG1hcC10by1sYXVuY2gge1xuICAgIHdpZHRoOiA1NTJweDtcbiAgICBoZWlnaHQ6IDgwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5tdXJtdXItcmV3YXJkcy0wMyB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8qIG1hcmdpbi1sZWZ0OiA3MnB4OyAqL1xuICAgIG1hcmdpbi10b3A6IDglO1xuICAgIG1hcmdpbi1ib3R0b206IDEyJTtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgb3ZlcmZsb3cteDphdXRvO1xuICAgIG92ZXJmbG93LXk6YXV0bztcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDAge1xuICAgXG4gICAgcGFkZGluZy1ib3R0b206IDEwJTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHBhZGRpbmctdG9wOiAyJTtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDYge1xuICAgXG4gICAgLyogaGVpZ2h0OiAxNDVweDsgKi9cbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogOTAlO1xuICAgIC8qIHBhZGRpbmctbGVmdDogMTVweDsgKi9cbiAgICBtYXJnaW4tbGVmdDogNTRweDtcbiAgfVxuXG4gIC5GcmVxdWVudGx5LWFza2VkLVF1ZXN0aW9ucyB7XG4gICAgLyogd2lkdGg6IDc4MHB4O1xuICAgIGhlaWdodDogODBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAxOTBweDsgKi9cblxuICB9XG4gIC5DdXJyZW50LXN0YXRlLW9mLU11cm11ciB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICAgIFxuICB9XG5cbiAgLk11cm11ci1pcy1jdXJyZW50bHktcnVubmluZy1vbi10aGUtVGVsb3MtQmxvY2tjaGFpbiB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDcge1xuICAgIG1hcmdpbi10b3A6IDM3cHg7XG4gICAgLyogaGVpZ2h0OiA4MHB4OyAqL1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAxNXB4OyAqL1xuICAgIG1hcmdpbi1sZWZ0OiA1NHB4O1xuICB9XG5cblxuICAuSG93LWlzLXRoZS1yZXB1dGF0aW9uLXNjb3JlLWNhbGN1bGF0ZWQge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgIFxuICB9XG5cbiAgLldoYXQtaXMtdGhlLWRpZmZlcmVuY2UtYmV0d2Vlbi1NVVItYW5kLURlY2liZWxzLURDQkwge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XaHktdHdvLXRva2VucyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuV2h5LXR3by1wbGF0Zm9ybXMtTVVSLW9uLUV0aGVyZXVtLWFuZC1EZWNpYmVscy1vbi1NYXRpYyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuV2hhdC1hcmUtdGhlLVRva2VuLWVjb25vbWljcy1mb3ItTVVSIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuXG4gIC5XaGF0LWFyZS10aGUtVG9rZW4tZWNvbm9taWNzLWZvci1EZWNpYmVscyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuSXMtdGhlcmUtYS1EZWNpYmVscy1NVVItcGFpci1Ib3ctZG9lcy10aGUtc3dhcC13b3JrIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2hlcmUtYXJlLW15LXRyYW5zYWN0aW9ucy1zdG9yZWQge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XaGVyZS1hcmUtbXktcHJpdmF0ZS1rZXlzLXN0b3JlZCB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuTG9hZC1tb3JlIHtcbiAgICB3aWR0aDogMTEwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgfVxuXG5cbiAgLm11cm11ci0wMyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMTIlO1xuICAgIG1hcmdpbi1sZWZ0OiA4JTtcbiAgICBcbiAgfVxuICBcbiAgLkZvcnVtcy1CbG9nLURvY3MtVG9rZW4tRWNvbm9taWNzIHtcbiAgICB3aWR0aDogMzU4cHg7XG4gICAgaGVpZ2h0OiAyNzJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG4gIFxuICAuaS1vcyB7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBoZWlnaHQ6IDUwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHg7XG4gICAgcGFkZGluZy10b3A6IDE2cHg7XG4gIH1cblxuICAuR29vZ2xlUGxheSB7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBoZWlnaHQ6IDUwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHg7XG4gICAgcGFkZGluZy10b3A6IDE2cHg7XG4gIH1cblxuICAuTXVybXVyLUFsbC1yaWdodHMtcmVzZXJ2ZWQge1xuICAgIGhlaWdodDogMjBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDUuMTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIG1hcmdpbi1sZWZ0OiA0JTtcbiAgICBtYXJnaW4tdG9wOiAxNyU7XG4gIH1cblxuXG4gIC5SZWN0YW5nbGUtMjQge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI1IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNiB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwY2Q5YjtcbiAgfVxuICBcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4gIC50ZXh0LXN0eWxlLTEge1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDE1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuRGVjaWJlbHMtYXJlLWdpdmVue1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICBcblxuXG5cblxuXG4gIC5CdWlsdC1vbi1CbG9ja2NoYWluIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLkN1cnJlbnQtUGFydG5lcnMge1xuICAgIHdpZHRoOiA0NjdweDtcbiAgICBoZWlnaHQ6IDgwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLk11cm11ci1mb3ItbW9iaWxlIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICB9XG5cbiAgLlVzZS1NdXJtdXIge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS43NTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAuSW1tZWRpYXRlLWJsb2NrY2hhaW4taWQtY3JlYXRpb24tTm8td2FpdC10aW1lIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMzM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICB9XG5cbiAgLyogLm1haW5faW1nIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5cbiAgLnJvdGF0ZSB7XG4gICAgYW5pbWF0aW9uOiByb3RhdGlvbiByZWxhdGl2ZTtcbiAgICBhbmltYXRpb24tbmFtZTogcm90YXRpb247XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDQwcHg7XG4gICAgdG9wOiAzNTVweDtcbiAgICAvKiBsZWZ0OiAtMTI1cHg7XG4gICAgdG9wOiAyNzBweDsgKi9cbiAgICB6LWluZGV4OiAtMTtcbiAgICBhbmltYXRpb24tZHVyYXRpb246IDRzO1xuICAgIGFuaW1hdGlvbi1kZWxheTogMXM7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICAvKiB0cmFuc2Zvcm06IHJvdGF0ZVooLTkwZGVnKTsgKi9cbiAgfVxuXG4gIEBrZXlmcmFtZXMgcm90YXRpb24ge1xuICAgIGZyb20ge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGV6KC0xODBkZWcpO1xuICAgICAgbGVmdDogNDBweDtcbiAgICAgIHRvcDogMjVweDtcbiAgICAgIHdpZHRoOiAxMCU7IGhlaWdodDogMTAlO1xuICAgIH1cbiAgICB0byB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooMGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuICB9XG4uc3ViX2ltZ3tcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogLTE7XG4gIGFuaW1hdGlvbi1uYW1lOiBzdWJfaW1nO1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBcbn1cbiAgQGtleWZyYW1lcyBzdWJfaW1nIHtcbiAgICBcbiAgICBmcm9tIHt3aWR0aDogMTAlOyBoZWlnaHQ6IDEwJTt9XG4gICAgdG8geyB3aWR0aDogMTEwJTsgaGVpZ2h0OiAxMTAlO31cbiAgfVxuICAuV2UtYXJlLWltYWdpbmluZyB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMjEwcHg7XG4gICAgb3BhY2l0eTogMC45O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZmZmZmZmO1xuICB9XG5cbiAgLkpvaW4tdGhlLW5ldy13YXktb2YtdGhlLXdvcmxkIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiA2MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI5IHtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YxZjJmOTtcbiAgICB3aWR0aDogNzhweDtcbiAgfVxuICAuUmVjdGFuZ2xlLTI4IHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICNmMWYyZjk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC8qIC5SZWN0YW5nbGUtMzAge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG5cbiAgLlBhdGgtOSB7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH0gKi9cblxuXG4gIC5SZWN0YW5nbGUtMzAge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0zMyB7XG4gICAgXG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMWYyZjk7XG4gICAgd2lkdGg6IDc4cHg7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5QYXRoLTkge1xuICAgIC8qIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7ICovXG4gICAgXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG5cbiAgLlBhdGgtOCB7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIHBhZGRpbmctbGVmdDogNTAlO1xuICB9XG5cbiAgLlRoYW5rcy1vci1zdWJzY3JpYmluZyB7XG4gICAgd2lkdGg6IDIyNHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuNjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDBjZDliO1xuICAgIHBhZGRpbmctbGVmdDogNCU7XG4gIH1cblxuICAuaW5wdXQtZ3JvdXAgPiAuZm9ybS1jb250cm9sOm5vdCg6bGFzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5jdXN0b20tc2VsZWN0Om5vdCg6bGFzdC1jaGlsZCkge1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbn1cblxuLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLWFwcGVuZCA+IC5idG4sIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpub3QoOmZpcnN0LWNoaWxkKSA+IC5pbnB1dC1ncm91cC10ZXh0LCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5idG46bm90KDpmaXJzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOmZpcnN0LWNoaWxkID4gLmlucHV0LWdyb3VwLXRleHQ6bm90KDpmaXJzdC1jaGlsZCkge1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AboutusComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-aboutus',
                templateUrl: './aboutus.component.html',
                styleUrls: ['./aboutus.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/component/home/home.component.ts":
/*!**************************************************!*\
  !*** ./src/app/component/home/home.component.ts ***!
  \**************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");



function HomeComponent_div_187_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_187_div_3_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r4.twitter(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function HomeComponent_div_187_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_187_div_4_Template_div_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r6.twitter(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function HomeComponent_div_187_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "input", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_187_Template_input_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r8.iconchange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, HomeComponent_div_187_div_3_Template, 3, 0, "div", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, HomeComponent_div_187_div_4_Template, 3, 0, "div", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("placeholder", ctx_r0.subscribe);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.iconstatus);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.iconstatus);
} }
function HomeComponent_div_188_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_188_Template_div_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r10.statuschange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Thanks or subscribing!");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class HomeComponent {
    constructor() {
        this.subscribe = "subscribe";
        this.status = false;
        this.iconstatus = false;
    }
    ngOnInit() {
    }
    twitter() {
        this.status = true;
    }
    statuschange() {
        this.status = false;
        this.iconstatus = false;
    }
    iconchange() {
        this.iconstatus = true;
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(); };
HomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["app-home"]], decls: 215, vars: 2, consts: [[1, "container-fluid"], [1, "container-sm"], [1, "row", 2, "padding-top", "10%", "padding-bottom", "5%", "padding-left", "40px"], [1, "col-sm-7"], [1, "row"], [1, "The-most-rewarding-social-media-platform"], [1, "Murmur-is-everything"], [1, "row", 2, "padding-top", "5%"], [1, "Rectangle-11"], [1, "Download-App"], [1, "Rectangle-10"], [1, "Learn-more"], [1, "col-sm-5"], ["src", "../assets/images/murmur hompeage main illus.png", 1, "murmur-02"], [1, "container-fluid", 2, "background-color", "#f1f2f9", "padding-top", "2%"], [1, "container-sm", 2, "padding-top", "10%"], [1, "col-sm-4"], ["src", "../assets/images/icons-05.png", 1, "icons-05"], [1, "col-sm-8", 2, "padding-left", "127px"], [1, "Why-Murmur"], [1, "We-believe"], ["href", "#", 1, "Read-More"], [1, "row", 2, "padding-top", "10%", "padding-left", "40px"], [1, "col-sm-3"], [1, "row", "Built-on-Blockchain"], [1, "col-sm-6"], [1, "row", "Murmur-is-a-rewarding", 2, "padding-top", "5%"], [1, "text-style-1"], [1, "col-sm-1"], [1, "col-sm-10"], [1, "col-sm-2"], [1, "row", 2, "padding-top", "10%"], ["src", "../assets/images/user rewards_Prancheta 1 copy.png", "width", "100%", "height", "105%"], [1, "row", "Rewarding-to-use"], [1, "Publishing-and-engaging", 2, "padding-top", "5%"], [1, "Rectangle-63"], [1, "row", "justify-content-center", 2, "padding-top", "10%", "text-align", "center"], [1, "col-sm-12", "Current-Partners"], [1, "row", 2, "align-items", "center", "text-align", "center", "padding-bottom", "8%"], ["src", "../assets/images/l 2.png", "width", "100%", "height", "100%"], ["src", "../assets/images/l1.png", "width", "100%", "height", "100%"], ["id", "carouselExampleIndicators", "data-ride", "carousel", 1, "carousel", "slide"], [1, "carousel-indicators"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "0", 1, "active"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "1"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "2"], [1, "carousel-inner"], [1, "carousel-item", "active", "Rectangle-24"], [1, "container-sm", "col-sm-4"], ["src", "../assets/images/icons-06 b.png", 1, "icons-06"], [1, "container-sm", "col-sm-2"], ["src", "../assets/images/icons-07.png", "width", "100%", 2, "padding-top", "155%", "margin-left", "15%"], [1, "Murmur-for-mobile"], [1, "Use-Murmur"], [1, "Immediate-blockchain-id-creation-No-wait-time"], ["src", "../assets/images/Google+Play.png", 1, "i-os1"], ["src", "../assets/images/i os.png", 1, "GooglePlay1"], [1, "carousel-item", "Rectangle-25"], ["src", "../assets/images/icons-06 c.png", 1, "icons-06"], ["src", "../assets/images/icons-09.png", "width", "100%", 2, "padding-top", "155%", "margin-left", "15%"], [1, "carousel-item", "Rectangle-26"], ["src", "../assets/images/icons-06 a.png", 1, "icons-06"], ["src", "../assets/images/icons-08.png", "width", "100%", 2, "padding-top", "155%", "margin-left", "15%"], [1, "container-fluid", 2, "padding-top", "2%", "padding-bottom", "10%"], [1, "container", 2, "padding-top", "10%"], [1, "We-are-imagining"], [1, "row", 2, "padding-top", "2%"], [1, "Join-the-new-way-of-the-world"], ["src", "../assets/images/Path 8.png", "width", "95%"], ["class", "input-group mb-3", "style", "width: 95%;", 4, "ngIf"], [1, "container-fluid", 2, "padding-top", "10%"], ["src", "../assets/images/about us@2x.png", 1, "murmur-03"], [1, "Forums-Blog-Docs-Token-Economics"], ["src", "../assets/images/Google+Play.png", 1, "GooglePlay"], ["src", "../assets/images/i os.png", 1, "i-os"], [1, "Murmur-All-rights-reserved"], [1, "input-group", "mb-3", 2, "width", "95%"], ["type", "text", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 1, "form-control", "Rectangle-29", 3, "placeholder", "click"], [1, "input-group-append"], ["class", "input-group-text Rectangle-30", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["class", "input-group-text Rectangle-33", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-30", 3, "click"], [1, "fa", "fa-paper-plane", "Path-9"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-33", 3, "click"], [1, "Rectangle-28", 3, "click"], [1, "Thanks-or-subscribing"], [1, "fa", "fa-paper-plane", "Path-8"]], template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "The most rewarding social media platform");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Murmur is everything that social media can be - transparent, trustworthy, and most of all, rewarding to use. On Murmur, you are in charge of your data and your content, and everything action you do translates into unique rewards. That range from tokens to trust scores.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Download App");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "span", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Learn more");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "img", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Why Murmur?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "p", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "We believe that social media users deserve more from their platforms; that sharing just what\u2019s on your mind and engaging with others should not only be refreshing but also truly valuable. Other networks make money from your data, manipulate what you ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "a", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Read More");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "Built on Blockchain");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "Murmur is a rewarding decentralized social media platform which was built on the Telos Blockchain, but is now porting over to the Matic Blockchain ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "span", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "matic.network.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, " This means that Murmur is transparent, less corruptible, and governed by the community.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Supports privacy");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "To connect to Murmur, all you need is a unique Ethereum address, which can be generated for free on the Murmur mobile app or on a chrome extension like ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "span", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58, "metamask.io.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, " Once activated, all your actions and rewards will be traceable to this identity and this alone.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](60, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65, "Easy to get started");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](66, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](69, "While built on blockchain, using Murmur is straight-forward and clear. It\u2019s like any other microblogging platform, but supports 256 characters\u2019 worth of text, content tagging, tipping feature, and unique actions like murmur, snoop, yell, and whisper.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](70, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](72, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](78, "Rewarding to use");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, "Publishing and engaging with content published by your peers earn you Decibel points. These points are converted into Matic Blockchain tokens weekly. Your actions also culminate in a Trust Score* that reliably points to your trustworthiness in the ecosystem.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](82, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](83, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "h1", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, "Current Partners");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](90, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](92, "img", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](94, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](95, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "ol", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](98, "li", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](99, "li", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](100, "li", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](106, "img", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](108, "img", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "h2", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, "Murmur for mobile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "p", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](115, "Use Murmur on-the-go with your mobile phone. MurmurDapp for Android and iOS devices offer the same capabilities as the Murmur web platform, with three major differences:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "p", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](118, "Immediate blockchain id creation.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "p", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](121, "No wait time!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](123, "img", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](124, "img", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](129, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](131, "img", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "h2", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](135, "Murmur for mobile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "p", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](138, "Use Murmur on-the-go with your mobile phone. MurmurDapp for Android and iOS devices offer the same capabilities as the Murmur web platform, with three major differences:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "p", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](141, "Easy to use EOS/Telos token wallet for token transfers, tips, and redemption");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](143, "img", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](144, "img", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](146, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](149, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](150, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](151, "img", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "h2", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](155, "Murmur for mobile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "p", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](158, "Use Murmur on-the-go with your mobile phone. MurmurDapp for Android and iOS devices offer the same capabilities as the Murmur web platform, with three major differences:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "p", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](161, "Keep your profile information private. Verify your profile as human/bot without revealing your identity.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](163, "img", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](164, "img", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](165, "div", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](166, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](168, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](169, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](170, "span", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](171, " We are imagining a world where social media is trustworthy, rewarding and liberating. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](172, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](173, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](174, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](175, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](176, "span", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](177, " Join the new way of the world! ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](178, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](179, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](180, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](181, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](182, "img", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](183, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](184, "div", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](185, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](186, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](187, HomeComponent_div_187_Template, 5, 3, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](188, HomeComponent_div_188_Template, 5, 0, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](189, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](190, "div", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](191, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](192, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](193, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](194, "img", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](195, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](196, "span", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](197, " Forums ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](198, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](199, "span", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](200, "Blog");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](201, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](202, "span", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](203, "Docs");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](204, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](205, "span", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](206, "Token Economics");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](207, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](208, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](209, "img", 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](210, "img", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](211, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](212, "span", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](213, " \u00A9 2020 Murmur. All rights reserved. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](214, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](187);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.status);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]], styles: [".The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 625px;\n  \n  font-family: Poppins;\n  font-size: 54px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.3;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 580px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]:hover{\n    width: 580px;\n    height: 170px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .murmur-02[_ngcontent-%COMP%] {\n    \n    width:108%;\n    height:100%;\n  }\n\n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  padding-left: 13%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 20%;\n  cursor: pointer;\n  \n  }\n\n  \n\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .We-believe[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .icons-05[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100%;\n  }\n\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Rewarding-to-use[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%] {\n    \n    height: 125px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Rectangle-63[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 220px;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]   .text-style-1[_ngcontent-%COMP%] {\n    color: #8069ff;\n  }\n\n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;  \n  }\n\n  .icons-06[_ngcontent-%COMP%] {\n    \n    width: 160%;\n    height: 130%;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 180px;\n  }\n\n  .Use-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    width: 540px;\n    \n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  \n\n  .i-os1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n    margin-right: 30px;\n  }\n\n  .GooglePlay1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n  }\n\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  .sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #8069ff;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Rectangle-31[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n    color: #8069ff;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n\n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n\n  .input-container[_ngcontent-%COMP%] { \n    display: flex;\n    width: 100%;\n    margin-bottom: 15px;\n  }\n\n  .icon[_ngcontent-%COMP%] {\n    padding: 10px;\n    background: dodgerblue;\n    color: white;\n    min-width: 50px;\n    text-align: center;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n}\n\n  .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7RUFDRTtJQUNFLFlBQVk7RUFDZCxtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2Q7O0VBRUE7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7SUFDZjs7cUNBRWlDO0VBQ25DOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixVQUFVO0lBQ1YsV0FBVztFQUNiOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Y7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixvQkFBb0I7RUFDcEI7O0VBRUE7Ozs7Ozs7Ozs7OztLQVlHOztFQUVIO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7RUFDZDs7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFDQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0VBQ2Y7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGtCQUFrQjtFQUNwQjs7RUFDQTtJQUNFLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixXQUFXO0lBQ1gsWUFBWTtFQUNkOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7O0VBR0E7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBOztLQUVHOztFQUVIO0lBQ0UsVUFBVTtJQUNWLFdBQVc7SUFDWCxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsV0FBVztFQUNiOztFQUNBO0lBQ0Usb0NBQTRCO1lBQTVCLDRCQUE0QjtJQUM1QixnQ0FBd0I7WUFBeEIsd0JBQXdCO0lBQ3hCLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsVUFBVTtJQUNWO2lCQUNhO0lBQ2IsV0FBVztJQUNYLDhCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsMkJBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQixXQUFXLEVBQUUsWUFBWTtJQUN6QixnQ0FBZ0M7RUFDbEM7O0VBRUE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjs7RUFkQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGOztFQUNGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLHVCQUF1QjtFQUN2Qiw4QkFBc0I7VUFBdEIsc0JBQXNCOztBQUV4Qjs7RUFDRTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDOztFQUpBOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7O0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiOztFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLFlBQVk7SUFDWixlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFDQTs7SUFFRSxZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBQ0E7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsY0FBYztJQUNkLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBO0lBQ0U7c0JBQ2tCOztJQUVsQixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxjQUFjO0lBQ2QsZUFBZTtJQUNmLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTs7RUFFakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFHQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQSxtQkFDd0IsU0FBUztJQUMvQixhQUFhO0lBQ2IsV0FBVztJQUNYLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsWUFBWTtJQUNaLGVBQWU7SUFDZixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtBQUNoQzs7RUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsMEJBQTBCO0VBQzFCLDZCQUE2QjtBQUMvQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9ob21lL2hvbWUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAvKiBoZWlnaHQ6IDE2MHB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiA1NHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuMztcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDU4MHB4O1xuICAgIC8qIGhlaWdodDogMTcwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjk0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjsgKi9cbiAgfVxuXG4gIC5NdXJtdXItaXMtZXZlcnl0aGluZzpob3ZlcntcbiAgICB3aWR0aDogNTgwcHg7XG4gICAgaGVpZ2h0OiAxNzBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLm11cm11ci0wMiB7XG4gICAgLyogd2lkdGg6IDEwNTBweDtcbiAgICBoZWlnaHQ6IDcwMHB4OyAqL1xuICAgIHdpZHRoOjEwOCU7XG4gICAgaGVpZ2h0OjEwMCU7XG4gIH1cbiAgXG4gIC5SZWN0YW5nbGUtMTAge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZjYzEzYztcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTA6aG92ZXIge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLlJlY3RhbmdsZS0xMSB7XG4gICAgd2lkdGg6IDE5NXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjODA2OWZmO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLkRvd25sb2FkLUFwcCB7XG4gICAgd2lkdGg6IDE1MHB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiAjMDAwMDAwO1xuICBwYWRkaW5nLWxlZnQ6IDEzJTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLkxlYXJuLW1vcmUge1xuICAgIHdpZHRoOiAxMTVweDtcbiAgaGVpZ2h0OiAyOHB4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICAvKiBjb2xvcjogIzAwMDAwMDsgKi9cbiAgfVxuXG4gIC8qIC5MZWFybi1tb3JlOmhvdmVyIHtcbiAgICB3aWR0aDogMTE1cHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6IHdoaXRlO1xuICB9ICovXG5cbiAgLldoeS1NdXJtdXIge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICAvKiBoZWlnaHQ6IDc3cHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XZS1iZWxpZXZlIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiAxMTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLmljb25zLTA1IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBoZWlnaHQ6IDExMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuUmV3YXJkaW5nLXRvLXVzZSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgfVxuXG4gIC5QdWJsaXNoaW5nLWFuZC1lbmdhZ2luZyB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIGhlaWdodDogMTI1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuICAuUmVjdGFuZ2xlLTYzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDIyMHB4O1xuICB9XG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICAvKiBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNXB4O1xuICB9XG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcgLnRleHQtc3R5bGUtMSB7XG4gICAgY29sb3I6ICM4MDY5ZmY7XG4gIH1cbiAgXG4gIC5DdXJyZW50LVBhcnRuZXJzIHtcbiAgICB3aWR0aDogNDY3cHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDsgIFxuICB9XG5cbiAgLmljb25zLTA2IHtcbiAgICAvKiB3aWR0aDogNzEwcHg7XG4gICAgaGVpZ2h0OiA3NDZweDsgKi9cbiAgICB3aWR0aDogMTYwJTtcbiAgICBoZWlnaHQ6IDEzMCU7XG4gIH1cblxuICAuTXVybXVyLWZvci1tb2JpbGUge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICAvKiBoZWlnaHQ6IDc3cHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLXRvcDogMTgwcHg7XG4gIH1cblxuICBcbiAgLlVzZS1NdXJtdXIge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICAvKiBoZWlnaHQ6IDEwNXB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS43NTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAuSW1tZWRpYXRlLWJsb2NrY2hhaW4taWQtY3JlYXRpb24tTm8td2FpdC10aW1lIHtcbiAgICB3aWR0aDogNTQwcHg7XG4gICAgLyogaGVpZ2h0OiA2N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAvKiAubWFpbl9pbWcge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH0gKi9cblxuICAuaS1vczEge1xuICAgIHdpZHRoOiAzMyU7XG4gICAgaGVpZ2h0OiAzMyU7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkxIHtcbiAgICB3aWR0aDogMzMlO1xuICAgIGhlaWdodDogMzMlO1xuICB9XG4gIC5yb3RhdGUge1xuICAgIGFuaW1hdGlvbjogcm90YXRpb24gcmVsYXRpdmU7XG4gICAgYW5pbWF0aW9uLW5hbWU6IHJvdGF0aW9uO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiA0MHB4O1xuICAgIHRvcDogMzU1cHg7XG4gICAgLyogbGVmdDogLTEyNXB4O1xuICAgIHRvcDogMjcwcHg7ICovXG4gICAgei1pbmRleDogLTE7XG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uOiA0cztcbiAgICBhbmltYXRpb24tZGVsYXk6IDFzO1xuICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7XG4gICAgLyogdHJhbnNmb3JtOiByb3RhdGVaKC05MGRlZyk7ICovXG4gIH1cblxuICBAa2V5ZnJhbWVzIHJvdGF0aW9uIHtcbiAgICBmcm9tIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRleigtMTgwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICB3aWR0aDogMTAlOyBoZWlnaHQ6IDEwJTtcbiAgICB9XG4gICAgdG8ge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGVaKDBkZWcpO1xuICAgICAgbGVmdDogNDBweDtcbiAgICAgIHRvcDogMjVweDtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIH1cbiAgfVxuLnN1Yl9pbWd7XG4gIGFuaW1hdGlvbi1uYW1lOiBzdWJfaW1nO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IC0xO1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgXG59XG4gIEBrZXlmcmFtZXMgc3ViX2ltZyB7XG4gICAgXG4gICAgZnJvbSB7d2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7fVxuICAgIHRvIHsgd2lkdGg6IDExMCU7IGhlaWdodDogMTEwJTt9XG4gIH1cbiAgLldlLWFyZS1pbWFnaW5pbmcge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDIxMHB4O1xuICAgIG9wYWNpdHk6IDAuOTtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5Kb2luLXRoZS1uZXctd2F5LW9mLXRoZS13b3JsZCB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yOSB7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMWYyZjk7XG4gICAgd2lkdGg6IDc4cHg7XG4gIH1cbiAgLlJlY3RhbmdsZS0yOCB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogODVweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjZjFmMmY5O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMzAge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjODA2OWZmO1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMzEge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMzMge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUGF0aC05IHtcbiAgICAvKiBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4OyAqL1xuICAgIFxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxuXG4gIC5QYXRoLTgge1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDUwJTtcbiAgfVxuXG4gIC5tdXJtdXItMDMge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTEyJTtcbiAgICBtYXJnaW4tbGVmdDogOCU7XG4gICAgXG4gIH1cbiAgXG4gIC5Gb3J1bXMtQmxvZy1Eb2NzLVRva2VuLUVjb25vbWljcyB7XG4gICAgd2lkdGg6IDM1OHB4O1xuICAgIGhlaWdodDogMjcycHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS44O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuICBcbiAgLmktb3Mge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLk11cm11ci1BbGwtcmlnaHRzLXJlc2VydmVkIHtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiA1LjE0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tbGVmdDogNCU7XG4gICAgbWFyZ2luLXRvcDogMTclO1xuICB9XG5cblxuICAuUmVjdGFuZ2xlLTI0IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNSB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZjYzEzYztcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjYge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMGNkOWI7XG4gIH1cblxuICAuaW5wdXQtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiAtbXMtZmxleGJveDsgLyogSUUxMCAqL1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgfVxuICBcbiAgLmljb24ge1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgYmFja2dyb3VuZDogZG9kZ2VyYmx1ZTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWluLXdpZHRoOiA1MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuXG4gIC5UaGFua3Mtb3Itc3Vic2NyaWJpbmcge1xuICAgIHdpZHRoOiAyMjRweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjY1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwY2Q5YjtcbiAgICBwYWRkaW5nLWxlZnQ6IDQlO1xuICB9XG5cbiAgLmlucHV0LWdyb3VwID4gLmZvcm0tY29udHJvbDpub3QoOmxhc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuY3VzdG9tLXNlbGVjdDpub3QoOmxhc3QtY2hpbGQpIHtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG59XG5cbi5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtYXBwZW5kID4gLmlucHV0LWdyb3VwLXRleHQsIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmJ0biwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6Zmlyc3QtY2hpbGQgPiAuYnRuOm5vdCg6Zmlyc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5pbnB1dC1ncm91cC10ZXh0Om5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-home',
                templateUrl: './home.component.html',
                styleUrls: ['./home.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/component/navbar/navbar.component.ts":
/*!******************************************************!*\
  !*** ./src/app/component/navbar/navbar.component.ts ***!
  \******************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class NavbarComponent {
    constructor() { }
    ngOnInit() {
    }
}
NavbarComponent.ɵfac = function NavbarComponent_Factory(t) { return new (t || NavbarComponent)(); };
NavbarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NavbarComponent, selectors: [["app-navbar"]], decls: 17, vars: 0, consts: [[1, "container-fluid", "navbar", "sticky-top", "navbar-expand-md", "navbar-dark", 2, "background-color", "#ffffff"], [1, "container"], ["src", "../assets/images/MUR-Logo 1-01.png", "width", "20%"], ["type", "button", "data-toggle", "collapse", "data-target", "#collapsibleNavbar", 1, "navbar-toggler", 2, "background-color", "#8069ff"], [1, "navbar-toggler-icon"], ["id", "collapsibleNavbar", 1, "collapse", "navbar-collapse"], [1, "navbar-nav", "ml-auto", "pr-5"], [1, "nav-item", "active", "pl-3", "pr-3", 2, "padding-top", "5%"], ["routerLink", "/Home", "routerLinkActive", "active", 1, "HOME"], [1, "nav-item", "pl-3", "pr-3", 2, "padding-top", "5%"], ["routerLink", "/About", "routerLinkActive", "active", 1, "ABOUT-US"], [1, "nav-item", "pl-3", "pr-3", 2, "padding-top", "2%"], [1, "Rectangle-7"], ["href", "#", 1, "CONTACT"]], template: function NavbarComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ul", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "li", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "HOME ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "li", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "ABOUT US");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "li", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "CONTACT");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkWithHref"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkActive"]], styles: ["nav[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  .nav-heading[_ngcontent-%COMP%] {\n    width: 29.7px;\n    height: 19.3px;\n    color: #7000d3;\n    font-family: Poppins;\n  }\n  .HOME[_ngcontent-%COMP%] {\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .HOME.active[_ngcontent-%COMP%]{\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #7000d3;\n    text-decoration:none;\n  }\n  .ABOUT-US[_ngcontent-%COMP%] {\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration:none;\n  }\n  .ABOUT-US.active[_ngcontent-%COMP%] {\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #7000d3;\n    text-decoration:none;\n  }\n  .CONTACT[_ngcontent-%COMP%] {\n    width: 97px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #fcc13c;\n    text-decoration:none;\n    padding-left: 24%;\n  }\n  .Rectangle-7[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    border: solid 1px #fcc13c;\n    padding-top: 7%;\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L25hdmJhci9uYXZiYXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7RUFDaEI7RUFDQTtJQUNFLGNBQWM7RUFDaEI7RUFFQTtJQUNFLGFBQWE7SUFDYixjQUFjO0lBQ2QsY0FBYztJQUNkLG9CQUFvQjtFQUN0QjtFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsb0JBQW9CO0VBQ3RCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG9CQUFvQjtFQUN0QjtFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsb0JBQW9CO0lBQ3BCLGlCQUFpQjtFQUNuQjtFQUdBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtFQUNqQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudC9uYXZiYXIvbmF2YmFyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJuYXYgdWwgbGkgYTpob3ZlciB7XG4gICAgY29sb3I6ICMwMjIyNWI7XG4gIH1cbiAgbmF2IGE6aG92ZXIge1xuICAgIGNvbG9yOiAjMDIyMjViO1xuICB9XG5cbiAgLm5hdi1oZWFkaW5nIHtcbiAgICB3aWR0aDogMjkuN3B4O1xuICAgIGhlaWdodDogMTkuM3B4O1xuICAgIGNvbG9yOiAjNzAwMGQzO1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICB9XG5cbiAgLkhPTUUge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSE9NRS5hY3RpdmV7XG4gICAgd2lkdGg6IDYwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzcwMDBkMztcbiAgICB0ZXh0LWRlY29yYXRpb246bm9uZTtcbiAgfVxuXG4gIC5BQk9VVC1VUyB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOm5vbmU7XG4gIH1cblxuICAuQUJPVVQtVVMuYWN0aXZlIHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzcwMDBkMztcbiAgICB0ZXh0LWRlY29yYXRpb246bm9uZTtcbiAgfVxuXG4gIC5DT05UQUNUIHtcbiAgICB3aWR0aDogOTdweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZmNjMTNjO1xuICAgIHRleHQtZGVjb3JhdGlvbjpub25lO1xuICAgIHBhZGRpbmctbGVmdDogMjQlO1xuICB9XG4gIFxuXG4gIC5SZWN0YW5nbGUtNyB7XG4gICAgd2lkdGg6IDE5NXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjZmNjMTNjO1xuICAgIHBhZGRpbmctdG9wOiA3JTtcbiAgfSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NavbarComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-navbar',
                templateUrl: './navbar.component.html',
                styleUrls: ['./navbar.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/mnwuser/Videos/murmurDapp/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map