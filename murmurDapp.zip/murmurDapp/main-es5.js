(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    "./$$_lazy_route_resource lazy recursive":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function $$_lazy_route_resourceLazyRecursive(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
      /***/
    },

    /***/
    "./src/app/app-routing.module.ts":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _component_home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./component/home/home.component */
      "./src/app/component/home/home.component.ts");
      /* harmony import */


      var _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./component/aboutus/aboutus.component */
      "./src/app/component/aboutus/aboutus.component.ts");
      /* harmony import */


      var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./component/navbar/navbar.component */
      "./src/app/component/navbar/navbar.component.ts");

      var routes = [{
        path: 'Home',
        component: _component_home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"]
      }, {
        path: 'About',
        component: _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_3__["AboutusComponent"]
      }, {
        path: 'Navbar',
        component: _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__["NavbarComponent"]
      }, {
        path: '',
        redirectTo: '/Home',
        pathMatch: 'full'
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AppRoutingModule
      });
      AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AppRoutingModule_Factory(t) {
          return new (t || AppRoutingModule)();
        },
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "./src/app/app.component.ts":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./component/navbar/navbar.component */
      "./src/app/component/navbar/navbar.component.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var AppComponent = function AppComponent() {
        _classCallCheck(this, AppComponent);

        this.title = 'murmurDapp';
      };

      AppComponent.ɵfac = function AppComponent_Factory(t) {
        return new (t || AppComponent)();
      };

      AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AppComponent,
        selectors: [["app-root"]],
        decls: 2,
        vars: 0,
        template: function AppComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-navbar");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
          }
        },
        directives: [_component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_1__["NavbarComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]],
        styles: ["nav[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    color: #02225b;\n  }\n  .nav-heading[_ngcontent-%COMP%] {\n    width: 29.7px;\n    height: 19.3px;\n    color: #7000d3;\n    font-family: Poppins;\n  }\n  .HOME[_ngcontent-%COMP%] {\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration:none;\n  }\n  .ABOUT-US[_ngcontent-%COMP%] {\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration:none;\n  }\n  .CONTACT[_ngcontent-%COMP%] {\n    width: 97px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #fcc13c;\n    text-decoration:none;\n  }\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 46px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 580px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Download-App[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    background-color: #8069ff;\n    margin-right: 10%;\n  }\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    background-color: #fcc13c;\n  }\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .We-believe[_ngcontent-%COMP%] {\n    width: 625px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  .Use-Murmur[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n  \n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n  .sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #8069ff;\n    width: 78px;\n  }\n  .Path-9[_ngcontent-%COMP%] {\n    color: white;\n    font-size: 28px;\n    \n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkVBQUU7SUFDRSxjQUFjO0VBQ2hCO0VBQ0E7SUFDRSxjQUFjO0VBQ2hCO0VBRUE7SUFDRSxhQUFhO0lBQ2IsY0FBYztJQUNkLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsb0JBQW9CO0VBQ3RCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG9CQUFvQjtFQUN0QjtFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLGlCQUFpQjtFQUNuQjtFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCx5QkFBeUI7RUFDM0I7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztFQUNoQjtFQUVBO0lBQ0Usb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0VBRUE7SUFDRSxvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUVBOztLQUVHO0VBRUg7SUFDRSxvQ0FBNEI7WUFBNUIsNEJBQTRCO0lBQzVCLGdDQUF3QjtZQUF4Qix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixVQUFVO0lBQ1Y7aUJBQ2E7SUFDYixXQUFXO0lBQ1gsOEJBQXNCO1lBQXRCLHNCQUFzQjtJQUN0QiwyQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLFdBQVcsRUFBRSxZQUFZO0lBQ3pCLGdDQUFnQztFQUNsQztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7RUFkQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGO0VBQ0Y7RUFDRSwrQkFBdUI7VUFBdkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsdUJBQXVCO0VBQ3ZCLDhCQUFzQjtVQUF0QixzQkFBc0I7O0FBRXhCO0VBQ0U7O0lBRUUsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLEtBQUssV0FBVyxFQUFFLFlBQVksQ0FBQztFQUNqQztFQUpBOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBRUE7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0VBQ2I7RUFFQTtJQUNFLFlBQVk7SUFDWixlQUFlOztFQUVqQiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiICBuYXYgdWwgbGkgYTpob3ZlciB7XG4gICAgY29sb3I6ICMwMjIyNWI7XG4gIH1cbiAgbmF2IGE6aG92ZXIge1xuICAgIGNvbG9yOiAjMDIyMjViO1xuICB9XG5cbiAgLm5hdi1oZWFkaW5nIHtcbiAgICB3aWR0aDogMjkuN3B4O1xuICAgIGhlaWdodDogMTkuM3B4O1xuICAgIGNvbG9yOiAjNzAwMGQzO1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICB9XG5cbiAgLkhPTUUge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOm5vbmU7XG4gIH1cblxuICAuQUJPVVQtVVMge1xuICAgIHdpZHRoOiAxMDBweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjpub25lO1xuICB9XG5cbiAgLkNPTlRBQ1Qge1xuICAgIHdpZHRoOiA5N3B4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmY2MxM2M7XG4gICAgdGV4dC1kZWNvcmF0aW9uOm5vbmU7XG4gIH1cblxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDZweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDU4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS45NDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMCU7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDE5NXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICB9XG5cbiAgLldoeS1NdXJtdXIge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLldlLWJlbGlldmUge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLk11cm11ci1pcy1hLXJld2FyZGluZyB7XG4gICAgd2lkdGg6IDMwNHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuQ3VycmVudC1QYXJ0bmVycyB7XG4gICAgd2lkdGg6IDQ2N3B4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWZvci1tb2JpbGUge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAuVXNlLU11cm11ciB7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjc1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgfVxuXG4gIC5JbW1lZGlhdGUtYmxvY2tjaGFpbi1pZC1jcmVhdGlvbi1Oby13YWl0LXRpbWUge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAvKiAubWFpbl9pbWcge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH0gKi9cblxuICAucm90YXRlIHtcbiAgICBhbmltYXRpb246IHJvdGF0aW9uIHJlbGF0aXZlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiByb3RhdGlvbjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNDBweDtcbiAgICB0b3A6IDM1NXB4O1xuICAgIC8qIGxlZnQ6IC0xMjVweDtcbiAgICB0b3A6IDI3MHB4OyAqL1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogNHM7XG4gICAgYW5pbWF0aW9uLWRlbGF5OiAxcztcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpOyAqL1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhdGlvbiB7XG4gICAgZnJvbSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZXooLTE4MGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgd2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7XG4gICAgfVxuICAgIHRvIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbi5zdWJfaW1ne1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIFxufVxuICBAa2V5ZnJhbWVzIHN1Yl9pbWcge1xuICAgIFxuICAgIGZyb20ge3dpZHRoOiAxMCU7IGhlaWdodDogMTAlO31cbiAgICB0byB7IHdpZHRoOiAxMTAlOyBoZWlnaHQ6IDExMCU7fVxuICB9XG4gIC5XZS1hcmUtaW1hZ2luaW5nIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyMTBweDtcbiAgICBvcGFjaXR5OiAwLjk7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSm9pbi10aGUtbmV3LXdheS1vZi10aGUtd29ybGQge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjkge1xuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG5cbiAgLlJlY3RhbmdsZS0zMCB7XG4gICAgXG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgd2lkdGg6IDc4cHg7XG4gIH1cblxuICAuUGF0aC05IHtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIFxuICB9Il19 */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-root',
            templateUrl: './app.component.html',
            styleUrls: ['./app.component.css']
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "./src/app/app.module.ts":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app-routing.module */
      "./src/app/app-routing.module.ts");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./app.component */
      "./src/app/app.component.ts");
      /* harmony import */


      var _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./component/home/home.component */
      "./src/app/component/home/home.component.ts");
      /* harmony import */


      var _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./component/aboutus/aboutus.component */
      "./src/app/component/aboutus/aboutus.component.ts");
      /* harmony import */


      var _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./component/navbar/navbar.component */
      "./src/app/component/navbar/navbar.component.ts");

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
        type: AppModule,
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
      });
      AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
        factory: function AppModule_Factory(t) {
          return new (t || AppModule)();
        },
        providers: [],
        imports: [[_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, {
          declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"], _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__["HomeComponent"], _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__["AboutusComponent"], _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"]],
          imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
          args: [{
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"], _component_home_home_component__WEBPACK_IMPORTED_MODULE_4__["HomeComponent"], _component_aboutus_aboutus_component__WEBPACK_IMPORTED_MODULE_5__["AboutusComponent"], _component_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_6__["NavbarComponent"]],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"]],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "./src/app/component/aboutus/aboutus.component.ts":
    /*!********************************************************!*\
      !*** ./src/app/component/aboutus/aboutus.component.ts ***!
      \********************************************************/

    /*! exports provided: AboutusComponent */

    /***/
    function srcAppComponentAboutusAboutusComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AboutusComponent", function () {
        return AboutusComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

      function AboutusComponent_div_151_div_3_Template(rf, ctx) {
        if (rf & 1) {
          var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 75);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_151_div_3_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);

            var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r4.twitter();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 76);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AboutusComponent_div_151_div_4_Template(rf, ctx) {
        if (rf & 1) {
          var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 77);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_151_div_4_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);

            var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r6.twitter();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 76);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function AboutusComponent_div_151_Template(rf, ctx) {
        if (rf & 1) {
          var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 70);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "input", 71);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_151_Template_input_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

            var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r8.iconchange();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 72);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, AboutusComponent_div_151_div_3_Template, 3, 0, "div", 73);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, AboutusComponent_div_151_div_4_Template, 3, 0, "div", 74);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.iconstatus);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.iconstatus);
        }
      }

      function AboutusComponent_div_152_Template(rf, ctx) {
        if (rf & 1) {
          var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 70);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 78);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AboutusComponent_div_152_Template_div_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);

            var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r10.statuschange();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 79);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Thanks or subscribing!");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 80);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var AboutusComponent = /*#__PURE__*/function () {
        function AboutusComponent() {
          _classCallCheck(this, AboutusComponent);

          this.subscribe = "subscribe";
          this.status = false;
          this.iconstatus = false;
        }

        _createClass(AboutusComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "twitter",
          value: function twitter() {
            this.status = true;
          }
        }, {
          key: "statuschange",
          value: function statuschange() {
            this.status = false;
            this.iconstatus = false;
          }
        }, {
          key: "iconchange",
          value: function iconchange() {
            this.iconstatus = true;
          }
        }]);

        return AboutusComponent;
      }();

      AboutusComponent.ɵfac = function AboutusComponent_Factory(t) {
        return new (t || AboutusComponent)();
      };

      AboutusComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AboutusComponent,
        selectors: [["app-aboutus"]],
        decls: 179,
        vars: 2,
        consts: [[1, "container-sm"], [1, "row", 2, "padding-top", "10%", "padding-bottom", "5%", "padding-left", "35px"], [1, "col-sm-6"], [1, "row"], [1, "About-us"], [1, "Murmur-aims"], [1, "row", 2, "padding-top", "5%"], [1, "Rectangle-11"], [1, "Download-App"], [1, "Rectangle-10"], [1, "Learn-more"], ["src", "../assets/images/about us-01.png", "width", "95%", "height", "100%", 1, "main_img"], [1, "container-fluid", 2, "background-color", "#f1f2f9", "padding-top", "2%"], [1, "container-sm", 2, "padding-top", "10%"], ["src", "../assets/images/user rewards_Prancheta 1 copy.png", 1, "murmur-rewards_Prancheta-1-copy"], [1, "col-sm-5"], [1, "How-do-we-reward-users"], [1, "This-is-where"], ["href", "#", 1, "Read-More"], [1, "col-sm-1"], [1, "container-fluid"], [1, "row", 2, "padding-top", "10%", "margin-left", "1%"], [1, "Development-Partners"], ["src", "../assets/images/download.jpg", 1, "download"], [1, "Chainflux-is-an-end"], [1, "Visit-Site"], [1, "text-style-1"], [1, "Total-supply-1billion-Decibels"], [1, "Decibels-are-given"], [1, "row", 2, "padding-top", "180px"], [1, "col-sm-3"], [1, "col-sm-7"], [1, "Roadmap-to-launch"], [1, "col-sm-2"], ["src", "../assets/images/murmur  rewards-03.png", 1, "murmur-rewards-03"], [1, "container-fluid", "Rectangle-40"], [1, "container-sm", 2, "padding-top", "7%"], [1, "row", 2, "margin-bottom", "80px"], [1, "col-sm-10"], [1, "Frequently-asked-Questions"], [1, "col-sm-12"], [1, "card", "Rectangle-46"], [1, "card-body"], [1, "Current-state-of-Murmur"], [1, "Murmur-is-currently-running-on-the-Telos-Blockchain"], [1, "card", "Rectangle-47"], [1, "How-is-the-reputation-score-calculated"], [1, "What-is-the-difference-between-MUR-and-Decibels-DCBL"], [1, "Why-two-tokens"], [1, "Why-two-platforms-MUR-on-Ethereum-and-Decibels-on-Matic"], [1, "What-are-the-Token-economics-for-MUR"], [1, "What-are-the-Token-economics-for-Decibels"], [1, "Is-there-a-Decibels-MUR-pair-How-does-the-swap-work"], [1, "Where-are-my-transactions-stored"], [1, "Where-are-my-private-keys-stored"], [1, "row", 2, "padding-top", "12%", "padding-left", "42%"], [1, "Rectangle-12"], [1, "Load-more"], [1, "container-fluid", 2, "padding-top", "2%", "border", "solid 1px #707070", "background-color", "#8069ff", "padding-bottom", "10%"], [1, "We-are-imagining"], [1, "row", 2, "padding-top", "2%"], [1, "Join-the-new-way-of-the-world"], ["src", "../assets/images/e-mail arrow white web.png", "width", "95%"], ["class", "input-group mb-3", "style", "width: 95%;", 4, "ngIf"], [1, "container-fluid", 2, "padding-top", "10%"], ["src", "../assets/images/about us@2x.png", 1, "murmur-03"], [1, "Forums-Blog-Docs-Token-Economics"], ["src", "../assets/images/Google+Play.png", 1, "GooglePlay"], ["src", "../assets/images/i os.png", 1, "i-os"], [1, "Murmur-All-rights-reserved"], [1, "input-group", "mb-3", 2, "width", "95%"], ["type", "text", "placeholder", "Subscribe", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 1, "form-control", "Rectangle-29", 3, "click"], [1, "input-group-append"], ["class", "input-group-text Rectangle-30", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["class", "input-group-text Rectangle-33", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-30", 3, "click"], [1, "fa", "fa-paper-plane", "Path-9"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-33", 3, "click"], [1, "Rectangle-28", 3, "click"], [1, "Thanks-or-subscribing"], [1, "fa", "fa-paper-plane", "Path-8"]],
        template: function AboutusComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "About us");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Decibel aims to be the most rewarding social media platform.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "span", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Download App");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Learn more");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "img", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](22, "img", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "span", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "How do we reward users?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "span", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "This is where SoFi, or Social Finance meets DeFi, decentralized finance. Users of Decibel have a say in MIPs (Decibel Improvement Proposals), governance of MurSwap, as well as the reward mechanism in MurSwap. Decibels (DCBL) is the token given as incentive to LPs. Decibels is given as incentive to Decibel social media users for governance of the network. Decibel holders can develop a reputation score based on their social media activity. Decibel holders can request for Decibel collateralized loans for ETH or any ERC20 token. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "a", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Read More");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "span", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Development Partners");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "img", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "span", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Chainflux is an end-to-end blockchain project development company that helps build efficient, agile, and trust-based businesses.'");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "a", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Visit Site");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "span", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Total supply:");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "span", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "1billion Decibels");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "span", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Decibels are given out every week based on a given formula. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](57, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, " Decibels are also the reward Token given out to LPs in MURSwap. They are rewarded in DCBL (Decibels), which enables voting on MIPs as well as suggests improvements to the Decibel ecosystem. Decibel holders who have developed a reputation score can request for decibel collateralized loans in exchange for ETH or any ERC20 Token. Decibels can also be exchanged on a lending platform for any other Ethereum based asset. The transaction fees ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "a", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "Read More");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](63, "div", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "div", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](65, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "span", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](68, " Roadmap to launch ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](69, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](71, "img", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](75, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "span", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](78, " Frequently asked Questions ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "span", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, "Current state of Decibel?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](85, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](86, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "span", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, "Decibel is currently running on the Telos Blockchain.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "span", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](92, "How is the reputation score calculated?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "span", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](96, "What is the difference between MUR and Decibels (DCBL)?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "span", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](100, "Why two tokens?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "span", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](104, "Why two platforms \u2013 MUR on Ethereum and Decibels on Matic?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "span", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](108, "What are the Token economics for MUR?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "span", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, "What are the Token economics for Decibels? ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "span", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](116, "Is there a Decibels \u2013 MUR pair? How does the swap work?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "span", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](120, "Where are my transactions stored?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](123, "span", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](124, "Where are my private keys stored?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "div", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "span", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](128, "Load more");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](131, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](132, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "span", 59);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](135, " We are imagining a world where social media is trustworthy, rewarding and liberating. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](136, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "div", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](138, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "span", 61);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](141, " Join the new way of the world! ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](142, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](144, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](146, "img", 62);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](147, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "div", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](149, "div", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](150, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](151, AboutusComponent_div_151_Template, 5, 2, "div", 63);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](152, AboutusComponent_div_152_Template, 5, 0, "div", 63);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](153, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "div", 64);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](158, "img", 65);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "span", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](161, " Forums ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](162, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](163, "span", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](164, "Blog");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](165, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](166, "span", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](167, "Docs");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](168, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](169, "span", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](170, "Token Economics");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](171, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](172, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](173, "img", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](174, "img", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](175, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](176, "span", 69);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](177, " \xA9 2020 Decibel. All rights reserved. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](178, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](151);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.status);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]],
        styles: ["@media only screen and (min-width: 1200px) { \n  .About-us[_ngcontent-%COMP%] {\n    width: 248px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-top: 50px;\n\n  }\n  \n  .Murmur-aims[_ngcontent-%COMP%] {\n    width: 420px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Murmur-aims[_ngcontent-%COMP%]:hover {\n    width: 420px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-12[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 17px;\n    cursor: pointer;\n  }\n  .Rectangle-12[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color:white;\n    margin-right: 30px;\n    padding-top: 17px;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  \n  padding-left: 13%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 20%;\n  cursor: pointer;\n  \n  }\n\n\n  .How-do-we-reward-users[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .This-is-where[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .This-is-where[_ngcontent-%COMP%]:hover{\n    \n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Read-More[_ngcontent-%COMP%] {\n    \n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2.05;\n  letter-spacing: normal;\n  text-align: left;\n  color: #8069ff;\n  padding-top: 50px;\n}\n  .murmur-rewards_Prancheta-1-copy[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 80%;\n    margin-top: 12%;\n  }\n\n  .Development-Partners[_ngcontent-%COMP%] {\n    \n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    margin-bottom: 30px;\n    color: #000000;\n  }\n\n  .download[_ngcontent-%COMP%] {\n    width: 67%;\n    height: 100%;\n    margin-bottom: 30px;\n  }\n\n  .Chainflux-is-an-end[_ngcontent-%COMP%] {\n    width: 428px;\n    height: 85px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-bottom: 30px;\n    cursor: pointer;\n  }\n\n  .Chainflux-is-an-end[_ngcontent-%COMP%]:hover {\n    width: 428px;\n    height: 85px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-bottom: 30px;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Visit-Site[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .Total-supply-1billion-Decibels[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n\n  .Roadmap-to-launch[_ngcontent-%COMP%] {\n    width: 552px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .murmur-rewards-03[_ngcontent-%COMP%] {\n    height: 100%;\n    width: 100%;\n    \n    margin-top: 8%;\n    margin-bottom: 12%;\n    position: relative;\n    overflow-x:auto;\n    overflow-y:auto;\n  }\n\n  .Rectangle-40[_ngcontent-%COMP%] {\n   \n    padding-bottom: 10%;\n    background-color: #f1f2f9;\n    padding-top: 2%;\n  }\n\n  .Rectangle-46[_ngcontent-%COMP%] {\n   \n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n\n  .Frequently-asked-Questions[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    \n\n  }\n  .Current-state-of-Murmur[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n    \n  }\n\n  .Murmur-is-currently-running-on-the-Telos-Blockchain[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 30px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    \n    color: #000000;\n  }\n\n  .Rectangle-47[_ngcontent-%COMP%] {\n    margin-top: 37px;\n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n\n\n  .How-is-the-reputation-score-calculated[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n   \n  }\n\n  .What-is-the-difference-between-MUR-and-Decibels-DCBL[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Why-two-tokens[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Why-two-platforms-MUR-on-Ethereum-and-Decibels-on-Matic[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .What-are-the-Token-economics-for-MUR[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .What-are-the-Token-economics-for-Decibels[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Is-there-a-Decibels-MUR-pair-How-does-the-swap-work[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Where-are-my-transactions-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Where-are-my-private-keys-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Load-more[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    \n    padding-left: 20%;\n  }\n\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n  \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n  .text-style-1[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Decibels-are-given[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Decibels-are-given[_ngcontent-%COMP%]:hover{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  \n\n\n\n\n\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  .Use-Murmur[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  \n\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #ffffff;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n  }\n\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #00cd9b;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n    color: #00cd9b;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n}\n }\n\n @media only screen and (max-width: 600px) { \n  .About-us[_ngcontent-%COMP%] {\n    width: 248px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n  \n  .Murmur-aims[_ngcontent-%COMP%] {\n    width: 420px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Murmur-aims[_ngcontent-%COMP%]:hover {\n    width: 420px;\n    height: 65px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color: white;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-12[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    background-color: #8069ff;\n    margin-right: 30px;\n    padding-top: 17px;\n    cursor: pointer;\n  }\n  .Rectangle-12[_ngcontent-%COMP%]:hover {\n    width: 195px;\n    height: 65px;\n    background-color: black;\n    color:white;\n    margin-right: 30px;\n    padding-top: 17px;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  \n  padding-left: 13%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 20%;\n  cursor: pointer;\n  \n  }\n\n\n  .How-do-we-reward-users[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .This-is-where[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .This-is-where[_ngcontent-%COMP%]:hover{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Read-More[_ngcontent-%COMP%] {\n    \n  font-family: Poppins;\n  font-size: 20px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2.05;\n  letter-spacing: normal;\n  text-align: left;\n  color: #8069ff;\n  padding-top: 50px;\n}\n  .murmur-rewards_Prancheta-1-copy[_ngcontent-%COMP%] {\n    width:100%;\n    height:100%;\n   \n  }\n\n  .Development-Partners[_ngcontent-%COMP%] {\n    \n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    margin-bottom: 30px;\n    color: #000000;\n  }\n\n  .download[_ngcontent-%COMP%] {\n    width: 67%;\n    height: 100%;\n    margin-bottom: 30px;\n  }\n\n  .Chainflux-is-an-end[_ngcontent-%COMP%] {\n    width: 428px;\n    height: 85px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-bottom: 30px;\n    cursor: pointer;\n  }\n\n  .Chainflux-is-an-end[_ngcontent-%COMP%]:hover {\n    width: 428px;\n    height: 85px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-bottom: 30px;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Visit-Site[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .Total-supply-1billion-Decibels[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 150px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n\n  .Roadmap-to-launch[_ngcontent-%COMP%] {\n    width: 552px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .murmur-rewards-03[_ngcontent-%COMP%] {\n    height: 100%;\n    width: 100%;\n    \n    margin-top: 8%;\n    margin-bottom: 12%;\n    position: relative;\n    overflow-x:auto;\n    overflow-y:auto;\n  }\n\n  .Rectangle-40[_ngcontent-%COMP%] {\n   \n    padding-bottom: 10%;\n    background-color: #f1f2f9;\n    padding-top: 2%;\n  }\n\n  .Rectangle-46[_ngcontent-%COMP%] {\n   \n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n\n  .Frequently-asked-Questions[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    \n\n  }\n  .Current-state-of-Murmur[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n    \n  }\n\n  .Murmur-is-currently-running-on-the-Telos-Blockchain[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 30px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    \n    color: #000000;\n  }\n\n  .Rectangle-47[_ngcontent-%COMP%] {\n    margin-top: 37px;\n    \n    border-radius: 3px;\n    background-color: #ffffff;\n    width: 90%;\n    \n    margin-left: 54px;\n  }\n\n\n  .How-is-the-reputation-score-calculated[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n   \n  }\n\n  .What-is-the-difference-between-MUR-and-Decibels-DCBL[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Why-two-tokens[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Why-two-platforms-MUR-on-Ethereum-and-Decibels-on-Matic[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .What-are-the-Token-economics-for-MUR[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .What-are-the-Token-economics-for-Decibels[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Is-there-a-Decibels-MUR-pair-How-does-the-swap-work[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Where-are-my-transactions-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Where-are-my-private-keys-stored[_ngcontent-%COMP%] {\n    width: 1013px;\n    height: 45px;\n    font-family: Poppins;\n    font-size: 30px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n\n  .Load-more[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    \n    padding-left: 20%;\n  }\n\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n  \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n  .text-style-1[_ngcontent-%COMP%] {\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Decibels-are-given[_ngcontent-%COMP%]{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Decibels-are-given[_ngcontent-%COMP%]:hover{\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  \n\n\n\n\n\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  .Use-Murmur[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n  }\n\n  \n\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #ffffff;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n  }\n\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  \n\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #00cd9b;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n    color: #00cd9b;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n}\n }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L2Fib3V0dXMvYWJvdXR1cy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Q0FDQztFQUNDO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxnQkFBZ0I7O0VBRWxCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCOzs7RUFHQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7RUFDakI7O0VBRUE7SUFDRTtvQkFDZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7RUFDQTtJQUNFO2lCQUNhO0VBQ2Ysb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsaUJBQWlCO0FBQ25CO0VBQ0U7SUFDRSxXQUFXO0lBQ1gsV0FBVztJQUNYLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsWUFBWTtJQUNaLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsbUJBQW1CO0lBQ25CLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG1CQUFtQjtJQUNuQiwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7O0VBR0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxtQkFBbUI7SUFDbkIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixVQUFVO0lBQ1Ysd0JBQXdCO0lBQ3hCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFO21CQUNlO0lBQ2Ysb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QseUJBQXlCOztFQUUzQjtFQUNBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7O0VBRWhCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCOztJQUVoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIseUJBQXlCO0lBQ3pCLFVBQVU7SUFDVix3QkFBd0I7SUFDeEIsaUJBQWlCO0VBQ25COzs7RUFHQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjOztFQUVoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOzs7RUFHQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsaUJBQWlCO0VBQ25COzs7RUFHQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTs7RUFFakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsZUFBZTtJQUNmLGVBQWU7RUFDakI7OztFQUdBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBc0JBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCOzs7Ozs7OztFQVFBO0lBQ0UsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTs7S0FFRzs7RUFFSDtJQUNFLG9DQUE0QjtZQUE1Qiw0QkFBNEI7SUFDNUIsZ0NBQXdCO1lBQXhCLHdCQUF3QjtJQUN4QixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFVBQVU7SUFDVjtpQkFDYTtJQUNiLFdBQVc7SUFDWCw4QkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLDJCQUFtQjtZQUFuQixtQkFBbUI7SUFDbkIsV0FBVyxFQUFFLFlBQVk7SUFDekIsZ0NBQWdDO0VBQ2xDOztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7O0VBZEE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjtBQUNGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLHVCQUF1QjtFQUN2Qiw4QkFBc0I7VUFBdEIsc0JBQXNCOztBQUV4QjtFQUNFOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFKQTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTs7Ozs7Ozs7Ozs7S0FXRzs7O0VBR0g7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtBQUNoQzs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsMEJBQTBCO0VBQzFCLDZCQUE2QjtBQUMvQjtDQUNDOztDQUVBO0VBQ0M7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7RUFDZCxZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZjs7RUFFQTtJQUNFLFlBQVk7RUFDZCxZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQjs7O0VBR0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCO0VBQ0E7SUFDRTtpQkFDYTtFQUNmLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGlCQUFpQjtBQUNuQjtFQUNFO0lBQ0UsVUFBVTtJQUNWLFdBQVc7O0VBRWI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsWUFBWTtJQUNaLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsbUJBQW1CO0lBQ25CLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLG1CQUFtQjtJQUNuQiwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7O0VBR0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxtQkFBbUI7SUFDbkIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixVQUFVO0lBQ1Ysd0JBQXdCO0lBQ3hCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFO21CQUNlO0lBQ2Ysb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QseUJBQXlCOztFQUUzQjtFQUNBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7O0VBRWhCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCOztJQUVoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIseUJBQXlCO0lBQ3pCLFVBQVU7SUFDVix3QkFBd0I7SUFDeEIsaUJBQWlCO0VBQ25COzs7RUFHQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjOztFQUVoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7OztFQUdBO0lBQ0UsYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOzs7RUFHQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsaUJBQWlCO0VBQ25COzs7RUFHQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTs7RUFFakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsZUFBZTtJQUNmLGVBQWU7RUFDakI7OztFQUdBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBc0JBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFO29CQUNnQjtJQUNoQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0U7b0JBQ2dCO0lBQ2hCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCOzs7Ozs7OztFQVFBO0lBQ0UsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTs7S0FFRzs7RUFFSDtJQUNFLG9DQUE0QjtZQUE1Qiw0QkFBNEI7SUFDNUIsZ0NBQXdCO1lBQXhCLHdCQUF3QjtJQUN4QixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFVBQVU7SUFDVjtpQkFDYTtJQUNiLFdBQVc7SUFDWCw4QkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLDJCQUFtQjtZQUFuQixtQkFBbUI7SUFDbkIsV0FBVyxFQUFFLFlBQVk7SUFDekIsZ0NBQWdDO0VBQ2xDOztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7O0VBZEE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjtBQUNGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLHVCQUF1QjtFQUN2Qiw4QkFBc0I7VUFBdEIsc0JBQXNCOztBQUV4QjtFQUNFOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFKQTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTs7Ozs7Ozs7Ozs7S0FXRzs7O0VBR0g7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtBQUNoQzs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsMEJBQTBCO0VBQzFCLDZCQUE2QjtBQUMvQjtDQUNDIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2Fib3V0dXMvYWJvdXR1cy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4gQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAxMjAwcHgpIHsgXG4gIC5BYm91dC11cyB7XG4gICAgd2lkdGg6IDI0OHB4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG5cbiAgfVxuICBcbiAgLk11cm11ci1haW1zIHtcbiAgICB3aWR0aDogNDIwcHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS45NDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLk11cm11ci1haW1zOmhvdmVyIHtcbiAgICB3aWR0aDogNDIwcHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS45NDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgXG4gIC5SZWN0YW5nbGUtMTAge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZjYzEzYztcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTA6aG92ZXIge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLlJlY3RhbmdsZS0xMSB7XG4gICAgd2lkdGg6IDE5NXB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjODA2OWZmO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTE6aG92ZXIge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTIge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XG4gICAgcGFkZGluZy10b3A6IDE3cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTI6aG92ZXIge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6d2hpdGU7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICAgIHBhZGRpbmctdG9wOiAxN3B4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5Eb3dubG9hZC1BcHAge1xuICAgIHdpZHRoOiAxNTBweDtcbiAgaGVpZ2h0OiAyOHB4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAvKiBjb2xvcjogIzAwMDAwMDsgKi9cbiAgcGFkZGluZy1sZWZ0OiAxMyU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5MZWFybi1tb3JlIHtcbiAgICB3aWR0aDogMTE1cHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZy1sZWZ0OiAyMCU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIH1cblxuXG4gIC5Ib3ctZG8td2UtcmV3YXJkLXVzZXJzIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQ1cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLlRoaXMtaXMtd2hlcmV7XG4gICAgLyogd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMjUwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuVGhpcy1pcy13aGVyZTpob3ZlcntcbiAgICAvKiB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWFkLU1vcmUge1xuICAgIC8qIHdpZHRoOiAxMTBweDtcbiAgaGVpZ2h0OiAyOHB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMi4wNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICM4MDY5ZmY7XG4gIHBhZGRpbmctdG9wOiA1MHB4O1xufVxuICAubXVybXVyLXJld2FyZHNfUHJhbmNoZXRhLTEtY29weSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA4MCU7XG4gICAgbWFyZ2luLXRvcDogMTIlO1xuICB9XG5cbiAgLkRldmVsb3BtZW50LVBhcnRuZXJzIHtcbiAgICAvKiB3aWR0aDogNjI1cHg7ICovXG4gICAgLyogaGVpZ2h0OiAxNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuZG93bmxvYWQge1xuICAgIHdpZHRoOiA2NyU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIH1cblxuICAuQ2hhaW5mbHV4LWlzLWFuLWVuZCB7XG4gICAgd2lkdGg6IDQyOHB4O1xuICAgIGhlaWdodDogODVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLkNoYWluZmx1eC1pcy1hbi1lbmQ6aG92ZXIge1xuICAgIHdpZHRoOiA0MjhweDtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5WaXNpdC1TaXRlIHtcbiAgICB3aWR0aDogMTEwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMi4wNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICM4MDY5ZmY7XG4gIH1cblxuICAuVG90YWwtc3VwcGx5LTFiaWxsaW9uLURlY2liZWxzIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cblxuICAuUm9hZG1hcC10by1sYXVuY2gge1xuICAgIHdpZHRoOiA1NTJweDtcbiAgICBoZWlnaHQ6IDgwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5tdXJtdXItcmV3YXJkcy0wMyB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8qIG1hcmdpbi1sZWZ0OiA3MnB4OyAqL1xuICAgIG1hcmdpbi10b3A6IDglO1xuICAgIG1hcmdpbi1ib3R0b206IDEyJTtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgb3ZlcmZsb3cteDphdXRvO1xuICAgIG92ZXJmbG93LXk6YXV0bztcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDAge1xuICAgXG4gICAgcGFkZGluZy1ib3R0b206IDEwJTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHBhZGRpbmctdG9wOiAyJTtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDYge1xuICAgXG4gICAgLyogaGVpZ2h0OiAxNDVweDsgKi9cbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogOTAlO1xuICAgIC8qIHBhZGRpbmctbGVmdDogMTVweDsgKi9cbiAgICBtYXJnaW4tbGVmdDogNTRweDtcbiAgfVxuXG4gIC5GcmVxdWVudGx5LWFza2VkLVF1ZXN0aW9ucyB7XG4gICAgLyogd2lkdGg6IDc4MHB4O1xuICAgIGhlaWdodDogODBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAxOTBweDsgKi9cblxuICB9XG4gIC5DdXJyZW50LXN0YXRlLW9mLU11cm11ciB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICAgIFxuICB9XG5cbiAgLk11cm11ci1pcy1jdXJyZW50bHktcnVubmluZy1vbi10aGUtVGVsb3MtQmxvY2tjaGFpbiB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtNDcge1xuICAgIG1hcmdpbi10b3A6IDM3cHg7XG4gICAgLyogaGVpZ2h0OiA4MHB4OyAqL1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIHdpZHRoOiA5MCU7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAxNXB4OyAqL1xuICAgIG1hcmdpbi1sZWZ0OiA1NHB4O1xuICB9XG5cblxuICAuSG93LWlzLXRoZS1yZXB1dGF0aW9uLXNjb3JlLWNhbGN1bGF0ZWQge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgIFxuICB9XG5cbiAgLldoYXQtaXMtdGhlLWRpZmZlcmVuY2UtYmV0d2Vlbi1NVVItYW5kLURlY2liZWxzLURDQkwge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XaHktdHdvLXRva2VucyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuV2h5LXR3by1wbGF0Zm9ybXMtTVVSLW9uLUV0aGVyZXVtLWFuZC1EZWNpYmVscy1vbi1NYXRpYyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuV2hhdC1hcmUtdGhlLVRva2VuLWVjb25vbWljcy1mb3ItTVVSIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuXG4gIC5XaGF0LWFyZS10aGUtVG9rZW4tZWNvbm9taWNzLWZvci1EZWNpYmVscyB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuSXMtdGhlcmUtYS1EZWNpYmVscy1NVVItcGFpci1Ib3ctZG9lcy10aGUtc3dhcC13b3JrIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2hlcmUtYXJlLW15LXRyYW5zYWN0aW9ucy1zdG9yZWQge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XaGVyZS1hcmUtbXktcHJpdmF0ZS1rZXlzLXN0b3JlZCB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuTG9hZC1tb3JlIHtcbiAgICB3aWR0aDogMTEwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAvKiBjb2xvcjogIzAwMDAwMDsgKi9cbiAgICBwYWRkaW5nLWxlZnQ6IDIwJTtcbiAgfVxuXG5cbiAgLm11cm11ci0wMyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMTIlO1xuICAgIG1hcmdpbi1sZWZ0OiA4JTtcbiAgICBcbiAgfVxuICBcbiAgLkZvcnVtcy1CbG9nLURvY3MtVG9rZW4tRWNvbm9taWNzIHtcbiAgICB3aWR0aDogMzU4cHg7XG4gICAgaGVpZ2h0OiAyNzJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3M6aG92ZXIge1xuICAgIHdpZHRoOiAzNThweDtcbiAgICBoZWlnaHQ6IDI3MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuODtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgXG4gIC5pLW9zIHtcbiAgICB3aWR0aDogMzAlO1xuICAgIGhlaWdodDogNTAlO1xuICAgIHBhZGRpbmctbGVmdDogMThweDtcbiAgICBwYWRkaW5nLXRvcDogMTZweDtcbiAgfVxuXG4gIC5Hb29nbGVQbGF5IHtcbiAgICB3aWR0aDogMzAlO1xuICAgIGhlaWdodDogNTAlO1xuICAgIHBhZGRpbmctbGVmdDogMThweDtcbiAgICBwYWRkaW5nLXRvcDogMTZweDtcbiAgfVxuXG4gIC5NdXJtdXItQWxsLXJpZ2h0cy1yZXNlcnZlZCB7XG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogNS4xNDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgbWFyZ2luLWxlZnQ6IDQlO1xuICAgIG1hcmdpbi10b3A6IDE3JTtcbiAgfVxuXG5cbiAgLlJlY3RhbmdsZS0yNCB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjUge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI2IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICB9XG4gIFxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cbiAgLnRleHQtc3R5bGUtMSB7XG4gICAgLyogd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMTUwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5EZWNpYmVscy1hcmUtZ2l2ZW57XG4gICAgLyogd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMjUwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRGVjaWJlbHMtYXJlLWdpdmVuOmhvdmVye1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICBcblxuXG5cblxuXG4gIC5CdWlsdC1vbi1CbG9ja2NoYWluIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLkN1cnJlbnQtUGFydG5lcnMge1xuICAgIHdpZHRoOiA0NjdweDtcbiAgICBoZWlnaHQ6IDgwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLk11cm11ci1mb3ItbW9iaWxlIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICB9XG5cbiAgLlVzZS1NdXJtdXIge1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS43NTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gIH1cblxuICAuSW1tZWRpYXRlLWJsb2NrY2hhaW4taWQtY3JlYXRpb24tTm8td2FpdC10aW1lIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDI0cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMzM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICB9XG5cbiAgLyogLm1haW5faW1nIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5cbiAgLnJvdGF0ZSB7XG4gICAgYW5pbWF0aW9uOiByb3RhdGlvbiByZWxhdGl2ZTtcbiAgICBhbmltYXRpb24tbmFtZTogcm90YXRpb247XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDQwcHg7XG4gICAgdG9wOiAzNTVweDtcbiAgICAvKiBsZWZ0OiAtMTI1cHg7XG4gICAgdG9wOiAyNzBweDsgKi9cbiAgICB6LWluZGV4OiAtMTtcbiAgICBhbmltYXRpb24tZHVyYXRpb246IDRzO1xuICAgIGFuaW1hdGlvbi1kZWxheTogMXM7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICAvKiB0cmFuc2Zvcm06IHJvdGF0ZVooLTkwZGVnKTsgKi9cbiAgfVxuXG4gIEBrZXlmcmFtZXMgcm90YXRpb24ge1xuICAgIGZyb20ge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGV6KC0xODBkZWcpO1xuICAgICAgbGVmdDogNDBweDtcbiAgICAgIHRvcDogMjVweDtcbiAgICAgIHdpZHRoOiAxMCU7IGhlaWdodDogMTAlO1xuICAgIH1cbiAgICB0byB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooMGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuICB9XG4uc3ViX2ltZ3tcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogLTE7XG4gIGFuaW1hdGlvbi1uYW1lOiBzdWJfaW1nO1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBcbn1cbiAgQGtleWZyYW1lcyBzdWJfaW1nIHtcbiAgICBcbiAgICBmcm9tIHt3aWR0aDogMTAlOyBoZWlnaHQ6IDEwJTt9XG4gICAgdG8geyB3aWR0aDogMTEwJTsgaGVpZ2h0OiAxMTAlO31cbiAgfVxuICAuV2UtYXJlLWltYWdpbmluZyB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMjEwcHg7XG4gICAgb3BhY2l0eTogMC45O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZmZmZmZmO1xuICB9XG5cbiAgLkpvaW4tdGhlLW5ldy13YXktb2YtdGhlLXdvcmxkIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiA2MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI5IHtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YxZjJmOTtcbiAgICB3aWR0aDogNzhweDtcbiAgfVxuICAuUmVjdGFuZ2xlLTI4IHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICNmMWYyZjk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC8qIC5SZWN0YW5nbGUtMzAge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG5cbiAgLlBhdGgtOSB7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH0gKi9cblxuXG4gIC5SZWN0YW5nbGUtMzAge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0zMyB7XG4gICAgXG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMWYyZjk7XG4gICAgd2lkdGg6IDc4cHg7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5QYXRoLTkge1xuICAgIC8qIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7ICovXG4gICAgXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG5cbiAgLlBhdGgtOCB7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIHBhZGRpbmctbGVmdDogNTAlO1xuICB9XG5cbiAgLlRoYW5rcy1vci1zdWJzY3JpYmluZyB7XG4gICAgd2lkdGg6IDIyNHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuNjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDBjZDliO1xuICAgIHBhZGRpbmctbGVmdDogNCU7XG4gIH1cblxuICAuaW5wdXQtZ3JvdXAgPiAuZm9ybS1jb250cm9sOm5vdCg6bGFzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5jdXN0b20tc2VsZWN0Om5vdCg6bGFzdC1jaGlsZCkge1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbn1cblxuLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLWFwcGVuZCA+IC5idG4sIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpub3QoOmZpcnN0LWNoaWxkKSA+IC5pbnB1dC1ncm91cC10ZXh0LCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5idG46bm90KDpmaXJzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOmZpcnN0LWNoaWxkID4gLmlucHV0LWdyb3VwLXRleHQ6bm90KDpmaXJzdC1jaGlsZCkge1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG59XG4gfVxuXG4gQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkgeyBcbiAgLkFib3V0LXVzIHtcbiAgICB3aWR0aDogMjQ4cHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cbiAgXG4gIC5NdXJtdXItYWltcyB7XG4gICAgd2lkdGg6IDQyMHB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5NdXJtdXItYWltczpob3ZlciB7XG4gICAgd2lkdGg6IDQyMHB4O1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIFxuICAuUmVjdGFuZ2xlLTEwIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEwOmhvdmVyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTEge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTExOmhvdmVyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBtYXJnaW4tcmlnaHQ6IDMwcHg7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICAgIHBhZGRpbmctdG9wOiAxN3B4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEyOmhvdmVyIHtcbiAgICB3aWR0aDogMTk1cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOndoaXRlO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogMTdweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIHBhZGRpbmctbGVmdDogMTMlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMjAlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIGNvbG9yOiAjMDAwMDAwOyAqL1xuICB9XG5cblxuICAuSG93LWRvLXdlLXJld2FyZC11c2VycyB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMTUwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5UaGlzLWlzLXdoZXJle1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlRoaXMtaXMtd2hlcmU6aG92ZXJ7XG4gICAgLyogd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMjUwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVhZC1Nb3JlIHtcbiAgICAvKiB3aWR0aDogMTEwcHg7XG4gIGhlaWdodDogMjhweDsgKi9cbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiAjODA2OWZmO1xuICBwYWRkaW5nLXRvcDogNTBweDtcbn1cbiAgLm11cm11ci1yZXdhcmRzX1ByYW5jaGV0YS0xLWNvcHkge1xuICAgIHdpZHRoOjEwMCU7XG4gICAgaGVpZ2h0OjEwMCU7XG4gICBcbiAgfVxuXG4gIC5EZXZlbG9wbWVudC1QYXJ0bmVycyB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIC8qIGhlaWdodDogMTUwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLmRvd25sb2FkIHtcbiAgICB3aWR0aDogNjclO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICB9XG5cbiAgLkNoYWluZmx1eC1pcy1hbi1lbmQge1xuICAgIHdpZHRoOiA0MjhweDtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5DaGFpbmZsdXgtaXMtYW4tZW5kOmhvdmVyIHtcbiAgICB3aWR0aDogNDI4cHg7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuVmlzaXQtU2l0ZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLlRvdGFsLXN1cHBseS0xYmlsbGlvbi1EZWNpYmVscyB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogMTUwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG5cbiAgLlJvYWRtYXAtdG8tbGF1bmNoIHtcbiAgICB3aWR0aDogNTUycHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAubXVybXVyLXJld2FyZHMtMDMge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICAvKiBtYXJnaW4tbGVmdDogNzJweDsgKi9cbiAgICBtYXJnaW4tdG9wOiA4JTtcbiAgICBtYXJnaW4tYm90dG9tOiAxMiU7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIG92ZXJmbG93LXg6YXV0bztcbiAgICBvdmVyZmxvdy15OmF1dG87XG4gIH1cblxuICAuUmVjdGFuZ2xlLTQwIHtcbiAgIFxuICAgIHBhZGRpbmctYm90dG9tOiAxMCU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLXRvcDogMiU7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTQ2IHtcbiAgIFxuICAgIC8qIGhlaWdodDogMTQ1cHg7ICovXG4gICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gICAgd2lkdGg6IDkwJTtcbiAgICAvKiBwYWRkaW5nLWxlZnQ6IDE1cHg7ICovXG4gICAgbWFyZ2luLWxlZnQ6IDU0cHg7XG4gIH1cblxuICAuRnJlcXVlbnRseS1hc2tlZC1RdWVzdGlvbnMge1xuICAgIC8qIHdpZHRoOiA3ODBweDtcbiAgICBoZWlnaHQ6IDgwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIC8qIHBhZGRpbmctbGVmdDogMTkwcHg7ICovXG5cbiAgfVxuICAuQ3VycmVudC1zdGF0ZS1vZi1NdXJtdXIge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgICBcbiAgfVxuXG4gIC5NdXJtdXItaXMtY3VycmVudGx5LXJ1bm5pbmctb24tdGhlLVRlbG9zLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgXG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTQ3IHtcbiAgICBtYXJnaW4tdG9wOiAzN3B4O1xuICAgIC8qIGhlaWdodDogODBweDsgKi9cbiAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogOTAlO1xuICAgIC8qIHBhZGRpbmctbGVmdDogMTVweDsgKi9cbiAgICBtYXJnaW4tbGVmdDogNTRweDtcbiAgfVxuXG5cbiAgLkhvdy1pcy10aGUtcmVwdXRhdGlvbi1zY29yZS1jYWxjdWxhdGVkIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICBcbiAgfVxuXG4gIC5XaGF0LWlzLXRoZS1kaWZmZXJlbmNlLWJldHdlZW4tTVVSLWFuZC1EZWNpYmVscy1EQ0JMIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2h5LXR3by10b2tlbnMge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG5cbiAgLldoeS10d28tcGxhdGZvcm1zLU1VUi1vbi1FdGhlcmV1bS1hbmQtRGVjaWJlbHMtb24tTWF0aWMge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG5cbiAgLldoYXQtYXJlLXRoZS1Ub2tlbi1lY29ub21pY3MtZm9yLU1VUiB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cblxuICAuV2hhdC1hcmUtdGhlLVRva2VuLWVjb25vbWljcy1mb3ItRGVjaWJlbHMge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG5cbiAgLklzLXRoZXJlLWEtRGVjaWJlbHMtTVVSLXBhaXItSG93LWRvZXMtdGhlLXN3YXAtd29yayB7XG4gICAgd2lkdGg6IDEwMTNweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLldoZXJlLWFyZS1teS10cmFuc2FjdGlvbnMtc3RvcmVkIHtcbiAgICB3aWR0aDogMTAxM3B4O1xuICAgIGhlaWdodDogNDVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2hlcmUtYXJlLW15LXByaXZhdGUta2V5cy1zdG9yZWQge1xuICAgIHdpZHRoOiAxMDEzcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG5cbiAgLkxvYWQtbW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gICAgcGFkZGluZy1sZWZ0OiAyMCU7XG4gIH1cblxuXG4gIC5tdXJtdXItMDMge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTEyJTtcbiAgICBtYXJnaW4tbGVmdDogOCU7XG4gICAgXG4gIH1cbiAgXG4gIC5Gb3J1bXMtQmxvZy1Eb2NzLVRva2VuLUVjb25vbWljcyB7XG4gICAgd2lkdGg6IDM1OHB4O1xuICAgIGhlaWdodDogMjcycHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS44O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLkZvcnVtcy1CbG9nLURvY3MtVG9rZW4tRWNvbm9taWNzOmhvdmVyIHtcbiAgICB3aWR0aDogMzU4cHg7XG4gICAgaGVpZ2h0OiAyNzJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIFxuICAuaS1vcyB7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBoZWlnaHQ6IDUwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHg7XG4gICAgcGFkZGluZy10b3A6IDE2cHg7XG4gIH1cblxuICAuR29vZ2xlUGxheSB7XG4gICAgd2lkdGg6IDMwJTtcbiAgICBoZWlnaHQ6IDUwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDE4cHg7XG4gICAgcGFkZGluZy10b3A6IDE2cHg7XG4gIH1cblxuICAuTXVybXVyLUFsbC1yaWdodHMtcmVzZXJ2ZWQge1xuICAgIGhlaWdodDogMjBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDUuMTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIG1hcmdpbi1sZWZ0OiA0JTtcbiAgICBtYXJnaW4tdG9wOiAxNyU7XG4gIH1cblxuXG4gIC5SZWN0YW5nbGUtMjQge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI1IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNiB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwY2Q5YjtcbiAgfVxuICBcblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG5cblxuXG4gIC50ZXh0LXN0eWxlLTEge1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDE1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuRGVjaWJlbHMtYXJlLWdpdmVue1xuICAgIC8qIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDI1MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLkRlY2liZWxzLWFyZS1naXZlbjpob3ZlcntcbiAgICAvKiB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgXG5cblxuXG5cblxuICAuQnVpbHQtb24tQmxvY2tjaGFpbiB7XG4gICAgd2lkdGg6IDMwNHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5DdXJyZW50LVBhcnRuZXJzIHtcbiAgICB3aWR0aDogNDY3cHg7XG4gICAgaGVpZ2h0OiA4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5NdXJtdXItZm9yLW1vYmlsZSB7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA1NHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgfVxuXG4gIC5Vc2UtTXVybXVyIHtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNzU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICB9XG5cbiAgLkltbWVkaWF0ZS1ibG9ja2NoYWluLWlkLWNyZWF0aW9uLU5vLXdhaXQtdGltZSB7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjMzO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgfVxuXG4gIC8qIC5tYWluX2ltZyB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfSAqL1xuXG4gIC5yb3RhdGUge1xuICAgIGFuaW1hdGlvbjogcm90YXRpb24gcmVsYXRpdmU7XG4gICAgYW5pbWF0aW9uLW5hbWU6IHJvdGF0aW9uO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiA0MHB4O1xuICAgIHRvcDogMzU1cHg7XG4gICAgLyogbGVmdDogLTEyNXB4O1xuICAgIHRvcDogMjcwcHg7ICovXG4gICAgei1pbmRleDogLTE7XG4gICAgYW5pbWF0aW9uLWR1cmF0aW9uOiA0cztcbiAgICBhbmltYXRpb24tZGVsYXk6IDFzO1xuICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7XG4gICAgLyogdHJhbnNmb3JtOiByb3RhdGVaKC05MGRlZyk7ICovXG4gIH1cblxuICBAa2V5ZnJhbWVzIHJvdGF0aW9uIHtcbiAgICBmcm9tIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRleigtMTgwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICB3aWR0aDogMTAlOyBoZWlnaHQ6IDEwJTtcbiAgICB9XG4gICAgdG8ge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGVaKDBkZWcpO1xuICAgICAgbGVmdDogNDBweDtcbiAgICAgIHRvcDogMjVweDtcbiAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIH1cbiAgfVxuLnN1Yl9pbWd7XG4gIGFuaW1hdGlvbi1uYW1lOiBzdWJfaW1nO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IC0xO1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgYW5pbWF0aW9uLWR1cmF0aW9uOiAzcztcbiAgXG59XG4gIEBrZXlmcmFtZXMgc3ViX2ltZyB7XG4gICAgXG4gICAgZnJvbSB7d2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7fVxuICAgIHRvIHsgd2lkdGg6IDExMCU7IGhlaWdodDogMTEwJTt9XG4gIH1cbiAgLldlLWFyZS1pbWFnaW5pbmcge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDIxMHB4O1xuICAgIG9wYWNpdHk6IDAuOTtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2ZmZmZmZjtcbiAgfVxuXG4gIC5Kb2luLXRoZS1uZXctd2F5LW9mLXRoZS13b3JsZCB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDBjZDliO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yOSB7XG4gICAgaGVpZ2h0OiA4NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMWYyZjk7XG4gICAgd2lkdGg6IDc4cHg7XG4gIH1cbiAgLlJlY3RhbmdsZS0yOCB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIGhlaWdodDogODVweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjZjFmMmY5O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAvKiAuUmVjdGFuZ2xlLTMwIHtcbiAgICBcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwY2Q5YjtcbiAgICB3aWR0aDogNzhweDtcbiAgfVxuXG4gIC5QYXRoLTkge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9ICovXG5cblxuICAuUmVjdGFuZ2xlLTMwIHtcbiAgICBcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwY2Q5YjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMzMge1xuICAgIFxuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiAjMDBjZDliO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUGF0aC05IHtcbiAgICAvKiBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4OyAqL1xuICAgIFxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxuXG4gIC5QYXRoLTgge1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDUwJTtcbiAgfVxuXG4gIC5UaGFua3Mtb3Itc3Vic2NyaWJpbmcge1xuICAgIHdpZHRoOiAyMjRweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjY1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwY2Q5YjtcbiAgICBwYWRkaW5nLWxlZnQ6IDQlO1xuICB9XG5cbiAgLmlucHV0LWdyb3VwID4gLmZvcm0tY29udHJvbDpub3QoOmxhc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuY3VzdG9tLXNlbGVjdDpub3QoOmxhc3QtY2hpbGQpIHtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG59XG5cbi5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtYXBwZW5kID4gLmlucHV0LWdyb3VwLXRleHQsIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmJ0biwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6Zmlyc3QtY2hpbGQgPiAuYnRuOm5vdCg6Zmlyc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5pbnB1dC1ncm91cC10ZXh0Om5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xufVxuIH0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AboutusComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-aboutus',
            templateUrl: './aboutus.component.html',
            styleUrls: ['./aboutus.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "./src/app/component/home/home.component.ts":
    /*!**************************************************!*\
      !*** ./src/app/component/home/home.component.ts ***!
      \**************************************************/

    /*! exports provided: HomeComponent */

    /***/
    function srcAppComponentHomeHomeComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomeComponent", function () {
        return HomeComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

      function HomeComponent_div_182_input_1_Template(rf, ctx) {
        if (rf & 1) {
          var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 84);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_182_input_1_Template_input_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);

            var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r6.iconchange();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("placeholder", ctx_r2.subscribe);
        }
      }

      function HomeComponent_div_182_input_2_Template(rf, ctx) {
        if (rf & 1) {
          var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "input", 85);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_182_input_2_Template_input_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);

            var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r8.iconchange();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("placeholder", ctx_r3.subscribe);
        }
      }

      function HomeComponent_div_182_div_4_Template(rf, ctx) {
        if (rf & 1) {
          var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 86);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_182_div_4_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);

            var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r10.twitter();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 87);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function HomeComponent_div_182_div_5_Template(rf, ctx) {
        if (rf & 1) {
          var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 88);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_182_div_5_Template_div_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);

            var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r12.twitter();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 87);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "br");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function HomeComponent_div_182_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 78);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, HomeComponent_div_182_input_1_Template, 1, 1, "input", 79);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, HomeComponent_div_182_input_2_Template, 1, 1, "input", 80);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 81);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, HomeComponent_div_182_div_4_Template, 3, 0, "div", 82);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, HomeComponent_div_182_div_5_Template, 3, 0, "div", 83);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.iconstatus);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.iconstatus);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.iconstatus);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.iconstatus);
        }
      }

      function HomeComponent_div_183_Template(rf, ctx) {
        if (rf & 1) {
          var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 78);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 89);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HomeComponent_div_183_Template_div_click_1_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15);

            var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r14.statuschange();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 90);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Thanks or subscribing!");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i", 91);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var HomeComponent = /*#__PURE__*/function () {
        function HomeComponent() {
          _classCallCheck(this, HomeComponent);

          this.subscribe = "subscribe";
          this.status = false;
          this.iconstatus = false;
        }

        _createClass(HomeComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "twitter",
          value: function twitter() {
            this.status = true;
          }
        }, {
          key: "statuschange",
          value: function statuschange() {
            this.status = false;
            this.iconstatus = false;
          }
        }, {
          key: "iconchange",
          value: function iconchange() {
            this.iconstatus = true;
          }
        }]);

        return HomeComponent;
      }();

      HomeComponent.ɵfac = function HomeComponent_Factory(t) {
        return new (t || HomeComponent)();
      };

      HomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: HomeComponent,
        selectors: [["app-home"]],
        decls: 210,
        vars: 2,
        consts: [[1, "container-fluid"], [1, "container-sm"], [1, "row", "rewarding"], [1, "col-sm-5"], [1, "row"], [1, "The-most-rewarding-social-media-platform"], [1, "Murmur-is-everything"], [1, "row", 2, "padding-top", "5%"], [1, "Rectangle-11"], [1, "Download-App"], [1, "Rectangle-10"], [1, "Learn-more"], [1, "col-sm-7", "murmurimg1"], ["src", "../assets/images/murmur hompeage main illus.png", 1, "murmur-02"], [1, "container-fluid", 2, "background-color", "#f1f2f9", "padding-top", "2%"], [1, "container-sm", 2, "padding-top", "10%"], [1, "col-sm-4"], ["src", "../assets/images/icons-05.png", 1, "icons-05"], [1, "col-sm-8", "murmur2"], [1, "Why-Murmur"], [1, "We-believe"], ["href", "#", 1, "Read-More"], [1, "row", "murmur3"], [1, "col-sm-3"], [1, "row", "Built-on-Blockchain"], [1, "col-sm-12"], [1, "row", "Murmur-is-a-rewarding", 2, "padding-top", "5%"], [1, "text-style-1"], [1, "col-sm-1"], [1, "row", 2, "padding-top", "10%"], ["src", "../assets/images/user rewards_Prancheta 1 copy.png", "width", "100%", "height", "105%", 1, "rewardimg"], [1, "col-sm-7"], [1, "row", "Rewarding-to-use"], [1, "Publishing-and-engaging", 2, "padding-top", "5%"], [1, "Rectangle-63"], [1, "row", "justify-content-center", 2, "padding-top", "10%", "text-align", "center"], [1, "col-sm-12", "Current-Partners"], [1, "row", 2, "align-items", "center", "text-align", "center", "padding-bottom", "8%"], ["src", "../assets/images/l 2.png", 1, "matic"], ["src", "../assets/images/l1.png", 1, "bicon"], ["id", "carouselExampleIndicators", "data-ride", "carousel", 1, "carousel", "slide"], [1, "carousel-indicators"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "0", 1, "active"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "1"], ["data-target", "#carouselExampleIndicators", "data-slide-to", "2"], [1, "carousel-inner"], [1, "carousel-item", "active", "Rectangle-24"], [1, "container-sm", "col-sm-4"], ["src", "../assets/images/icons-06 b.png", 1, "icons-06"], [1, "container-sm", "col-sm-2"], ["src", "../assets/images/icons-07.png", 1, "icons7"], [1, "col-sm-6"], [1, "Murmur-for-mobile"], [1, "Use-Murmur"], [1, "Immediate-blockchain-id-creation-No-wait-time"], [1, "No-wait-time"], ["src", "../assets/images/i os.png", 1, "i-os1"], ["src", "../assets/images/Google+Play.png", 1, "GooglePlay1"], [1, "carousel-item", "Rectangle-25"], ["src", "../assets/images/icons-06 c.png", 1, "icons-06"], ["src", "../assets/images/icons-09.png", 1, "icons8"], [1, "carousel-item", "Rectangle-26"], ["src", "../assets/images/icons-06 a.png", 1, "icons-06"], ["src", "../assets/images/icons-08.png", 1, "icons9"], [1, "container-fluid", 2, "padding-top", "2%", "padding-bottom", "10%"], [1, "container", 2, "padding-top", "10%"], [1, "We-are-imagining"], [1, "col-sm-2"], [1, "row", 2, "padding-top", "2%"], [1, "Join-the-new-way-of-the-world"], ["src", "../assets/images/Path 8.png", 1, "path8"], ["class", "input-group mb-3 subcribe", 4, "ngIf"], [1, "container-fluid", 2, "padding-top", "10%"], ["src", "../assets/images/about us@2x.png", 1, "murmur-03"], [1, "Forums-Blog-Docs-Token-Economics"], ["src", "../assets/images/Google+Play.png", 1, "GooglePlay"], ["src", "../assets/images/i os.png", 1, "i-os"], [1, "Murmur-All-rights-reserved"], [1, "input-group", "mb-3", "subcribe"], ["type", "text", "class", "form-control Rectangle-29", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 3, "placeholder", "click", 4, "ngIf"], ["type", "text", "class", "form-control Rectangle-31", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 3, "placeholder", "click", 4, "ngIf"], [1, "input-group-append"], ["class", "input-group-text Rectangle-30", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["class", "input-group-text Rectangle-33", "id", "basic-addon2", 3, "click", 4, "ngIf"], ["type", "text", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 1, "form-control", "Rectangle-29", 3, "placeholder", "click"], ["type", "text", "aria-label", "Subscribe", "aria-describedby", "Subscribe", 1, "form-control", "Rectangle-31", 3, "placeholder", "click"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-30", 3, "click"], [1, "fa", "fa-paper-plane", "Path-9"], ["id", "basic-addon2", 1, "input-group-text", "Rectangle-33", 3, "click"], [1, "Rectangle-28", 3, "click"], [1, "Thanks-or-subscribing"], [1, "fa", "fa-paper-plane", "Path-8"]],
        template: function HomeComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "The most rewarding social media platform");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Decibel is everything that social media can be - transparent, trustworthy, and most of all, rewarding to use. On Decibel, you are in charge of your data and your content, and everything action you do translates into unique rewards. That range from tokens to trust scores.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Download App");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "span", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Learn more");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "img", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "img", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 19);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Why Decibel?");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "p", 20);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "We believe that social media users deserve more from their platforms; that sharing just what\u2019s on your mind and engaging with others should not only be refreshing but also truly valuable. Other networks make money from your data, manipulate what you ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "a", 21);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Read More");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 22);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "Built on Blockchain");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Decibel is a rewarding decentralized social media platform which was built on the Telos Blockchain, but is now porting over to the Matic Blockchain ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "span", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "matic.network.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, " This means that Decibel is transparent, less corruptible, and governed by the community.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Supports privacy");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "To connect to Decibel, all you need is a unique Ethereum address, which can be generated for free on the Decibel mobile app or on a chrome extension like ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "span", 27);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "metamask.io.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, " Once activated, all your actions and rewards will be traceable to this identity and this alone.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 24);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](63, "Easy to get started");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "div", 26);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "While built on blockchain, using Decibel is straight-forward and clear. It\u2019s like any other microblogging platform, but supports 256 characters\u2019 worth of text, content tagging, tipping feature, and unique actions like murmur, snoop, yell, and whisper.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 29);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](69, "div", 28);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "div", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](71, "img", 30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 32);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](75, "Rewarding to use");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 33);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "p");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](78, "Publishing and engaging with content published by your peers earn you Decibel points. These points are converted into Matic Blockchain tokens weekly. Your actions also culminate in a Trust Score* that reliably points to your trustworthiness in the ecosystem.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](79, "div", 34);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "div", 35);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "h1", 36);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, "Current Partners");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "div", 37);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](86, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](88, "img", 38);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](90, "img", 39);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](91, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 40);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "ol", 41);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](94, "li", 42);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](95, "li", 43);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](96, "li", 44);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "div", 45);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "div", 46);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](102, "img", 48);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "div", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](104, "img", 50);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "h2", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](108, "Decibel for mobile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "p", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](111, "Use Decibel on-the-go with your mobile phone. DecibelDapp for Android and iOS devices offer the same capabilities as the Decibel web platform, with three major differences:");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "p", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](114, "Immediate blockchain id creation.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "p", 55);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](116, "No wait time!");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](118, "img", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](119, "img", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "div", 58);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](123, "div", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](124, "img", 59);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "div", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](126, "img", 60);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "div", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "h2", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](130, "Decibel for mobile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](131, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "p", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](133, "Use Decibel on-the-go with your mobile phone. DecibelDapp for Android and iOS devices offer the same capabilities as the Decibel web platform, with three major differences:");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "p", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](136, "Easy to use EOS/Telos token wallet for token transfers, tips, and redemption");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](138, "img", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](139, "img", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](140, "div", 61);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 47);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](144, "img", 62);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "div", 49);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](146, "img", 63);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "div", 51);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](149, "h2", 52);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](150, "Decibel for mobile");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "p", 53);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](153, "Use Decibel on-the-go with your mobile phone. DecibelDapp for Android and iOS devices offer the same capabilities as the Decibel web platform, with three major differences:");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "p", 54);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](156, "Keep your profile information private. Verify your profile as human/bot without revealing your identity.");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "div", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](158, "img", 56);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](159, "img", 57);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "div", 64);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](161, "div", 65);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](163, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](164, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](165, "span", 66);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](166, " We are imagining a world where social media is trustworthy, rewarding and liberating. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](167, "div", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](168, "div", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](169, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](170, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](171, "span", 69);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](172, " Join the new way of the world! ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](173, "div", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](174, "div", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](175, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](176, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](177, "img", 70);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](178, "div", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](179, "div", 68);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](180, "div", 23);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](181, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](182, HomeComponent_div_182_Template, 6, 4, "div", 71);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](183, HomeComponent_div_183_Template, 5, 0, "div", 71);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](184, "div", 67);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](185, "div", 72);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](186, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](187, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](188, "div", 31);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](189, "img", 73);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](190, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](191, "span", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](192, " Forums ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](193, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](194, "span", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](195, "Blog");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](196, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](197, "span", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](198, "Docs");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](199, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](200, "span", 74);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](201, "Token Economics");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](202, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](203, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](204, "img", 75);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](205, "img", 76);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](206, "div", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](207, "span", 77);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](208, " \xA9 2020 Decibel. All rights reserved. ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](209, "br");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](182);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.status);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"]],
        styles: ["@media only screen and (min-width: 1200px) {\n  .rewarding[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-bottom: 5%;\n    padding-left: 40px;\n  }\n\n  .murmur2[_ngcontent-%COMP%]\n  {\n    padding-left: 127px;\n  }\n\n  .murmur3[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-left: 40px;\n  }\n  .murmurimg1[_ngcontent-%COMP%]\n  {\n    margin-top: -100px;\n  }\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 625px;\n  \n  font-family: Poppins;\n  font-size: 35px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.3;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 580px;\n    \n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]:hover{\n    width: 580px;\n    \n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .murmur-02[_ngcontent-%COMP%] {\n    width: 127%;\n    height: 100%;\n    margin-left: -78px;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 149px;\n    height: 52px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 149px;\n    height: 52px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 149px;\n    height: 52px;\n    background-color: #8069ff;\n    color: black;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 149px;\n    height: 52px;\n    background-color: black;\n    color: white;\n    margin-right: 30px;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 14px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  \n  padding-left: 16%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 14px;\n  font-family: Poppins;\n  font-size: 14px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 24%;\n  cursor: pointer;\n  \n  }\n\n\n  \n\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .We-believe[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .We-believe[_ngcontent-%COMP%]:hover {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .icons-05[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100%;\n    margin-left: 20px;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n.rewardimg[_ngcontent-%COMP%]\n{\n  width:100%; \n  height:105%;\n}\n  .Rewarding-to-use[_ngcontent-%COMP%] {\n    \n    height: 65px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%] {\n    \n    height: 125px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%]:hover {\n    \n    height: 125px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  \n  .Rectangle-63[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 220px;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n    cursor: pointer;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]:hover {\n    width: 304px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]   .text-style-1[_ngcontent-%COMP%] {\n    color: #8069ff;\n  }\n  \n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;  \n  }\n\n  .matic[_ngcontent-%COMP%]\n  {\n    width:100%;\n    height:100%;\n  }\n\n  .bicon[_ngcontent-%COMP%]\n  {\n    width:100%;\n    height:100%;\n  }\n  .icons-06[_ngcontent-%COMP%] {\n    width: 200%;\n    height: 100%;\n    margin-top: 23px;\n    margin-left: -40%;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 180px;\n  }\n\n  \n  .Use-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 5%;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    width: 540px;\n    \n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 5%;\n  }\n\n  .No-wait-time[_ngcontent-%COMP%] {\n    width: 540px;\n    \n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    \n  }\n  \n\n  .i-os1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n    margin-right: 30px;\n  }\n\n  .GooglePlay1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n  }\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .path8[_ngcontent-%COMP%]\n  {\n    width:95%\n  }\n\n  .subcribe[_ngcontent-%COMP%]\n  {\n    width:95%\n  }\n\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    \n    height: 85px;\n    background-color: #8069ff;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n  .Rectangle-31[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #ffffff;\n    width: 78px;\n  }\n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    \n    height: 85px;\n    background-color: #ffffff;\n    width: 78px;\n    color: #8069ff;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n \n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n\n  .icons7[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 129%;\n    margin-left: 3%;\n  }\n\n  .icons8[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 105%;\n    margin-left: 3%;\n  }\n\n  .icons9[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 98%;\n    margin-left: -5%;\n  }\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n\n  .input-container[_ngcontent-%COMP%] { \n    display: flex;\n    width: 100%;\n    margin-bottom: 15px;\n  }\n  \n  .icon[_ngcontent-%COMP%] {\n    padding: 10px;\n    background: dodgerblue;\n    color: white;\n    min-width: 50px;\n    text-align: center;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n    border-right-color:#ffffff;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n  border-left-color:#ffffff;\n}\n}\n\n@media only screen and (max-width: 1024px) {\n  .rewarding[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-bottom: 5%;\n    padding-left: 40px;\n  }\n\n  .murmur2[_ngcontent-%COMP%]\n  {\n    padding-left: 127px;\n  }\n\n  .murmur3[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-left: 40px;\n  }\n  .murmurimg1[_ngcontent-%COMP%]\n  {\n    margin-top: -100px;\n  }\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 625px;\n  \n  font-family: Poppins;\n  font-size: 35px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.3;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 580px;\n    \n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]:hover{\n    width: 580px;\n    \n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.94;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .murmur-02[_ngcontent-%COMP%] {\n    width: 127%;\n    height: 100%;\n    margin-left: -89px;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 149px;\n    height: 52px;\n    background-color: #fcc13c;\n    padding-top: 4%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 149px;\n    height: 52px;\n    background-color: black;\n    color: white;\n    padding-top: 4%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 149px;\n    height: 52px;\n    background-color: #8069ff;\n    color: black;\n    margin-right: 30px;\n    padding-top: 4%;\n    cursor: pointer;\n  }\n\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 149px;\n    height: 52px;\n    background-color: black;\n    color: white;\n    margin-right: 30px;\n    padding-top: 4%;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 14px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  \n  padding-left: 16%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 115px;\n  height: 14px;\n  font-family: Poppins;\n  font-size: 14px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.5;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 24%;\n  cursor: pointer;\n  \n  }\n\n\n  \n\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .We-believe[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .We-believe[_ngcontent-%COMP%]:hover {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  \n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.05;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .icons-05[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100%;\n    margin-left: 20px;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n    .rewardimg[_ngcontent-%COMP%]\n    {\n      width:100%; \n      height:140%;\n    }\n\n  .Rewarding-to-use[_ngcontent-%COMP%] {\n    \n    height: 65px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%] {\n    \n    height: 125px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%]:hover {\n    \n    height: 125px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  \n  .Rectangle-63[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 220px;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 304px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n    cursor: pointer;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]:hover {\n    width: 304px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    padding-left: 15px;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]   .text-style-1[_ngcontent-%COMP%] {\n    color: #8069ff;\n  }\n  \n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 467px;\n    height: 80px;\n    font-family: Poppins;\n    font-size: 54px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;  \n  }\n\n  .matic[_ngcontent-%COMP%]\n  {\n    width:100%;\n    height:100%;\n  }\n\n  .bicon[_ngcontent-%COMP%]\n  {\n    width:100%;\n    height:100%;\n  }\n  .icons-06[_ngcontent-%COMP%] {\n    width: 200%;\n    height: 100%;\n    margin-top: 60px;\n    margin-left: -40%;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 51px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.3;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 180px;\n  }\n\n  \n  .Use-Murmur[_ngcontent-%COMP%] {\n    width: 625px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.75;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 5%;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    width: 540px;\n    \n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    padding-top: 5%;\n  }\n\n  .No-wait-time[_ngcontent-%COMP%] {\n    width: 540px;\n    \n    font-family: Poppins;\n    font-size: 24px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.33;\n    letter-spacing: normal;\n    text-align: left;\n    color: #f1f2f9;\n    \n  }\n  \n\n  .i-os1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n    margin-right: 30px;\n  }\n\n  .GooglePlay1[_ngcontent-%COMP%] {\n    width: 33%;\n    height: 33%;\n  }\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 210px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 60px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n  .path8[_ngcontent-%COMP%]\n  {\n    width:95%\n  }\n\n  .subcribe[_ngcontent-%COMP%]\n  {\n    width:95%\n  }\n\n  .Rectangle-29[_ngcontent-%COMP%] {\n    height: 85px;\n    background-color: #f1f2f9;\n    width: 78px;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 625px;\n    height: 85px;\n    border: solid 1px #f1f2f9;\n    background-color: #ffffff;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    \n    \n    height: 85px;\n    background-color: #8069ff;\n    width: 78px;\n    color: white;\n    font-size: 28px;\n    cursor: pointer;\n  }\n  .Rectangle-31[_ngcontent-%COMP%] {\n    \n    height: 85px;\n    background-color: #ffffff;\n    width: 78px;\n  }\n  .Rectangle-33[_ngcontent-%COMP%] {\n    \n    \n    height: 85px;\n    background-color: #ffffff;\n    width: 78px;\n    color: #8069ff;\n    font-size: 28px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    padding-left: 10px;\n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 28px;\n    padding-left: 50%;\n  }\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 112%;\n    margin-left: 8%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    cursor: pointer;\n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 358px;\n    height: 272px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.8;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n \n  .i-os[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 30%;\n    height: 50%;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    margin-left: 4%;\n    margin-top: 17%;\n  }\n\n  .icons7[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 165%;\n    margin-left: -10%;\n  }\n\n  .icons8[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 165%;\n    margin-left: -10%;\n  }\n\n  .icons9[_ngcontent-%COMP%]\n  {\n    width: 100%;\n    padding-top: 150%;\n    margin-left: -10%;\n  }\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 800px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n\n  .input-container[_ngcontent-%COMP%] { \n    display: flex;\n    width: 100%;\n    margin-bottom: 15px;\n  }\n  \n  .icon[_ngcontent-%COMP%] {\n    padding: 10px;\n    background: dodgerblue;\n    color: white;\n    min-width: 50px;\n    text-align: center;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n    border-right-color:#ffffff;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n  border-left-color:#ffffff;\n}\n}\n\n@media only screen and (max-width: 600px) {\n  .rewarding[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-bottom: 5%;\n    padding-left: 5%;\n  }\n\n  .murmur2[_ngcontent-%COMP%]\n  {\n    padding-left: 15%;\n  }\n  .murmur3[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-left: 5%;\n  }\n\n  .murmurimg1[_ngcontent-%COMP%]\n  {\n    margin-top: -20px;\n  }\n\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 215px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 344px;\n    height: 175px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]:hover{\n    width: 344px;\n    height: 175px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .murmur-02[_ngcontent-%COMP%] {\n    \n    width: 127%;\n    height: 100%;\n    margin-left: -59px;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 145px;\n    height: 45px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 145px;\n    height: 45px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 145px;\n    height: 45px;\n    background-color: #8069ff;\n    margin-right: 6%;\n    margin-left: 5%;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 145px;\n    height: 45px;\n    background-color: black;\n    color: white;\n    margin-right: 6%;\n    margin-left: 5%;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 119px;\n    height: 21px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    \n    padding-left: 10%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 93px;\n  height: 21px;\n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 20%;\n  cursor: pointer;\n  \n  }\n\n  \n\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 300px;\n    height: 115px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    margin-top: 10%;\n  }\n\n  .We-believe[_ngcontent-%COMP%] {\n    width: 342px;\n  \n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  }\n\n  .We-believe[_ngcontent-%COMP%]:hover {\n    width: 342px;\n  \n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  text-decoration: underline;\n  -webkit-text-decoration-color: #8069ff;\n          text-decoration-color: #8069ff;\n  text-underline-position: under;\n  cursor: pointer;\n  }\n\n  \n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #8069ff;\n  }\n\n  .icons-05[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100%;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 304px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 15%;\n    \n    margin-top: 16%;\n  }\n\n  .rewardimg[_ngcontent-%COMP%]\n{\n  width:100%; \n  height:105%;\n}\n  .Rewarding-to-use[_ngcontent-%COMP%] {\n    \n    width: 341px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 10%;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%] {\n    \n    width: 330px;\n    height: 212px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 5%;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%]:hover {\n    \n    width: 330px;\n    height: 212px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 5%;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .Rectangle-63[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100px;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 190px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 15px;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]:hover {\n    width: 343px;\n    height: 190px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 15px;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]   .text-style-1[_ngcontent-%COMP%] {\n    color: #8069ff;\n  }\n  \n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 115px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;  \n    margin-top: 100px;\n  }\n\n  .matic[_ngcontent-%COMP%]\n  {\n    width: 196px;\n    height: 75px;\n  }\n\n  .bicon[_ngcontent-%COMP%]\n  {\n    width: 253px;\n  height: 75px;\n  margin-bottom: 95px;\n\n  }\n  .icons-06[_ngcontent-%COMP%] {\n    \n    width: 566px;\n    height: 529px;\n    margin-left: -77px;\n\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 120px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 66px;\n    padding-top: 0px;\n  }\n\n  \n  .Use-Murmur[_ngcontent-%COMP%] {\n    width: 377px;\n    height: 162px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 37px;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    width: 385px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 35px;\n  }\n\n  .No-wait-time[_ngcontent-%COMP%] {\n    width: 385px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 6px;\n    \n  }\n  \n\n  .i-os1[_ngcontent-%COMP%] {\n    width: 150px;\n    height: 45px;\n    margin-left: 54px;\n    \n    margin-right: 8px;\n  }\n\n  .GooglePlay1[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 45px;\n  }\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 361px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 159px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .path8[_ngcontent-%COMP%]\n  {\n    width: 342.5px;\n    height: 32.9px;\n  \n  }\n\n  .subcribe[_ngcontent-%COMP%]\n  {\n    width: 343px;\n  }\n  .Rectangle-29[_ngcontent-%COMP%] {\n    \n  height: 47px;\n  background-color: #f1f2f9;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 47px;\n    background-color: #ffffff;\n    border: solid 1px #f1f2f9;\n    \n    padding-top: 0%;\n    cursor: pointer;\n  }\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    width: 47px;\n    height: 47px;\n    background-color: #8069ff;\n    width: 78px;\n    color: white;\n    font-size: 20px;\n    cursor: pointer;\n  }\n  .Rectangle-31[_ngcontent-%COMP%] {\n   \n    height: 47px;\n    background-color: #ffffff;\n  }\n  .Rectangle-33[_ngcontent-%COMP%] {\n    width: 47px;\n    height: 47px;\n    background-color: #ffffff;\n    width: 78px;\n    color: #8069ff;\n    font-size: 20px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    \n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 20px;\n    padding-left: 19%;\n  }\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 115%;\n    height: 100%;\n    margin-left: -7%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 323px;\n  height: 267px;\n  font-family: Poppins;\n  font-size: 36px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  }\n\n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 323px;\n  height: 267px;\n  font-family: Poppins;\n  font-size: 36px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  text-decoration: underline;\n  -webkit-text-decoration-color: #8069ff;\n          text-decoration-color: #8069ff;\n  text-underline-position: under;\n  cursor: pointer;\n  }\n  \n  .i-os[_ngcontent-%COMP%] {\n    width: 165px;\n    height: 60px;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 165px;\n    height: 60px;\n    padding-left: 18px;\n    padding-top: 16px;\n    \n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    \n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;  \n    padding-left: 52px;\n    margin-bottom: 40px;\n  }\n\n  .icons7[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .icons8[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .icons9[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    \n  height: 1260px;\n  border: solid 1px #707070;\n  background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 1260px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 1260px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n\n  .input-container[_ngcontent-%COMP%] { \n    display: flex;\n    width: 100%;\n    margin-bottom: 15px;\n  }\n  \n  .icon[_ngcontent-%COMP%] {\n    padding: 10px;\n    background: dodgerblue;\n    color: white;\n    min-width: 50px;\n    text-align: center;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 10px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n    border-right-color:#ffffff;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n  border-left-color:#ffffff;\n  width: 47px;\n}\n}\n\n@media only screen and (max-width: 360px) {\n  .rewarding[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-bottom: 5%;\n    padding-left: 5%;\n  }\n\n  .murmur2[_ngcontent-%COMP%]\n  {\n    padding-left: 15%;\n  }\n  .murmur3[_ngcontent-%COMP%]\n  {\n    padding-top: 10%;\n    padding-left: 5%;\n  }\n\n  .murmurimg1[_ngcontent-%COMP%]\n  {\n    margin-top: -30px;\n  }\n\n  .The-most-rewarding-social-media-platform[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 215px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]{\n    width: 344px;\n    height: 175px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n\n  .Murmur-is-everything[_ngcontent-%COMP%]:hover{\n    width: 344px;\n    height: 175px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n\n  .murmur-02[_ngcontent-%COMP%] {\n    width: 125%;\n    height: 100%;\n    \n    margin-left: -51px;\n    padding-top: 80px;\n  }\n  \n  .Rectangle-10[_ngcontent-%COMP%] {\n    width: 145px;\n    height: 45px;\n    background-color: #fcc13c;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-10[_ngcontent-%COMP%]:hover {\n    width: 145px;\n    height: 45px;\n    background-color: black;\n    color: white;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%] {\n    width: 145px;\n    height: 45px;\n    background-color: #8069ff;\n    margin-right: 2%;\n    margin-left: 2%;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n  .Rectangle-11[_ngcontent-%COMP%]:hover {\n    width: 145px;\n    height: 45px;\n    background-color: black;\n    color: white;\n    margin-right: 2%;\n    margin-left: 2%;\n    padding-top: 3%;\n    cursor: pointer;\n  }\n\n  .Download-App[_ngcontent-%COMP%] {\n    width: 119px;\n    height: 21px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: left;\n    \n  padding-left: 10%;\n  cursor: pointer;\n  }\n\n  .Learn-more[_ngcontent-%COMP%] {\n    width: 93px;\n  height: 21px;\n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  padding-left: 18%;\n  cursor: pointer;\n  \n  }\n\n  \n\n  .Why-Murmur[_ngcontent-%COMP%] {\n    width: 269px;\n    height: 115px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    margin-top: 10%;\n  }\n\n  .We-believe[_ngcontent-%COMP%] {\n    width: 342px;\n  \n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  cursor: pointer;\n  }\n  .We-believe[_ngcontent-%COMP%]:hover {\n    width: 342px;\n  \n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  text-decoration: underline;\n  -webkit-text-decoration-color: #8069ff;\n          text-decoration-color: #8069ff;\n  text-underline-position: under;\n  cursor: pointer;\n  }\n\n  .Read-More[_ngcontent-%COMP%] {\n    width: 110px;\n  height: 28px;\n  font-family: Poppins;\n  font-size: 16px;\n  font-weight: 500;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 1.56;\n  letter-spacing: normal;\n  text-align: left;\n  color: #8069ff;\n  }\n\n  .icons-05[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100%;\n    margin-left: 0px;\n  }\n  .Built-on-Blockchain[_ngcontent-%COMP%] {\n    width: 292px;;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 5%;\n    \n    margin-top: 16%;\n  }\n\n  .rewardimg[_ngcontent-%COMP%]\n{\n  width:100%; \n  height:105%;\n}\n\n  .Rewarding-to-use[_ngcontent-%COMP%] {\n    \n    width: 290px;\n    height: 110px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 10%;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%] {\n    \n    width: 280px;\n    height: 212px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 5%;\n    cursor: pointer;\n  }\n\n  .Publishing-and-engaging[_ngcontent-%COMP%]:hover {\n    \n    width: 280px;\n    height: 212px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    padding-left: 5%;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n  }\n  .Rectangle-63[_ngcontent-%COMP%] {\n    width: 100%;\n    height: 100px;\n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%] {\n    width: 294px;\n    height: 190px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    cursor: pointer;\n    \n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]:hover {\n    width: 294px;\n    height: 190px;\n    font-family: Poppins;\n    font-size: 16px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.56;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;\n    text-decoration: underline;\n    -webkit-text-decoration-color: #8069ff;\n            text-decoration-color: #8069ff;\n    text-underline-position: under;\n    cursor: pointer;\n    \n  }\n  .Murmur-is-a-rewarding[_ngcontent-%COMP%]   .text-style-1[_ngcontent-%COMP%] {\n    color: #8069ff;\n  }\n  \n  .Current-Partners[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 115px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #000000;  \n    margin-top: 100px;\n  }\n\n  .matic[_ngcontent-%COMP%]\n  {\n    width: 196px;\n    height: 75px;\n  }\n\n  .bicon[_ngcontent-%COMP%]\n  {\n    width: 253px;\n  height: 75px;\n  margin-bottom: 95px;\n\n  }\n  .icons-06[_ngcontent-%COMP%] {\n    width: 531px;\n    height: 535px;\n    margin-left: -100px;\n  }\n\n  .Murmur-for-mobile[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 120px;\n    font-family: Poppins;\n    font-size: 45px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 14px;\n    padding-top: 0px;\n  }\n\n  \n  .Use-Murmur[_ngcontent-%COMP%] {\n    width: 320px;\n    height: 162px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: 500;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 37px;\n  }\n\n  .Immediate-blockchain-id-creation-No-wait-time[_ngcontent-%COMP%] {\n    width: 316px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 35px;\n  }\n\n  .No-wait-time[_ngcontent-%COMP%] {\n    width: 340px;\n    \n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.39;\n    letter-spacing: normal;\n    text-align: center;\n    color: #f1f2f9;\n    padding-left: 6px;\n    \n  }\n  \n\n  .i-os1[_ngcontent-%COMP%] {\n    width: 150px;\n    height: 45px;\n    margin-left: 21px;\n    \n    margin-right: 8px;\n  }\n\n  .GooglePlay1[_ngcontent-%COMP%] {\n    width: 150px;\n  height: 45px;\n  }\n  .rotate[_ngcontent-%COMP%] {\n    -webkit-animation: rotation relative;\n            animation: rotation relative;\n    -webkit-animation-name: rotation;\n            animation-name: rotation;\n    position: absolute;\n    left: 40px;\n    top: 355px;\n    \n    z-index: -1;\n    -webkit-animation-duration: 4s;\n            animation-duration: 4s;\n    -webkit-animation-delay: 1s;\n            animation-delay: 1s;\n    width: 100%; height: 100%;\n    \n  }\n\n  @-webkit-keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n\n  @keyframes rotation {\n    from {\n      transform: rotatez(-180deg);\n      left: 40px;\n      top: 25px;\n      width: 10%; height: 10%;\n    }\n    to {\n      transform: rotateZ(0deg);\n      left: 40px;\n      top: 25px;\n      display: none;\n      width: 100%; height: 100%;\n    }\n  }\n.sub_img[_ngcontent-%COMP%]{\n  -webkit-animation-name: sub_img;\n          animation-name: sub_img;\n  position: absolute;\n  z-index: -1;\n  animation-name: sub_img;\n  -webkit-animation-duration: 3s;\n          animation-duration: 3s;\n  \n}\n  @-webkit-keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  @keyframes sub_img {\n    \n    from {width: 10%; height: 10%;}\n    to { width: 110%; height: 110%;}\n  }\n  .We-are-imagining[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 361px;\n    opacity: 0.9;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n  }\n\n  .Join-the-new-way-of-the-world[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 159px;\n    font-family: Poppins;\n    font-size: 40px;\n    font-weight: bold;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.25;\n    letter-spacing: normal;\n    text-align: left;\n    color: #8069ff;\n  }\n\n  .path8[_ngcontent-%COMP%]\n  {\n    width: 315.5px;\n    height: 41.9px;\n  \n  }\n\n  .subcribe[_ngcontent-%COMP%]\n  {\n    width: 315.5px;\n  }\n  .Rectangle-29[_ngcontent-%COMP%] {\n    \n  height: 47px;\n  background-color: #f1f2f9;\n  }\n  .Rectangle-28[_ngcontent-%COMP%] {\n    width: 343px;\n    height: 47px;\n    background-color: #ffffff;\n    border: solid 1px #f1f2f9;\n    \n    padding-top: 0%;\n    cursor: pointer;\n  }\n\n  .Rectangle-30[_ngcontent-%COMP%] {\n    width: 47px;\n    height: 47px;\n    background-color: #8069ff;\n    width: 78px;\n    color: white;\n    font-size: 20px;\n    cursor: pointer;\n  }\n  .Rectangle-31[_ngcontent-%COMP%] {\n   \n    height: 47px;\n    background-color: #ffffff;\n  }\n  .Rectangle-33[_ngcontent-%COMP%] {\n    width: 47px;\n    height: 47px;\n    background-color: #ffffff;\n    width: 78px;\n    color: #8069ff;\n    font-size: 20px;\n    cursor: pointer;\n  }\n\n  .Path-9[_ngcontent-%COMP%] {\n    \n    \n    \n  }\n\n  .Path-8[_ngcontent-%COMP%] {\n    color: #f1f2f9;\n    font-size: 20px;\n    padding-left: 19%;\n  }\n\n  .murmur-03[_ngcontent-%COMP%] {\n    width: 119%;\n    height: 100%;\n    margin-left: -9%;\n    \n  }\n  \n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%] {\n    width: 323px;\n  height: 267px;\n  font-family: Poppins;\n  font-size: 34px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  cursor: pointer;\n  }\n\n  .Forums-Blog-Docs-Token-Economics[_ngcontent-%COMP%]:hover {\n    width: 323px;\n  height: 267px;\n  font-family: Poppins;\n  font-size: 34px;\n  font-weight: bold;\n  font-stretch: normal;\n  font-style: normal;\n  line-height: 2;\n  letter-spacing: normal;\n  text-align: left;\n  color: #000000;\n  text-decoration: underline;\n  -webkit-text-decoration-color: #8069ff;\n          text-decoration-color: #8069ff;\n  text-underline-position: under;\n  cursor: pointer;\n  }\n  \n  .i-os[_ngcontent-%COMP%] {\n    width: 155px;\n    height: 60px;\n    padding-left: 18px;\n    padding-top: 16px;\n  }\n\n  .GooglePlay[_ngcontent-%COMP%] {\n    width: 155px;\n    height: 60px;\n    padding-left: 18px;\n    padding-top: 16px;\n    \n  }\n\n  .Murmur-All-rights-reserved[_ngcontent-%COMP%] {\n    \n    height: 20px;\n    font-family: Poppins;\n    font-size: 14px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 5.14;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;  \n    padding-left: 30px;\n    margin-bottom: 40px;\n  }\n\n  \n  .icons7[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .icons8[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .icons9[_ngcontent-%COMP%]\n  {\n    width: 0%;\n    padding-top: 0%;\n    margin-left: 0%;\n  }\n\n  .Rectangle-24[_ngcontent-%COMP%] {\n   \n    \n  height: 1260px;\n  border: solid 1px #707070;\n  background-color: #8069ff;\n  }\n\n  .Rectangle-25[_ngcontent-%COMP%] {\n   \n    height: 1260px;\n    border: solid 1px #707070;\n    background-color: #fcc13c;\n  }\n\n  .Rectangle-26[_ngcontent-%COMP%] {\n   \n    height: 1260px;\n    border: solid 1px #707070;\n    background-color: #00cd9b;\n  }\n\n  .input-container[_ngcontent-%COMP%] { \n    display: flex;\n    width: 100%;\n    margin-bottom: 15px;\n  }\n  \n  .icon[_ngcontent-%COMP%] {\n    padding: 10px;\n    background: dodgerblue;\n    color: white;\n    min-width: 50px;\n    text-align: center;\n  }\n\n  .Thanks-or-subscribing[_ngcontent-%COMP%] {\n    width: 224px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 10px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 2.65;\n    letter-spacing: normal;\n    text-align: left;\n    color: #00cd9b;\n    padding-left: 4%;\n  }\n\n  .input-group[_ngcontent-%COMP%]    > .form-control[_ngcontent-%COMP%]:not(:last-child), .input-group[_ngcontent-%COMP%]    > .custom-select[_ngcontent-%COMP%]:not(:last-child) {\n    border-top-right-radius: 0;\n    border-top-left-radius: 0;\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n    border-right-color:#ffffff;\n}\n\n.input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-append[_ngcontent-%COMP%]    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .btn[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:not(:first-child)    > .input-group-text[_ngcontent-%COMP%], .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .btn[_ngcontent-%COMP%]:not(:first-child), .input-group[_ngcontent-%COMP%]    > .input-group-prepend[_ngcontent-%COMP%]:first-child    > .input-group-text[_ngcontent-%COMP%]:not(:first-child) {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n  border-top-right-radius: 0;\n  border-bottom-right-radius: 0;\n  border-left-color:#ffffff;\n  width: 47px;\n}\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0U7O0lBRUUsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixrQkFBa0I7RUFDcEI7O0VBRUE7O0lBRUUsbUJBQW1CO0VBQ3JCOztFQUVBOztJQUVFLGdCQUFnQjtJQUNoQixrQkFBa0I7RUFDcEI7RUFDQTs7SUFFRSxrQkFBa0I7RUFDcEI7RUFDQTtJQUNFLFlBQVk7RUFDZCxtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2Q7O0VBRUE7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7SUFDZjs7cUNBRWlDO0VBQ25DOztFQUVBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Y7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZixvQkFBb0I7RUFDcEI7OztFQUdBOzs7Ozs7Ozs7Ozs7S0FZRzs7RUFFSDtJQUNFLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixpQkFBaUI7RUFDbkI7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCO0FBQ0Y7O0VBRUUsVUFBVTtFQUNWLFdBQVc7QUFDYjtFQUNFO0lBQ0Usa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCOzs7RUFHQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0VBQ2Y7RUFDQTtJQUNFLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGtCQUFrQjtJQUNsQiwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0VBQ2hCOztFQUVBOztJQUVFLFVBQVU7SUFDVixXQUFXO0VBQ2I7O0VBRUE7O0lBRUUsVUFBVTtJQUNWLFdBQVc7RUFDYjtFQUNBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7OztFQUdBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7O0VBRWhCO0VBQ0E7O0tBRUc7O0VBRUg7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0VBQ2I7RUFDQTtJQUNFLG9DQUE0QjtZQUE1Qiw0QkFBNEI7SUFDNUIsZ0NBQXdCO1lBQXhCLHdCQUF3QjtJQUN4QixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFVBQVU7SUFDVjtpQkFDYTtJQUNiLFdBQVc7SUFDWCw4QkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLDJCQUFtQjtZQUFuQixtQkFBbUI7SUFDbkIsV0FBVyxFQUFFLFlBQVk7SUFDekIsZ0NBQWdDO0VBQ2xDOztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7O0VBZEE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjtBQUNGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLHVCQUF1QjtFQUN2Qiw4QkFBc0I7VUFBdEIsc0JBQXNCOztBQUV4QjtFQUNFOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFKQTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUNBOztJQUVFO0VBQ0Y7O0VBRUE7O0lBRUU7RUFDRjs7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7O0lBRUUsaUJBQWlCO0lBQ2pCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLFlBQVk7SUFDWixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7O0lBRUUsaUJBQWlCO0lBQ2pCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7O0VBRWpCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLGVBQWU7RUFDakI7O0VBRUE7O0lBRUUsV0FBVztJQUNYLGlCQUFpQjtJQUNqQixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0VBQ2xCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBOztJQUVFLGFBQWE7SUFDYix5QkFBeUI7SUFDekIseUJBQXlCO0VBQzNCOztFQUVBLG1CQUN3QixTQUFTO0lBQy9CLGFBQWE7SUFDYixXQUFXO0lBQ1gsbUJBQW1CO0VBQ3JCOztFQUVBO0lBQ0UsYUFBYTtJQUNiLHNCQUFzQjtJQUN0QixZQUFZO0lBQ1osZUFBZTtJQUNmLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsZ0JBQWdCO0VBQ2xCOztFQUVBO0lBQ0UsMEJBQTBCO0lBQzFCLHlCQUF5QjtJQUN6Qiw2QkFBNkI7SUFDN0IsNEJBQTRCO0lBQzVCLDBCQUEwQjtBQUM5Qjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw0QkFBNEI7RUFDNUIsMEJBQTBCO0VBQzFCLDZCQUE2QjtFQUM3Qix5QkFBeUI7QUFDM0I7QUFDQTs7QUFFQTtFQUNFOztJQUVFLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsa0JBQWtCO0VBQ3BCOztFQUVBOztJQUVFLG1CQUFtQjtFQUNyQjs7RUFFQTs7SUFFRSxnQkFBZ0I7SUFDaEIsa0JBQWtCO0VBQ3BCO0VBQ0E7O0lBRUUsa0JBQWtCO0VBQ3BCO0VBQ0E7SUFDRSxZQUFZO0VBQ2QsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkOztFQUVBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0lBQ2Y7O3FDQUVpQztFQUNuQzs7RUFFQTtJQUNFLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCOzs7RUFHQTs7Ozs7Ozs7Ozs7O0tBWUc7O0VBRUg7SUFDRSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osaUJBQWlCO0VBQ25CO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7SUFFRTs7TUFFRSxVQUFVO01BQ1YsV0FBVztJQUNiOztFQUVGO0lBQ0Usa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCOzs7RUFHQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0VBQ2Y7RUFDQTtJQUNFLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGtCQUFrQjtJQUNsQiwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0VBQ2hCOztFQUVBOztJQUVFLFVBQVU7SUFDVixXQUFXO0VBQ2I7O0VBRUE7O0lBRUUsVUFBVTtJQUNWLFdBQVc7RUFDYjtFQUNBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7OztFQUdBO0lBQ0UsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7O0VBRWhCO0VBQ0E7O0tBRUc7O0VBRUg7SUFDRSxVQUFVO0lBQ1YsV0FBVztJQUNYLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0VBQ2I7RUFDQTtJQUNFLG9DQUE0QjtZQUE1Qiw0QkFBNEI7SUFDNUIsZ0NBQXdCO1lBQXhCLHdCQUF3QjtJQUN4QixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFVBQVU7SUFDVjtpQkFDYTtJQUNiLFdBQVc7SUFDWCw4QkFBc0I7WUFBdEIsc0JBQXNCO0lBQ3RCLDJCQUFtQjtZQUFuQixtQkFBbUI7SUFDbkIsV0FBVyxFQUFFLFlBQVk7SUFDekIsZ0NBQWdDO0VBQ2xDOztFQUVBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7O0VBZEE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjtBQUNGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLHVCQUF1QjtFQUN2Qiw4QkFBc0I7VUFBdEIsc0JBQXNCOztBQUV4QjtFQUNFOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFKQTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjtFQUNBOztJQUVFO0VBQ0Y7O0VBRUE7O0lBRUU7RUFDRjs7RUFFQTtJQUNFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7O0lBRUUsaUJBQWlCO0lBQ2pCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLFlBQVk7SUFDWixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBOztJQUVFLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztFQUNiO0VBQ0E7O0lBRUUsaUJBQWlCO0lBQ2pCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7O0VBRWpCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLGlCQUFpQjtFQUNuQjs7RUFFQTs7SUFFRSxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLGlCQUFpQjtFQUNuQjs7RUFFQTs7SUFFRSxXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLGlCQUFpQjtFQUNuQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxhQUFhO0lBQ2IseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQSxtQkFDd0IsU0FBUztJQUMvQixhQUFhO0lBQ2IsV0FBVztJQUNYLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsWUFBWTtJQUNaLGVBQWU7SUFDZixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtJQUM1QiwwQkFBMEI7QUFDOUI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLDBCQUEwQjtFQUMxQiw2QkFBNkI7RUFDN0IseUJBQXlCO0FBQzNCO0FBQ0E7O0FBQ0E7RUFDRTs7SUFFRSxnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtFQUNsQjs7RUFFQTs7SUFFRSxpQkFBaUI7RUFDbkI7RUFDQTs7SUFFRSxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0VBQ2xCOztFQUVBOztJQUVFLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxlQUFlO0lBQ2Y7O3FDQUVpQztFQUNuQzs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRTtvQkFDZ0I7SUFDaEIsV0FBVztJQUNYLFlBQVk7SUFDWixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGVBQWU7SUFDZixlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsaUJBQWlCO0VBQ25CLGVBQWU7RUFDZjs7RUFFQTtJQUNFLFdBQVc7RUFDYixZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQjs7RUFFQTs7Ozs7Ozs7Ozs7O0tBWUc7O0VBRUg7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkOztFQUVBO0lBQ0UsWUFBWTtFQUNkLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCwwQkFBMEI7RUFDMUIsc0NBQThCO1VBQTlCLDhCQUE4QjtFQUM5Qiw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmOzs7RUFHQTtJQUNFLFlBQVk7RUFDZCxZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2Q7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtFQUNkO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGlCQUFpQjtJQUNqQixxQkFBcUI7SUFDckIsZUFBZTtFQUNqQjs7RUFFQTs7RUFFQSxVQUFVO0VBQ1YsV0FBVztBQUNiO0VBQ0U7SUFDRSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsYUFBYTtFQUNmO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLDBCQUEwQjtJQUMxQixzQ0FBOEI7WUFBOUIsOEJBQThCO0lBQzlCLDhCQUE4QjtJQUM5QixlQUFlO0VBQ2pCOztFQUVBO0lBQ0UsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsaUJBQWlCO0VBQ25COztFQUVBOztJQUVFLFlBQVk7SUFDWixZQUFZO0VBQ2Q7O0VBRUE7O0lBRUUsWUFBWTtFQUNkLFlBQVk7RUFDWixtQkFBbUI7O0VBRW5CO0VBQ0E7SUFDRTtvQkFDZ0I7SUFDaEIsWUFBWTtJQUNaLGFBQWE7SUFDYixrQkFBa0I7O0VBRXBCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsZ0JBQWdCO0VBQ2xCOzs7RUFHQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2Qsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGlCQUFpQjs7RUFFbkI7RUFDQTs7S0FFRzs7RUFFSDtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLHdCQUF3QjtJQUN4QixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsWUFBWTtFQUNaO0VBQ0E7SUFDRSxvQ0FBNEI7WUFBNUIsNEJBQTRCO0lBQzVCLGdDQUF3QjtZQUF4Qix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixVQUFVO0lBQ1Y7aUJBQ2E7SUFDYixXQUFXO0lBQ1gsOEJBQXNCO1lBQXRCLHNCQUFzQjtJQUN0QiwyQkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLFdBQVcsRUFBRSxZQUFZO0lBQ3pCLGdDQUFnQztFQUNsQzs7RUFFQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGOztFQWRBO0lBQ0U7TUFDRSwyQkFBMkI7TUFDM0IsVUFBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLEVBQUUsV0FBVztJQUN6QjtJQUNBO01BQ0Usd0JBQXdCO01BQ3hCLFVBQVU7TUFDVixTQUFTO01BQ1QsYUFBYTtNQUNiLFdBQVcsRUFBRSxZQUFZO0lBQzNCO0VBQ0Y7QUFDRjtFQUNFLCtCQUF1QjtVQUF2Qix1QkFBdUI7RUFDdkIsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCx1QkFBdUI7RUFDdkIsOEJBQXNCO1VBQXRCLHNCQUFzQjs7QUFFeEI7RUFDRTs7SUFFRSxNQUFNLFVBQVUsRUFBRSxXQUFXLENBQUM7SUFDOUIsS0FBSyxXQUFXLEVBQUUsWUFBWSxDQUFDO0VBQ2pDO0VBSkE7O0lBRUUsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLEtBQUssV0FBVyxFQUFFLFlBQVksQ0FBQztFQUNqQztFQUNBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7O0lBRUUsY0FBYztJQUNkLGNBQWM7O0VBRWhCOztFQUVBOztJQUVFLFlBQVk7RUFDZDtFQUNBOztFQUVBLFlBQVk7RUFDWix5QkFBeUI7RUFDekI7RUFDQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLHlCQUF5QjtJQUN6QiwrQkFBK0I7SUFDL0IsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7O0lBRUUsWUFBWTtJQUNaLHlCQUF5QjtFQUMzQjtFQUNBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsV0FBVztJQUNYLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFO3NCQUNrQjs7SUFFbEIsd0JBQXdCO0VBQzFCOztFQUVBO0lBQ0UsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGdCQUFnQjs7RUFFbEI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsYUFBYTtFQUNiLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsY0FBYztFQUNkLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkOztFQUVBO0lBQ0UsWUFBWTtFQUNkLGFBQWE7RUFDYixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCwwQkFBMEI7RUFDMUIsc0NBQThCO1VBQTlCLDhCQUE4QjtFQUM5Qiw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCO3lCQUNxQjtFQUN2Qjs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLG1CQUFtQjtFQUNyQjs7RUFFQTs7SUFFRSxTQUFTO0lBQ1QsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7O0lBRUUsU0FBUztJQUNULGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLFNBQVM7SUFDVCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxrQkFBa0I7RUFDcEIsY0FBYztFQUNkLHlCQUF5QjtFQUN6Qix5QkFBeUI7RUFDekI7O0VBRUE7O0lBRUUsY0FBYztJQUNkLHlCQUF5QjtJQUN6Qix5QkFBeUI7RUFDM0I7O0VBRUE7O0lBRUUsY0FBYztJQUNkLHlCQUF5QjtJQUN6Qix5QkFBeUI7RUFDM0I7O0VBRUEsbUJBQ3dCLFNBQVM7SUFDL0IsYUFBYTtJQUNiLFdBQVc7SUFDWCxtQkFBbUI7RUFDckI7O0VBRUE7SUFDRSxhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLFlBQVk7SUFDWixlQUFlO0lBQ2Ysa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCxnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSwwQkFBMEI7SUFDMUIseUJBQXlCO0lBQ3pCLDZCQUE2QjtJQUM3Qiw0QkFBNEI7SUFDNUIsMEJBQTBCO0FBQzlCOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLDRCQUE0QjtFQUM1QiwwQkFBMEI7RUFDMUIsNkJBQTZCO0VBQzdCLHlCQUF5QjtFQUN6QixXQUFXO0FBQ2I7QUFDQTs7QUFFQTtFQUNFOztJQUVFLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0VBQ2xCOztFQUVBOztJQUVFLGlCQUFpQjtFQUNuQjtFQUNBOztJQUVFLGdCQUFnQjtJQUNoQixnQkFBZ0I7RUFDbEI7O0VBRUE7O0lBRUUsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGVBQWU7SUFDZjs7cUNBRWlDO0VBQ25DOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGtCQUFrQjtJQUNsQixpQkFBaUI7RUFDbkI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsZUFBZTtFQUNqQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix1QkFBdUI7SUFDdkIsWUFBWTtJQUNaLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLGVBQWU7SUFDZixlQUFlO0VBQ2pCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGVBQWU7SUFDZixlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixvQkFBb0I7RUFDdEIsaUJBQWlCO0VBQ2pCLGVBQWU7RUFDZjs7RUFFQTtJQUNFLFdBQVc7RUFDYixZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLG9CQUFvQjtFQUNwQjs7RUFFQTs7Ozs7Ozs7Ozs7O0tBWUc7O0VBRUg7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxZQUFZO0VBQ2QsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsY0FBYztFQUNkLGVBQWU7RUFDZjtFQUNBO0lBQ0UsWUFBWTtFQUNkLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCwwQkFBMEI7RUFDMUIsc0NBQThCO1VBQTlCLDhCQUE4QjtFQUM5Qiw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZDs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0VBQ2xCO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGdCQUFnQjtJQUNoQixxQkFBcUI7SUFDckIsZUFBZTtFQUNqQjs7RUFFQTs7RUFFQSxVQUFVO0VBQ1YsV0FBVztBQUNiOztFQUVFO0lBQ0Usa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsZ0JBQWdCO0lBQ2hCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsMEJBQTBCO0lBQzFCLHNDQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsOEJBQThCO0lBQzlCLGVBQWU7RUFDakI7RUFDQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0VBQ2Y7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsZUFBZTtJQUNmLHdCQUF3QjtFQUMxQjtFQUNBO0lBQ0UsWUFBWTtJQUNaLGFBQWE7SUFDYixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsc0NBQThCO1lBQTlCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsZUFBZTtJQUNmLHdCQUF3QjtFQUMxQjtFQUNBO0lBQ0UsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsaUJBQWlCO0VBQ25COztFQUVBOztJQUVFLFlBQVk7SUFDWixZQUFZO0VBQ2Q7O0VBRUE7O0lBRUUsWUFBWTtFQUNkLFlBQVk7RUFDWixtQkFBbUI7O0VBRW5CO0VBQ0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLGdCQUFnQjtFQUNsQjs7O0VBR0E7SUFDRSxZQUFZO0lBQ1osYUFBYTtJQUNiLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixrQkFBa0I7SUFDbEIsY0FBYztJQUNkLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2Qsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGlCQUFpQjtJQUNqQixzQkFBc0I7SUFDdEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxpQkFBaUI7O0VBRW5CO0VBQ0E7O0tBRUc7O0VBRUg7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLGlCQUFpQjtJQUNqQix3QkFBd0I7SUFDeEIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtFQUNkLFlBQVk7RUFDWjtFQUNBO0lBQ0Usb0NBQTRCO1lBQTVCLDRCQUE0QjtJQUM1QixnQ0FBd0I7WUFBeEIsd0JBQXdCO0lBQ3hCLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsVUFBVTtJQUNWO2lCQUNhO0lBQ2IsV0FBVztJQUNYLDhCQUFzQjtZQUF0QixzQkFBc0I7SUFDdEIsMkJBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQixXQUFXLEVBQUUsWUFBWTtJQUN6QixnQ0FBZ0M7RUFDbEM7O0VBRUE7SUFDRTtNQUNFLDJCQUEyQjtNQUMzQixVQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsRUFBRSxXQUFXO0lBQ3pCO0lBQ0E7TUFDRSx3QkFBd0I7TUFDeEIsVUFBVTtNQUNWLFNBQVM7TUFDVCxhQUFhO01BQ2IsV0FBVyxFQUFFLFlBQVk7SUFDM0I7RUFDRjs7RUFkQTtJQUNFO01BQ0UsMkJBQTJCO01BQzNCLFVBQVU7TUFDVixTQUFTO01BQ1QsVUFBVSxFQUFFLFdBQVc7SUFDekI7SUFDQTtNQUNFLHdCQUF3QjtNQUN4QixVQUFVO01BQ1YsU0FBUztNQUNULGFBQWE7TUFDYixXQUFXLEVBQUUsWUFBWTtJQUMzQjtFQUNGO0FBQ0Y7RUFDRSwrQkFBdUI7VUFBdkIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsdUJBQXVCO0VBQ3ZCLDhCQUFzQjtVQUF0QixzQkFBc0I7O0FBRXhCO0VBQ0U7O0lBRUUsTUFBTSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQzlCLEtBQUssV0FBVyxFQUFFLFlBQVksQ0FBQztFQUNqQztFQUpBOztJQUVFLE1BQU0sVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUM5QixLQUFLLFdBQVcsRUFBRSxZQUFZLENBQUM7RUFDakM7RUFDQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2IsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztFQUNoQjs7RUFFQTtJQUNFLFlBQVk7SUFDWixhQUFhO0lBQ2Isb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0VBQ2hCOztFQUVBOztJQUVFLGNBQWM7SUFDZCxjQUFjOztFQUVoQjs7RUFFQTs7SUFFRSxjQUFjO0VBQ2hCO0VBQ0E7O0VBRUEsWUFBWTtFQUNaLHlCQUF5QjtFQUN6QjtFQUNBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIseUJBQXlCO0lBQ3pCLCtCQUErQjtJQUMvQixlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLFdBQVc7SUFDWCxZQUFZO0lBQ1osZUFBZTtJQUNmLGVBQWU7RUFDakI7RUFDQTs7SUFFRSxZQUFZO0lBQ1oseUJBQXlCO0VBQzNCO0VBQ0E7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixXQUFXO0lBQ1gsY0FBYztJQUNkLGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBO0lBQ0U7c0JBQ2tCOztJQUVsQix3QkFBd0I7RUFDMUI7O0VBRUE7SUFDRSxjQUFjO0lBQ2QsZUFBZTtJQUNmLGlCQUFpQjtFQUNuQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCOztFQUVsQjs7RUFFQTtJQUNFLFlBQVk7RUFDZCxhQUFhO0VBQ2Isb0JBQW9CO0VBQ3BCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2Qsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtFQUNkLGFBQWE7RUFDYixvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixvQkFBb0I7RUFDcEIsa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCwwQkFBMEI7RUFDMUIsc0NBQThCO1VBQTlCLDhCQUE4QjtFQUM5Qiw4QkFBOEI7RUFDOUIsZUFBZTtFQUNmOztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCO3lCQUNxQjtFQUN2Qjs7RUFFQTtJQUNFLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLG1CQUFtQjtFQUNyQjs7RUFFQTs7Ozs7S0FLRztFQUNIOztJQUVFLFNBQVM7SUFDVCxlQUFlO0lBQ2YsZUFBZTtFQUNqQjs7RUFFQTs7SUFFRSxTQUFTO0lBQ1QsZUFBZTtJQUNmLGVBQWU7RUFDakI7O0VBRUE7O0lBRUUsU0FBUztJQUNULGVBQWU7SUFDZixlQUFlO0VBQ2pCOztFQUVBOztJQUVFLGtCQUFrQjtFQUNwQixjQUFjO0VBQ2QseUJBQXlCO0VBQ3pCLHlCQUF5QjtFQUN6Qjs7RUFFQTs7SUFFRSxjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQTs7SUFFRSxjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLHlCQUF5QjtFQUMzQjs7RUFFQSxtQkFDd0IsU0FBUztJQUMvQixhQUFhO0lBQ2IsV0FBVztJQUNYLG1CQUFtQjtFQUNyQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsWUFBWTtJQUNaLGVBQWU7SUFDZixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLDBCQUEwQjtJQUMxQix5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLDRCQUE0QjtJQUM1QiwwQkFBMEI7QUFDOUI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNEJBQTRCO0VBQzVCLDBCQUEwQjtFQUMxQiw2QkFBNkI7RUFDN0IseUJBQXlCO0VBQ3pCLFdBQVc7QUFDYjtBQUNBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAxMjAwcHgpIHtcbiAgLnJld2FyZGluZ1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogNSU7XG4gICAgcGFkZGluZy1sZWZ0OiA0MHB4O1xuICB9XG5cbiAgLm11cm11cjJcbiAge1xuICAgIHBhZGRpbmctbGVmdDogMTI3cHg7XG4gIH1cblxuICAubXVybXVyM1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDQwcHg7XG4gIH1cbiAgLm11cm11cmltZzFcbiAge1xuICAgIG1hcmdpbi10b3A6IC0xMDBweDtcbiAgfVxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAvKiBoZWlnaHQ6IDE2MHB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAzNXB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuMztcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDU4MHB4O1xuICAgIC8qIGhlaWdodDogMTcwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjk0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjsgKi9cbiAgfVxuXG4gIC5NdXJtdXItaXMtZXZlcnl0aGluZzpob3ZlcntcbiAgICB3aWR0aDogNTgwcHg7XG4gICAgLyogaGVpZ2h0OiAxNzBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLm11cm11ci0wMiB7XG4gICAgd2lkdGg6IDEyNyU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAtNzhweDtcbiAgfVxuICBcbiAgLlJlY3RhbmdsZS0xMCB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLlJlY3RhbmdsZS0xMDpob3ZlciB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTExIHtcbiAgICB3aWR0aDogMTQ5cHg7XG4gICAgaGVpZ2h0OiA1MnB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0xMTpob3ZlciB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIHBhZGRpbmctbGVmdDogMTYlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDE0cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMjQlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIGNvbG9yOiAjMDAwMDAwOyAqL1xuICB9XG5cblxuICAvKiAuTGVhcm4tbW9yZTpob3ZlciB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgfSAqL1xuXG4gIC5XaHktTXVybXVyIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiA3N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2UtYmVsaWV2ZSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIC8qIGhlaWdodDogMTEwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuV2UtYmVsaWV2ZTpob3ZlciB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIC8qIGhlaWdodDogMTEwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICBcbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLmljb25zLTA1IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIH1cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBoZWlnaHQ6IDExMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cbi5yZXdhcmRpbWdcbntcbiAgd2lkdGg6MTAwJTsgXG4gIGhlaWdodDoxMDUlO1xufVxuICAuUmV3YXJkaW5nLXRvLXVzZSB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgfVxuXG4gIC5QdWJsaXNoaW5nLWFuZC1lbmdhZ2luZyB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIGhlaWdodDogMTI1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUHVibGlzaGluZy1hbmQtZW5nYWdpbmc6aG92ZXIge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICBoZWlnaHQ6IDEyNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICBcbiAgLlJlY3RhbmdsZS02MyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAyMjBweDtcbiAgfVxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgLyogaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nOmhvdmVyIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgLyogaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nIC50ZXh0LXN0eWxlLTEge1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG4gIFxuICAuQ3VycmVudC1QYXJ0bmVycyB7XG4gICAgd2lkdGg6IDQ2N3B4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgfVxuXG4gIC5tYXRpY1xuICB7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBoZWlnaHQ6MTAwJTtcbiAgfVxuXG4gIC5iaWNvblxuICB7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBoZWlnaHQ6MTAwJTtcbiAgfVxuICAuaWNvbnMtMDYge1xuICAgIHdpZHRoOiAyMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tdG9wOiAyM3B4O1xuICAgIG1hcmdpbi1sZWZ0OiAtNDAlO1xuICB9XG5cbiAgLk11cm11ci1mb3ItbW9iaWxlIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiA3N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy10b3A6IDE4MHB4O1xuICB9XG5cbiAgXG4gIC5Vc2UtTXVybXVyIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiAxMDVweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNzU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIHBhZGRpbmctdG9wOiA1JTtcbiAgfVxuXG4gIC5JbW1lZGlhdGUtYmxvY2tjaGFpbi1pZC1jcmVhdGlvbi1Oby13YWl0LXRpbWUge1xuICAgIHdpZHRoOiA1NDBweDtcbiAgICAvKiBoZWlnaHQ6IDY3cHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjMzO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLXRvcDogNSU7XG4gIH1cblxuICAuTm8td2FpdC10aW1lIHtcbiAgICB3aWR0aDogNTQwcHg7XG4gICAgLyogaGVpZ2h0OiA2N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgXG4gIH1cbiAgLyogLm1haW5faW1nIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5cbiAgLmktb3MxIHtcbiAgICB3aWR0aDogMzMlO1xuICAgIGhlaWdodDogMzMlO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgfVxuXG4gIC5Hb29nbGVQbGF5MSB7XG4gICAgd2lkdGg6IDMzJTtcbiAgICBoZWlnaHQ6IDMzJTtcbiAgfVxuICAucm90YXRlIHtcbiAgICBhbmltYXRpb246IHJvdGF0aW9uIHJlbGF0aXZlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiByb3RhdGlvbjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNDBweDtcbiAgICB0b3A6IDM1NXB4O1xuICAgIC8qIGxlZnQ6IC0xMjVweDtcbiAgICB0b3A6IDI3MHB4OyAqL1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogNHM7XG4gICAgYW5pbWF0aW9uLWRlbGF5OiAxcztcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpOyAqL1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhdGlvbiB7XG4gICAgZnJvbSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZXooLTE4MGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgd2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7XG4gICAgfVxuICAgIHRvIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbi5zdWJfaW1ne1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIFxufVxuICBAa2V5ZnJhbWVzIHN1Yl9pbWcge1xuICAgIFxuICAgIGZyb20ge3dpZHRoOiAxMCU7IGhlaWdodDogMTAlO31cbiAgICB0byB7IHdpZHRoOiAxMTAlOyBoZWlnaHQ6IDExMCU7fVxuICB9XG4gIC5XZS1hcmUtaW1hZ2luaW5nIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyMTBweDtcbiAgICBvcGFjaXR5OiAwLjk7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSm9pbi10aGUtbmV3LXdheS1vZi10aGUtd29ybGQge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuICAucGF0aDhcbiAge1xuICAgIHdpZHRoOjk1JVxuICB9XG5cbiAgLnN1YmNyaWJlXG4gIHtcbiAgICB3aWR0aDo5NSVcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjkge1xuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG4gIC5SZWN0YW5nbGUtMjgge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2YxZjJmOTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTMwIHtcbiAgICBcbiAgICAvKiB3aWR0aDogNDdweDsgKi9cbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTMxIHtcbiAgICBcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgfVxuICAuUmVjdGFuZ2xlLTMzIHtcbiAgICBcbiAgICAvKiB3aWR0aDogNDdweDsgKi9cbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlBhdGgtOSB7XG4gICAgLyogY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjhweDsgKi9cbiAgICBcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cblxuICAuUGF0aC04IHtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgcGFkZGluZy1sZWZ0OiA1MCU7XG4gIH1cblxuICAubXVybXVyLTAzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDExMiU7XG4gICAgbWFyZ2luLWxlZnQ6IDglO1xuICAgIFxuICB9XG4gIFxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3Mge1xuICAgIHdpZHRoOiAzNThweDtcbiAgICBoZWlnaHQ6IDI3MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuODtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIFxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3M6aG92ZXIge1xuICAgIHdpZHRoOiAzNThweDtcbiAgICBoZWlnaHQ6IDI3MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuODtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiBcbiAgLmktb3Mge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLk11cm11ci1BbGwtcmlnaHRzLXJlc2VydmVkIHtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiA1LjE0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tbGVmdDogNCU7XG4gICAgbWFyZ2luLXRvcDogMTclO1xuICB9XG5cbiAgLmljb25zN1xuICB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy10b3A6IDEyOSU7XG4gICAgbWFyZ2luLWxlZnQ6IDMlO1xuICB9XG5cbiAgLmljb25zOFxuICB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy10b3A6IDEwNSU7XG4gICAgbWFyZ2luLWxlZnQ6IDMlO1xuICB9XG5cbiAgLmljb25zOVxuICB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy10b3A6IDk4JTtcbiAgICBtYXJnaW4tbGVmdDogLTUlO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNCB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjUge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI2IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICB9XG5cbiAgLmlucHV0LWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogLW1zLWZsZXhib3g7IC8qIElFMTAgKi9cbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIH1cbiAgXG4gIC5pY29uIHtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIGJhY2tncm91bmQ6IGRvZGdlcmJsdWU7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1pbi13aWR0aDogNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cblxuICAuVGhhbmtzLW9yLXN1YnNjcmliaW5nIHtcbiAgICB3aWR0aDogMjI0cHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMi42NTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gICAgcGFkZGluZy1sZWZ0OiA0JTtcbiAgfVxuXG4gIC5pbnB1dC1ncm91cCA+IC5mb3JtLWNvbnRyb2w6bm90KDpsYXN0LWNoaWxkKSwgLmlucHV0LWdyb3VwID4gLmN1c3RvbS1zZWxlY3Q6bm90KDpsYXN0LWNoaWxkKSB7XG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1yaWdodC1jb2xvcjojZmZmZmZmO1xufVxuXG4uaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtYXBwZW5kID4gLmJ0biwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLWFwcGVuZCA+IC5pbnB1dC1ncm91cC10ZXh0LCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpub3QoOmZpcnN0LWNoaWxkKSA+IC5idG4sIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmlucHV0LWdyb3VwLXRleHQsIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOmZpcnN0LWNoaWxkID4gLmJ0bjpub3QoOmZpcnN0LWNoaWxkKSwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6Zmlyc3QtY2hpbGQgPiAuaW5wdXQtZ3JvdXAtdGV4dDpub3QoOmZpcnN0LWNoaWxkKSB7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWxlZnQtY29sb3I6I2ZmZmZmZjtcbn1cbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgLnJld2FyZGluZ1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogNSU7XG4gICAgcGFkZGluZy1sZWZ0OiA0MHB4O1xuICB9XG5cbiAgLm11cm11cjJcbiAge1xuICAgIHBhZGRpbmctbGVmdDogMTI3cHg7XG4gIH1cblxuICAubXVybXVyM1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDQwcHg7XG4gIH1cbiAgLm11cm11cmltZzFcbiAge1xuICAgIG1hcmdpbi10b3A6IC0xMDBweDtcbiAgfVxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAvKiBoZWlnaHQ6IDE2MHB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAzNXB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuMztcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDU4MHB4O1xuICAgIC8qIGhlaWdodDogMTcwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjk0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjsgKi9cbiAgfVxuXG4gIC5NdXJtdXItaXMtZXZlcnl0aGluZzpob3ZlcntcbiAgICB3aWR0aDogNTgwcHg7XG4gICAgLyogaGVpZ2h0OiAxNzBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuOTQ7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLm11cm11ci0wMiB7XG4gICAgd2lkdGg6IDEyNyU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAtODlweDtcbiAgfVxuICBcbiAgLlJlY3RhbmdsZS0xMCB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICAgIHBhZGRpbmctdG9wOiA0JTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLlJlY3RhbmdsZS0xMDpob3ZlciB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZy10b3A6IDQlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTExIHtcbiAgICB3aWR0aDogMTQ5cHg7XG4gICAgaGVpZ2h0OiA1MnB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgICBwYWRkaW5nLXRvcDogNCU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0xMTpob3ZlciB7XG4gICAgd2lkdGg6IDE0OXB4O1xuICAgIGhlaWdodDogNTJweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xuICAgIHBhZGRpbmctdG9wOiA0JTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gIGhlaWdodDogMjhweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIHBhZGRpbmctbGVmdDogMTYlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDE0cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMjQlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIGNvbG9yOiAjMDAwMDAwOyAqL1xuICB9XG5cblxuICAvKiAuTGVhcm4tbW9yZTpob3ZlciB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgfSAqL1xuXG4gIC5XaHktTXVybXVyIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiA3N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTRweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuV2UtYmVsaWV2ZSB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIC8qIGhlaWdodDogMTEwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuV2UtYmVsaWV2ZTpob3ZlciB7XG4gICAgd2lkdGg6IDYyNXB4O1xuICAgIC8qIGhlaWdodDogMTEwcHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICBcbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuMDU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLmljb25zLTA1IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XG4gIH1cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAzMDRweDtcbiAgICBoZWlnaHQ6IDExMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAgIC5yZXdhcmRpbWdcbiAgICB7XG4gICAgICB3aWR0aDoxMDAlOyBcbiAgICAgIGhlaWdodDoxNDAlO1xuICAgIH1cblxuICAuUmV3YXJkaW5nLXRvLXVzZSB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIGhlaWdodDogNjVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgfVxuXG4gIC5QdWJsaXNoaW5nLWFuZC1lbmdhZ2luZyB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIGhlaWdodDogMTI1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUHVibGlzaGluZy1hbmQtZW5nYWdpbmc6aG92ZXIge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICBoZWlnaHQ6IDEyNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICBcbiAgLlJlY3RhbmdsZS02MyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAyMjBweDtcbiAgfVxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgLyogaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nOmhvdmVyIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgLyogaGVpZ2h0OiAyNTBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nIC50ZXh0LXN0eWxlLTEge1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG4gIFxuICAuQ3VycmVudC1QYXJ0bmVycyB7XG4gICAgd2lkdGg6IDQ2N3B4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDU0cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgfVxuXG4gIC5tYXRpY1xuICB7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBoZWlnaHQ6MTAwJTtcbiAgfVxuXG4gIC5iaWNvblxuICB7XG4gICAgd2lkdGg6MTAwJTtcbiAgICBoZWlnaHQ6MTAwJTtcbiAgfVxuICAuaWNvbnMtMDYge1xuICAgIHdpZHRoOiAyMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tdG9wOiA2MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAtNDAlO1xuICB9XG5cbiAgLk11cm11ci1mb3ItbW9iaWxlIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiA3N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNTFweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy10b3A6IDE4MHB4O1xuICB9XG5cbiAgXG4gIC5Vc2UtTXVybXVyIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgLyogaGVpZ2h0OiAxMDVweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNzU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIHBhZGRpbmctdG9wOiA1JTtcbiAgfVxuXG4gIC5JbW1lZGlhdGUtYmxvY2tjaGFpbi1pZC1jcmVhdGlvbi1Oby13YWl0LXRpbWUge1xuICAgIHdpZHRoOiA1NDBweDtcbiAgICAvKiBoZWlnaHQ6IDY3cHg7ICovXG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjMzO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLXRvcDogNSU7XG4gIH1cblxuICAuTm8td2FpdC10aW1lIHtcbiAgICB3aWR0aDogNTQwcHg7XG4gICAgLyogaGVpZ2h0OiA2N3B4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zMztcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgXG4gIH1cbiAgLyogLm1haW5faW1nIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5cbiAgLmktb3MxIHtcbiAgICB3aWR0aDogMzMlO1xuICAgIGhlaWdodDogMzMlO1xuICAgIG1hcmdpbi1yaWdodDogMzBweDtcbiAgfVxuXG4gIC5Hb29nbGVQbGF5MSB7XG4gICAgd2lkdGg6IDMzJTtcbiAgICBoZWlnaHQ6IDMzJTtcbiAgfVxuICAucm90YXRlIHtcbiAgICBhbmltYXRpb246IHJvdGF0aW9uIHJlbGF0aXZlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiByb3RhdGlvbjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNDBweDtcbiAgICB0b3A6IDM1NXB4O1xuICAgIC8qIGxlZnQ6IC0xMjVweDtcbiAgICB0b3A6IDI3MHB4OyAqL1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogNHM7XG4gICAgYW5pbWF0aW9uLWRlbGF5OiAxcztcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpOyAqL1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhdGlvbiB7XG4gICAgZnJvbSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZXooLTE4MGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgd2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7XG4gICAgfVxuICAgIHRvIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbi5zdWJfaW1ne1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIFxufVxuICBAa2V5ZnJhbWVzIHN1Yl9pbWcge1xuICAgIFxuICAgIGZyb20ge3dpZHRoOiAxMCU7IGhlaWdodDogMTAlO31cbiAgICB0byB7IHdpZHRoOiAxMTAlOyBoZWlnaHQ6IDExMCU7fVxuICB9XG4gIC5XZS1hcmUtaW1hZ2luaW5nIHtcbiAgICB3aWR0aDogNjI1cHg7XG4gICAgaGVpZ2h0OiAyMTBweDtcbiAgICBvcGFjaXR5OiAwLjk7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSm9pbi10aGUtbmV3LXdheS1vZi10aGUtd29ybGQge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuICAucGF0aDhcbiAge1xuICAgIHdpZHRoOjk1JVxuICB9XG5cbiAgLnN1YmNyaWJlXG4gIHtcbiAgICB3aWR0aDo5NSVcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjkge1xuICAgIGhlaWdodDogODVweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMmY5O1xuICAgIHdpZHRoOiA3OHB4O1xuICB9XG4gIC5SZWN0YW5nbGUtMjgge1xuICAgIHdpZHRoOiA2MjVweDtcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2YxZjJmOTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTMwIHtcbiAgICBcbiAgICAvKiB3aWR0aDogNDdweDsgKi9cbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTMxIHtcbiAgICBcbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgfVxuICAuUmVjdGFuZ2xlLTMzIHtcbiAgICBcbiAgICAvKiB3aWR0aDogNDdweDsgKi9cbiAgICBoZWlnaHQ6IDg1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlBhdGgtOSB7XG4gICAgLyogY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjhweDsgKi9cbiAgICBcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cblxuICAuUGF0aC04IHtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBmb250LXNpemU6IDI4cHg7XG4gICAgcGFkZGluZy1sZWZ0OiA1MCU7XG4gIH1cblxuICAubXVybXVyLTAzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDExMiU7XG4gICAgbWFyZ2luLWxlZnQ6IDglO1xuICAgIFxuICB9XG4gIFxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3Mge1xuICAgIHdpZHRoOiAzNThweDtcbiAgICBoZWlnaHQ6IDI3MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuODtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIFxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3M6aG92ZXIge1xuICAgIHdpZHRoOiAzNThweDtcbiAgICBoZWlnaHQ6IDI3MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuODtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiBcbiAgLmktb3Mge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkge1xuICAgIHdpZHRoOiAzMCU7XG4gICAgaGVpZ2h0OiA1MCU7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLk11cm11ci1BbGwtcmlnaHRzLXJlc2VydmVkIHtcbiAgICBoZWlnaHQ6IDIwcHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiA1LjE0O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tbGVmdDogNCU7XG4gICAgbWFyZ2luLXRvcDogMTclO1xuICB9XG5cbiAgLmljb25zN1xuICB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZy10b3A6IDE2NSU7XG4gICAgbWFyZ2luLWxlZnQ6IC0xMCU7XG4gIH1cblxuICAuaWNvbnM4XG4gIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nLXRvcDogMTY1JTtcbiAgICBtYXJnaW4tbGVmdDogLTEwJTtcbiAgfVxuXG4gIC5pY29uczlcbiAge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmctdG9wOiAxNTAlO1xuICAgIG1hcmdpbi1sZWZ0OiAtMTAlO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNCB7XG4gICBcbiAgICBoZWlnaHQ6IDgwMHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjUge1xuICAgXG4gICAgaGVpZ2h0OiA4MDBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI2IHtcbiAgIFxuICAgIGhlaWdodDogODAwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDBjZDliO1xuICB9XG5cbiAgLmlucHV0LWNvbnRhaW5lciB7XG4gICAgZGlzcGxheTogLW1zLWZsZXhib3g7IC8qIElFMTAgKi9cbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIH1cbiAgXG4gIC5pY29uIHtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIGJhY2tncm91bmQ6IGRvZGdlcmJsdWU7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1pbi13aWR0aDogNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cblxuICAuVGhhbmtzLW9yLXN1YnNjcmliaW5nIHtcbiAgICB3aWR0aDogMjI0cHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMi42NTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMGNkOWI7XG4gICAgcGFkZGluZy1sZWZ0OiA0JTtcbiAgfVxuXG4gIC5pbnB1dC1ncm91cCA+IC5mb3JtLWNvbnRyb2w6bm90KDpsYXN0LWNoaWxkKSwgLmlucHV0LWdyb3VwID4gLmN1c3RvbS1zZWxlY3Q6bm90KDpsYXN0LWNoaWxkKSB7XG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1yaWdodC1jb2xvcjojZmZmZmZmO1xufVxuXG4uaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtYXBwZW5kID4gLmJ0biwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLWFwcGVuZCA+IC5pbnB1dC1ncm91cC10ZXh0LCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpub3QoOmZpcnN0LWNoaWxkKSA+IC5idG4sIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmlucHV0LWdyb3VwLXRleHQsIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOmZpcnN0LWNoaWxkID4gLmJ0bjpub3QoOmZpcnN0LWNoaWxkKSwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6Zmlyc3QtY2hpbGQgPiAuaW5wdXQtZ3JvdXAtdGV4dDpub3QoOmZpcnN0LWNoaWxkKSB7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWxlZnQtY29sb3I6I2ZmZmZmZjtcbn1cbn1cbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjAwcHgpIHtcbiAgLnJld2FyZGluZ1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWJvdHRvbTogNSU7XG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgfVxuXG4gIC5tdXJtdXIyXG4gIHtcbiAgICBwYWRkaW5nLWxlZnQ6IDE1JTtcbiAgfVxuICAubXVybXVyM1xuICB7XG4gICAgcGFkZGluZy10b3A6IDEwJTtcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xuICB9XG5cbiAgLm11cm11cmltZzFcbiAge1xuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xuICB9XG5cbiAgLlRoZS1tb3N0LXJld2FyZGluZy1zb2NpYWwtbWVkaWEtcGxhdGZvcm0ge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDIxNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDVweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMTE7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmd7XG4gICAgd2lkdGg6IDM0NHB4O1xuICAgIGhlaWdodDogMTc1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAvKiB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyOyAqL1xuICB9XG5cbiAgLk11cm11ci1pcy1ldmVyeXRoaW5nOmhvdmVye1xuICAgIHdpZHRoOiAzNDRweDtcbiAgICBoZWlnaHQ6IDE3NXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5tdXJtdXItMDIge1xuICAgIC8qIHdpZHRoOiAxMDUwcHg7XG4gICAgaGVpZ2h0OiA3MDBweDsgKi9cbiAgICB3aWR0aDogMTI3JTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IC01OXB4O1xuICB9XG4gIFxuICAuUmVjdGFuZ2xlLTEwIHtcbiAgICB3aWR0aDogMTQ1cHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEwOmhvdmVyIHtcbiAgICB3aWR0aDogMTQ1cHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTEge1xuICAgIHdpZHRoOiAxNDVweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDYlO1xuICAgIG1hcmdpbi1sZWZ0OiA1JTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTE6aG92ZXIge1xuICAgIHdpZHRoOiAxNDVweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi1yaWdodDogNiU7XG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTE5cHg7XG4gICAgaGVpZ2h0OiAyMXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gICAgcGFkZGluZy1sZWZ0OiAxMCU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5MZWFybi1tb3JlIHtcbiAgICB3aWR0aDogOTNweDtcbiAgaGVpZ2h0OiAyMXB4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41NjtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZy1sZWZ0OiAyMCU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIH1cblxuICAvKiAuTGVhcm4tbW9yZTpob3ZlciB7XG4gICAgd2lkdGg6IDExNXB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgfSAqL1xuXG4gIC5XaHktTXVybXVyIHtcbiAgICB3aWR0aDogMzAwcHg7XG4gICAgaGVpZ2h0OiAxMTVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQ1cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjExO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIG1hcmdpbi10b3A6IDEwJTtcbiAgfVxuXG4gIC5XZS1iZWxpZXZlIHtcbiAgICB3aWR0aDogMzQycHg7XG4gIC8qIGhlaWdodDogMTI1cHg7ICovXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5XZS1iZWxpZXZlOmhvdmVyIHtcbiAgICB3aWR0aDogMzQycHg7XG4gIC8qIGhlaWdodDogMTI1cHg7ICovXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzAwMDAwMDtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICBcbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5pY29ucy0wNSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICB9XG4gIC5CdWlsdC1vbi1CbG9ja2NoYWluIHtcbiAgICB3aWR0aDogMzA0cHg7XG4gICAgaGVpZ2h0OiAxMTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNSU7XG4gICAgLyogcGFkZGluZy10b3A6IDYlOyAqL1xuICAgIG1hcmdpbi10b3A6IDE2JTtcbiAgfVxuXG4gIC5yZXdhcmRpbWdcbntcbiAgd2lkdGg6MTAwJTsgXG4gIGhlaWdodDoxMDUlO1xufVxuICAuUmV3YXJkaW5nLXRvLXVzZSB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIHdpZHRoOiAzNDFweDtcbiAgICBoZWlnaHQ6IDExMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwJTtcbiAgfVxuXG4gIC5QdWJsaXNoaW5nLWFuZC1lbmdhZ2luZyB7XG4gICAgLyogd2lkdGg6IDYyNXB4OyAqL1xuICAgIHdpZHRoOiAzMzBweDtcbiAgICBoZWlnaHQ6IDIxMnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xuICB9XG5cbiAgLlB1Ymxpc2hpbmctYW5kLWVuZ2FnaW5nOmhvdmVyIHtcbiAgICAvKiB3aWR0aDogNjI1cHg7ICovXG4gICAgd2lkdGg6IDMzMHB4O1xuICAgIGhlaWdodDogMjEycHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHBhZGRpbmctbGVmdDogNSU7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICAgIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTYzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICB9XG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDE5MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XG4gIH1cblxuICAuTXVybXVyLWlzLWEtcmV3YXJkaW5nOmhvdmVyIHtcbiAgICB3aWR0aDogMzQzcHg7XG4gICAgaGVpZ2h0OiAxOTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxNXB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLk11cm11ci1pcy1hLXJld2FyZGluZyAudGV4dC1zdHlsZS0xIHtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuICBcbiAgLkN1cnJlbnQtUGFydG5lcnMge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDExNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDVweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMTE7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgICBtYXJnaW4tdG9wOiAxMDBweDtcbiAgfVxuXG4gIC5tYXRpY1xuICB7XG4gICAgd2lkdGg6IDE5NnB4O1xuICAgIGhlaWdodDogNzVweDtcbiAgfVxuXG4gIC5iaWNvblxuICB7XG4gICAgd2lkdGg6IDI1M3B4O1xuICBoZWlnaHQ6IDc1cHg7XG4gIG1hcmdpbi1ib3R0b206IDk1cHg7XG5cbiAgfVxuICAuaWNvbnMtMDYge1xuICAgIC8qIHdpZHRoOiA3MTBweDtcbiAgICBoZWlnaHQ6IDc0NnB4OyAqL1xuICAgIHdpZHRoOiA1NjZweDtcbiAgICBoZWlnaHQ6IDUyOXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAtNzdweDtcblxuICB9XG5cbiAgLk11cm11ci1mb3ItbW9iaWxlIHtcbiAgICB3aWR0aDogMzQzcHg7XG4gICAgaGVpZ2h0OiAxMjBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQ1cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjExO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIHBhZGRpbmctbGVmdDogNjZweDtcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xuICB9XG5cbiAgXG4gIC5Vc2UtTXVybXVyIHtcbiAgICB3aWR0aDogMzc3cHg7XG4gICAgaGVpZ2h0OiAxNjJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMzk7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy1sZWZ0OiAzN3B4O1xuICB9XG5cbiAgLkltbWVkaWF0ZS1ibG9ja2NoYWluLWlkLWNyZWF0aW9uLU5vLXdhaXQtdGltZSB7XG4gICAgd2lkdGg6IDM4NXB4O1xuICAgIC8qIGhlaWdodDogNjBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMzk7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy1sZWZ0OiAzNXB4O1xuICB9XG5cbiAgLk5vLXdhaXQtdGltZSB7XG4gICAgd2lkdGg6IDM4NXB4O1xuICAgIC8qIGhlaWdodDogNjBweDsgKi9cbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMzk7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy1sZWZ0OiA2cHg7XG4gICAgXG4gIH1cbiAgLyogLm1haW5faW1nIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9ICovXG5cbiAgLmktb3MxIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIG1hcmdpbi1sZWZ0OiA1NHB4O1xuICAgIC8qIHBhZGRpbmctbGVmdDogLTNweDsgKi9cbiAgICBtYXJnaW4tcmlnaHQ6IDhweDtcbiAgfVxuXG4gIC5Hb29nbGVQbGF5MSB7XG4gICAgd2lkdGg6IDE1MHB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIH1cbiAgLnJvdGF0ZSB7XG4gICAgYW5pbWF0aW9uOiByb3RhdGlvbiByZWxhdGl2ZTtcbiAgICBhbmltYXRpb24tbmFtZTogcm90YXRpb247XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDQwcHg7XG4gICAgdG9wOiAzNTVweDtcbiAgICAvKiBsZWZ0OiAtMTI1cHg7XG4gICAgdG9wOiAyNzBweDsgKi9cbiAgICB6LWluZGV4OiAtMTtcbiAgICBhbmltYXRpb24tZHVyYXRpb246IDRzO1xuICAgIGFuaW1hdGlvbi1kZWxheTogMXM7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICAvKiB0cmFuc2Zvcm06IHJvdGF0ZVooLTkwZGVnKTsgKi9cbiAgfVxuXG4gIEBrZXlmcmFtZXMgcm90YXRpb24ge1xuICAgIGZyb20ge1xuICAgICAgdHJhbnNmb3JtOiByb3RhdGV6KC0xODBkZWcpO1xuICAgICAgbGVmdDogNDBweDtcbiAgICAgIHRvcDogMjVweDtcbiAgICAgIHdpZHRoOiAxMCU7IGhlaWdodDogMTAlO1xuICAgIH1cbiAgICB0byB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZVooMGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgZGlzcGxheTogbm9uZTtcbiAgICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDEwMCU7XG4gICAgfVxuICB9XG4uc3ViX2ltZ3tcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogLTE7XG4gIGFuaW1hdGlvbi1uYW1lOiBzdWJfaW1nO1xuICBhbmltYXRpb24tZHVyYXRpb246IDNzO1xuICBcbn1cbiAgQGtleWZyYW1lcyBzdWJfaW1nIHtcbiAgICBcbiAgICBmcm9tIHt3aWR0aDogMTAlOyBoZWlnaHQ6IDEwJTt9XG4gICAgdG8geyB3aWR0aDogMTEwJTsgaGVpZ2h0OiAxMTAlO31cbiAgfVxuICAuV2UtYXJlLWltYWdpbmluZyB7XG4gICAgd2lkdGg6IDM0M3B4O1xuICAgIGhlaWdodDogMzYxcHg7XG4gICAgb3BhY2l0eTogMC45O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICB9XG5cbiAgLkpvaW4tdGhlLW5ldy13YXktb2YtdGhlLXdvcmxkIHtcbiAgICB3aWR0aDogMzQzcHg7XG4gICAgaGVpZ2h0OiAxNTlweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5wYXRoOFxuICB7XG4gICAgd2lkdGg6IDM0Mi41cHg7XG4gICAgaGVpZ2h0OiAzMi45cHg7XG4gIFxuICB9XG5cbiAgLnN1YmNyaWJlXG4gIHtcbiAgICB3aWR0aDogMzQzcHg7XG4gIH1cbiAgLlJlY3RhbmdsZS0yOSB7XG4gICAgXG4gIGhlaWdodDogNDdweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YxZjJmOTtcbiAgfVxuICAuUmVjdGFuZ2xlLTI4IHtcbiAgICB3aWR0aDogMzQzcHg7XG4gICAgaGVpZ2h0OiA0N3B4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2YxZjJmOTtcbiAgICAvKiBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmOyAqL1xuICAgIHBhZGRpbmctdG9wOiAwJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTMwIHtcbiAgICB3aWR0aDogNDdweDtcbiAgICBoZWlnaHQ6IDQ3cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTMxIHtcbiAgIFxuICAgIGhlaWdodDogNDdweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICB9XG4gIC5SZWN0YW5nbGUtMzMge1xuICAgIHdpZHRoOiA0N3B4O1xuICAgIGhlaWdodDogNDdweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIHdpZHRoOiA3OHB4O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUGF0aC05IHtcbiAgICAvKiBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyOHB4OyAqL1xuICAgIFxuICAgIC8qIHBhZGRpbmctbGVmdDogMTBweDsgKi9cbiAgfVxuXG4gIC5QYXRoLTgge1xuICAgIGNvbG9yOiAjZjFmMmY5O1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE5JTtcbiAgfVxuXG4gIC5tdXJtdXItMDMge1xuICAgIHdpZHRoOiAxMTUlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDogLTclO1xuICAgIFxuICB9XG4gIFxuICAuRm9ydW1zLUJsb2ctRG9jcy1Ub2tlbi1FY29ub21pY3Mge1xuICAgIHdpZHRoOiAzMjNweDtcbiAgaGVpZ2h0OiAyNjdweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMzZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAyO1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5Gb3J1bXMtQmxvZy1Eb2NzLVRva2VuLUVjb25vbWljczpob3ZlciB7XG4gICAgd2lkdGg6IDMyM3B4O1xuICBoZWlnaHQ6IDI2N3B4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAzNnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDI7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiAjMDAwMDAwO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICBcbiAgLmktb3Mge1xuICAgIHdpZHRoOiAxNjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkge1xuICAgIHdpZHRoOiAxNjVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICAgIC8qIG1hcmdpbi1sZWZ0OiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4OyAqL1xuICB9XG5cbiAgLk11cm11ci1BbGwtcmlnaHRzLXJlc2VydmVkIHtcbiAgICAvKiB3aWR0aDogMjQxcHg7ICovXG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogNS4xNDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgICBwYWRkaW5nLWxlZnQ6IDUycHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNDBweDtcbiAgfVxuXG4gIC5pY29uczdcbiAge1xuICAgIHdpZHRoOiAwJTtcbiAgICBwYWRkaW5nLXRvcDogMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICB9XG5cbiAgLmljb25zOFxuICB7XG4gICAgd2lkdGg6IDAlO1xuICAgIHBhZGRpbmctdG9wOiAwJTtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gIH1cblxuICAuaWNvbnM5XG4gIHtcbiAgICB3aWR0aDogMCU7XG4gICAgcGFkZGluZy10b3A6IDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjQge1xuICAgXG4gICAgLyogd2lkdGg6IDM3NXB4OyAqL1xuICBoZWlnaHQ6IDEyNjBweDtcbiAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5SZWN0YW5nbGUtMjUge1xuICAgXG4gICAgaGVpZ2h0OiAxMjYwcHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggIzcwNzA3MDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmNjMTNjO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNiB7XG4gICBcbiAgICBoZWlnaHQ6IDEyNjBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMGNkOWI7XG4gIH1cblxuICAuaW5wdXQtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiAtbXMtZmxleGJveDsgLyogSUUxMCAqL1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgfVxuICBcbiAgLmljb24ge1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgYmFja2dyb3VuZDogZG9kZ2VyYmx1ZTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWluLXdpZHRoOiA1MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuXG4gIC5UaGFua3Mtb3Itc3Vic2NyaWJpbmcge1xuICAgIHdpZHRoOiAyMjRweDtcbiAgICBoZWlnaHQ6IDI4cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAyLjY1O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBjb2xvcjogIzAwY2Q5YjtcbiAgICBwYWRkaW5nLWxlZnQ6IDQlO1xuICB9XG5cbiAgLmlucHV0LWdyb3VwID4gLmZvcm0tY29udHJvbDpub3QoOmxhc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuY3VzdG9tLXNlbGVjdDpub3QoOmxhc3QtY2hpbGQpIHtcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLXJpZ2h0LWNvbG9yOiNmZmZmZmY7XG59XG5cbi5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtYXBwZW5kID4gLmlucHV0LWdyb3VwLXRleHQsIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOm5vdCg6Zmlyc3QtY2hpbGQpID4gLmJ0biwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6Zmlyc3QtY2hpbGQgPiAuYnRuOm5vdCg6Zmlyc3QtY2hpbGQpLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5pbnB1dC1ncm91cC10ZXh0Om5vdCg6Zmlyc3QtY2hpbGQpIHtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xuICBib3JkZXItbGVmdC1jb2xvcjojZmZmZmZmO1xuICB3aWR0aDogNDdweDtcbn1cbn1cblxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNjBweCkge1xuICAucmV3YXJkaW5nXG4gIHtcbiAgICBwYWRkaW5nLXRvcDogMTAlO1xuICAgIHBhZGRpbmctYm90dG9tOiA1JTtcbiAgICBwYWRkaW5nLWxlZnQ6IDUlO1xuICB9XG5cbiAgLm11cm11cjJcbiAge1xuICAgIHBhZGRpbmctbGVmdDogMTUlO1xuICB9XG4gIC5tdXJtdXIzXG4gIHtcbiAgICBwYWRkaW5nLXRvcDogMTAlO1xuICAgIHBhZGRpbmctbGVmdDogNSU7XG4gIH1cblxuICAubXVybXVyaW1nMVxuICB7XG4gICAgbWFyZ2luLXRvcDogLTMwcHg7XG4gIH1cblxuICAuVGhlLW1vc3QtcmV3YXJkaW5nLXNvY2lhbC1tZWRpYS1wbGF0Zm9ybSB7XG4gICAgd2lkdGg6IDM0M3B4O1xuICAgIGhlaWdodDogMjE1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0NXB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4xMTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuXG4gIC5NdXJtdXItaXMtZXZlcnl0aGluZ3tcbiAgICB3aWR0aDogMzQ0cHg7XG4gICAgaGVpZ2h0OiAxNzVweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIC8qIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7ICovXG4gIH1cblxuICAuTXVybXVyLWlzLWV2ZXJ5dGhpbmc6aG92ZXJ7XG4gICAgd2lkdGg6IDM0NHB4O1xuICAgIGhlaWdodDogMTc1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogIzgwNjlmZjtcbiAgICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLm11cm11ci0wMiB7XG4gICAgd2lkdGg6IDEyNSU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHBhZGRpbmctbGVmdDogLTU5cHg7ICovXG4gICAgbWFyZ2luLWxlZnQ6IC01MXB4O1xuICAgIHBhZGRpbmctdG9wOiA4MHB4O1xuICB9XG4gIFxuICAuUmVjdGFuZ2xlLTEwIHtcbiAgICB3aWR0aDogMTQ1cHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTEwOmhvdmVyIHtcbiAgICB3aWR0aDogMTQ1cHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTEge1xuICAgIHdpZHRoOiAxNDVweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzgwNjlmZjtcbiAgICBtYXJnaW4tcmlnaHQ6IDIlO1xuICAgIG1hcmdpbi1sZWZ0OiAyJTtcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC5SZWN0YW5nbGUtMTE6aG92ZXIge1xuICAgIHdpZHRoOiAxNDVweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi1yaWdodDogMiU7XG4gICAgbWFyZ2luLWxlZnQ6IDIlO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuRG93bmxvYWQtQXBwIHtcbiAgICB3aWR0aDogMTE5cHg7XG4gICAgaGVpZ2h0OiAyMXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgLyogY29sb3I6ICMwMDAwMDA7ICovXG4gIHBhZGRpbmctbGVmdDogMTAlO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuTGVhcm4tbW9yZSB7XG4gICAgd2lkdGg6IDkzcHg7XG4gIGhlaWdodDogMjFweDtcbiAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBhZGRpbmctbGVmdDogMTglO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIGNvbG9yOiAjMDAwMDAwOyAqL1xuICB9XG5cbiAgLyogLkxlYXJuLW1vcmU6aG92ZXIge1xuICAgIHdpZHRoOiAxMTVweDtcbiAgaGVpZ2h0OiAyOHB4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogd2hpdGU7XG4gIH0gKi9cblxuICAuV2h5LU11cm11ciB7XG4gICAgd2lkdGg6IDI2OXB4O1xuICAgIGhlaWdodDogMTE1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0NXB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4xMTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBtYXJnaW4tdG9wOiAxMCU7XG4gIH1cblxuICAuV2UtYmVsaWV2ZSB7XG4gICAgd2lkdGg6IDM0MnB4O1xuICAvKiBoZWlnaHQ6IDEyNXB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41NjtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuV2UtYmVsaWV2ZTpob3ZlciB7XG4gICAgd2lkdGg6IDM0MnB4O1xuICAvKiBoZWlnaHQ6IDEyNXB4OyAqL1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMS41NjtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gIHRleHQtdW5kZXJsaW5lLXBvc2l0aW9uOiB1bmRlcjtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlYWQtTW9yZSB7XG4gICAgd2lkdGg6IDExMHB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGxpbmUtaGVpZ2h0OiAxLjU2O1xuICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuXG4gIC5pY29ucy0wNSB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAwcHg7XG4gIH1cbiAgLkJ1aWx0LW9uLUJsb2NrY2hhaW4ge1xuICAgIHdpZHRoOiAyOTJweDs7XG4gICAgaGVpZ2h0OiAxMTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgICAvKiBwYWRkaW5nLXRvcDogNiU7ICovXG4gICAgbWFyZ2luLXRvcDogMTYlO1xuICB9XG5cbiAgLnJld2FyZGltZ1xue1xuICB3aWR0aDoxMDAlOyBcbiAgaGVpZ2h0OjEwNSU7XG59XG5cbiAgLlJld2FyZGluZy10by11c2Uge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICB3aWR0aDogMjkwcHg7XG4gICAgaGVpZ2h0OiAxMTBweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiAxMCU7XG4gIH1cblxuICAuUHVibGlzaGluZy1hbmQtZW5nYWdpbmcge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICB3aWR0aDogMjgwcHg7XG4gICAgaGVpZ2h0OiAyMTJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAuUHVibGlzaGluZy1hbmQtZW5nYWdpbmc6aG92ZXIge1xuICAgIC8qIHdpZHRoOiA2MjVweDsgKi9cbiAgICB3aWR0aDogMjgwcHg7XG4gICAgaGVpZ2h0OiAyMTJweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTY7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgcGFkZGluZy1sZWZ0OiA1JTtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAuUmVjdGFuZ2xlLTYzIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICB9XG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmcge1xuICAgIHdpZHRoOiAyOTRweDtcbiAgICBoZWlnaHQ6IDE5MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAxNXB4OyAqL1xuICB9XG4gIC5NdXJtdXItaXMtYS1yZXdhcmRpbmc6aG92ZXIge1xuICAgIHdpZHRoOiAyOTRweDtcbiAgICBoZWlnaHQ6IDE5MHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41NjtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICB0ZXh0LWRlY29yYXRpb24tY29sb3I6ICM4MDY5ZmY7XG4gICAgdGV4dC11bmRlcmxpbmUtcG9zaXRpb246IHVuZGVyO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAvKiBwYWRkaW5nLWxlZnQ6IDE1cHg7ICovXG4gIH1cbiAgLk11cm11ci1pcy1hLXJld2FyZGluZyAudGV4dC1zdHlsZS0xIHtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgfVxuICBcbiAgLkN1cnJlbnQtUGFydG5lcnMge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDExNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDVweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMTE7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgICBtYXJnaW4tdG9wOiAxMDBweDtcbiAgfVxuXG4gIC5tYXRpY1xuICB7XG4gICAgd2lkdGg6IDE5NnB4O1xuICAgIGhlaWdodDogNzVweDtcbiAgfVxuXG4gIC5iaWNvblxuICB7XG4gICAgd2lkdGg6IDI1M3B4O1xuICBoZWlnaHQ6IDc1cHg7XG4gIG1hcmdpbi1ib3R0b206IDk1cHg7XG5cbiAgfVxuICAuaWNvbnMtMDYge1xuICAgIHdpZHRoOiA1MzFweDtcbiAgICBoZWlnaHQ6IDUzNXB4O1xuICAgIG1hcmdpbi1sZWZ0OiAtMTAwcHg7XG4gIH1cblxuICAuTXVybXVyLWZvci1tb2JpbGUge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDEyMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDVweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMTE7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6ICNmMWYyZjk7XG4gICAgcGFkZGluZy1sZWZ0OiAxNHB4O1xuICAgIHBhZGRpbmctdG9wOiAwcHg7XG4gIH1cblxuICBcbiAgLlVzZS1NdXJtdXIge1xuICAgIHdpZHRoOiAzMjBweDtcbiAgICBoZWlnaHQ6IDE2MnB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zOTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLWxlZnQ6IDM3cHg7XG4gIH1cblxuICAuSW1tZWRpYXRlLWJsb2NrY2hhaW4taWQtY3JlYXRpb24tTm8td2FpdC10aW1lIHtcbiAgICB3aWR0aDogMzE2cHg7XG4gICAgLyogaGVpZ2h0OiA2MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zOTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLWxlZnQ6IDM1cHg7XG4gIH1cblxuICAuTm8td2FpdC10aW1lIHtcbiAgICB3aWR0aDogMzQwcHg7XG4gICAgLyogaGVpZ2h0OiA2MHB4OyAqL1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4zOTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBwYWRkaW5nLWxlZnQ6IDZweDtcbiAgICBcbiAgfVxuICAvKiAubWFpbl9pbWcge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH0gKi9cblxuICAuaS1vczEge1xuICAgIHdpZHRoOiAxNTBweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIxcHg7XG4gICAgLyogcGFkZGluZy1sZWZ0OiAtM3B4OyAqL1xuICAgIG1hcmdpbi1yaWdodDogOHB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkxIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gIGhlaWdodDogNDVweDtcbiAgfVxuICAucm90YXRlIHtcbiAgICBhbmltYXRpb246IHJvdGF0aW9uIHJlbGF0aXZlO1xuICAgIGFuaW1hdGlvbi1uYW1lOiByb3RhdGlvbjtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogNDBweDtcbiAgICB0b3A6IDM1NXB4O1xuICAgIC8qIGxlZnQ6IC0xMjVweDtcbiAgICB0b3A6IDI3MHB4OyAqL1xuICAgIHotaW5kZXg6IC0xO1xuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogNHM7XG4gICAgYW5pbWF0aW9uLWRlbGF5OiAxcztcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlO1xuICAgIC8qIHRyYW5zZm9ybTogcm90YXRlWigtOTBkZWcpOyAqL1xuICB9XG5cbiAgQGtleWZyYW1lcyByb3RhdGlvbiB7XG4gICAgZnJvbSB7XG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZXooLTE4MGRlZyk7XG4gICAgICBsZWZ0OiA0MHB4O1xuICAgICAgdG9wOiAyNXB4O1xuICAgICAgd2lkdGg6IDEwJTsgaGVpZ2h0OiAxMCU7XG4gICAgfVxuICAgIHRvIHtcbiAgICAgIHRyYW5zZm9ybTogcm90YXRlWigwZGVnKTtcbiAgICAgIGxlZnQ6IDQwcHg7XG4gICAgICB0b3A6IDI1cHg7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJTtcbiAgICB9XG4gIH1cbi5zdWJfaW1ne1xuICBhbmltYXRpb24tbmFtZTogc3ViX2ltZztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAtMTtcbiAgYW5pbWF0aW9uLW5hbWU6IHN1Yl9pbWc7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7XG4gIFxufVxuICBAa2V5ZnJhbWVzIHN1Yl9pbWcge1xuICAgIFxuICAgIGZyb20ge3dpZHRoOiAxMCU7IGhlaWdodDogMTAlO31cbiAgICB0byB7IHdpZHRoOiAxMTAlOyBoZWlnaHQ6IDExMCU7fVxuICB9XG4gIC5XZS1hcmUtaW1hZ2luaW5nIHtcbiAgICB3aWR0aDogMzQzcHg7XG4gICAgaGVpZ2h0OiAzNjFweDtcbiAgICBvcGFjaXR5OiAwLjk7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS4yNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gIH1cblxuICAuSm9pbi10aGUtbmV3LXdheS1vZi10aGUtd29ybGQge1xuICAgIHdpZHRoOiAzNDNweDtcbiAgICBoZWlnaHQ6IDE1OXB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuMjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLnBhdGg4XG4gIHtcbiAgICB3aWR0aDogMzE1LjVweDtcbiAgICBoZWlnaHQ6IDQxLjlweDtcbiAgXG4gIH1cblxuICAuc3ViY3JpYmVcbiAge1xuICAgIHdpZHRoOiAzMTUuNXB4O1xuICB9XG4gIC5SZWN0YW5nbGUtMjkge1xuICAgIFxuICBoZWlnaHQ6IDQ3cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmMWYyZjk7XG4gIH1cbiAgLlJlY3RhbmdsZS0yOCB7XG4gICAgd2lkdGg6IDM0M3B4O1xuICAgIGhlaWdodDogNDdweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIGJvcmRlcjogc29saWQgMXB4ICNmMWYyZjk7XG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjsgKi9cbiAgICBwYWRkaW5nLXRvcDogMCU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0zMCB7XG4gICAgd2lkdGg6IDQ3cHg7XG4gICAgaGVpZ2h0OiA0N3B4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4MDY5ZmY7XG4gICAgd2lkdGg6IDc4cHg7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLlJlY3RhbmdsZS0zMSB7XG4gICBcbiAgICBoZWlnaHQ6IDQ3cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgfVxuICAuUmVjdGFuZ2xlLTMzIHtcbiAgICB3aWR0aDogNDdweDtcbiAgICBoZWlnaHQ6IDQ3cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgICB3aWR0aDogNzhweDtcbiAgICBjb2xvcjogIzgwNjlmZjtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbiAgLlBhdGgtOSB7XG4gICAgLyogY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMjhweDsgKi9cbiAgICBcbiAgICAvKiBwYWRkaW5nLWxlZnQ6IDEwcHg7ICovXG4gIH1cblxuICAuUGF0aC04IHtcbiAgICBjb2xvcjogI2YxZjJmOTtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxOSU7XG4gIH1cblxuICAubXVybXVyLTAzIHtcbiAgICB3aWR0aDogMTE5JTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IC05JTtcbiAgICBcbiAgfVxuICBcbiAgLkZvcnVtcy1CbG9nLURvY3MtVG9rZW4tRWNvbm9taWNzIHtcbiAgICB3aWR0aDogMzIzcHg7XG4gIGhlaWdodDogMjY3cHg7XG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICBmb250LXNpemU6IDM0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBsaW5lLWhlaWdodDogMjtcbiAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG4gIC5Gb3J1bXMtQmxvZy1Eb2NzLVRva2VuLUVjb25vbWljczpob3ZlciB7XG4gICAgd2lkdGg6IDMyM3B4O1xuICBoZWlnaHQ6IDI2N3B4O1xuICBmb250LWZhbWlseTogUG9wcGlucztcbiAgZm9udC1zaXplOiAzNHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgbGluZS1oZWlnaHQ6IDI7XG4gIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiAjMDAwMDAwO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgdGV4dC1kZWNvcmF0aW9uLWNvbG9yOiAjODA2OWZmO1xuICB0ZXh0LXVuZGVybGluZS1wb3NpdGlvbjogdW5kZXI7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICBcbiAgLmktb3Mge1xuICAgIHdpZHRoOiAxNTVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICB9XG5cbiAgLkdvb2dsZVBsYXkge1xuICAgIHdpZHRoOiAxNTVweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxOHB4O1xuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICAgIC8qIG1hcmdpbi1sZWZ0OiAwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4OyAqL1xuICB9XG5cbiAgLk11cm11ci1BbGwtcmlnaHRzLXJlc2VydmVkIHtcbiAgICAvKiB3aWR0aDogMjQxcHg7ICovXG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogNS4xNDtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7ICBcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogNDBweDtcbiAgfVxuXG4gIC8qIC5pY29uN1xuICB7XG4gICAgd2lkdGg6MCU7XG4gICAgIHBhZGRpbmctdG9wOiAxNTUlO1xuICAgIG1hcmdpbi1sZWZ0OiAxNSUgXG4gIH0gKi9cbiAgLmljb25zN1xuICB7XG4gICAgd2lkdGg6IDAlO1xuICAgIHBhZGRpbmctdG9wOiAwJTtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gIH1cblxuICAuaWNvbnM4XG4gIHtcbiAgICB3aWR0aDogMCU7XG4gICAgcGFkZGluZy10b3A6IDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgfVxuXG4gIC5pY29uczlcbiAge1xuICAgIHdpZHRoOiAwJTtcbiAgICBwYWRkaW5nLXRvcDogMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNCB7XG4gICBcbiAgICAvKiB3aWR0aDogMzc1cHg7ICovXG4gIGhlaWdodDogMTI2MHB4O1xuICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjODA2OWZmO1xuICB9XG5cbiAgLlJlY3RhbmdsZS0yNSB7XG4gICBcbiAgICBoZWlnaHQ6IDEyNjBweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjNzA3MDcwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmY2MxM2M7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTI2IHtcbiAgIFxuICAgIGhlaWdodDogMTI2MHB4O1xuICAgIGJvcmRlcjogc29saWQgMXB4ICM3MDcwNzA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwY2Q5YjtcbiAgfVxuXG4gIC5pbnB1dC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94OyAvKiBJRTEwICovXG4gICAgZGlzcGxheTogZmxleDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICB9XG4gIFxuICAuaWNvbiB7XG4gICAgcGFkZGluZzogMTBweDtcbiAgICBiYWNrZ3JvdW5kOiBkb2RnZXJibHVlO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBtaW4td2lkdGg6IDUwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB9XG5cbiAgLlRoYW5rcy1vci1zdWJzY3JpYmluZyB7XG4gICAgd2lkdGg6IDIyNHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDEwcHg7XG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDIuNjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDBjZDliO1xuICAgIHBhZGRpbmctbGVmdDogNCU7XG4gIH1cblxuICAuaW5wdXQtZ3JvdXAgPiAuZm9ybS1jb250cm9sOm5vdCg6bGFzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5jdXN0b20tc2VsZWN0Om5vdCg6bGFzdC1jaGlsZCkge1xuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwO1xuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcbiAgICBib3JkZXItcmlnaHQtY29sb3I6I2ZmZmZmZjtcbn1cblxuLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLWFwcGVuZCA+IC5idG4sIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1hcHBlbmQgPiAuaW5wdXQtZ3JvdXAtdGV4dCwgLmlucHV0LWdyb3VwID4gLmlucHV0LWdyb3VwLXByZXBlbmQ6bm90KDpmaXJzdC1jaGlsZCkgPiAuYnRuLCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpub3QoOmZpcnN0LWNoaWxkKSA+IC5pbnB1dC1ncm91cC10ZXh0LCAuaW5wdXQtZ3JvdXAgPiAuaW5wdXQtZ3JvdXAtcHJlcGVuZDpmaXJzdC1jaGlsZCA+IC5idG46bm90KDpmaXJzdC1jaGlsZCksIC5pbnB1dC1ncm91cCA+IC5pbnB1dC1ncm91cC1wcmVwZW5kOmZpcnN0LWNoaWxkID4gLmlucHV0LWdyb3VwLXRleHQ6bm90KDpmaXJzdC1jaGlsZCkge1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiNmZmZmZmY7XG4gIHdpZHRoOiA0N3B4O1xufVxufSJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-home',
            templateUrl: './home.component.html',
            styleUrls: ['./home.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "./src/app/component/navbar/navbar.component.ts":
    /*!******************************************************!*\
      !*** ./src/app/component/navbar/navbar.component.ts ***!
      \******************************************************/

    /*! exports provided: NavbarComponent */

    /***/
    function srcAppComponentNavbarNavbarComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NavbarComponent", function () {
        return NavbarComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");

      function NavbarComponent_span_4_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "MENU");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function NavbarComponent_span_5_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "BACK");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      var NavbarComponent = /*#__PURE__*/function () {
        function NavbarComponent() {
          _classCallCheck(this, NavbarComponent);

          this.status = false;
        }

        _createClass(NavbarComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "menustatus",
          value: function menustatus() {
            if (this.status) {
              this.status = false;
            } else {
              this.status = true;
            }
          }
        }]);

        return NavbarComponent;
      }();

      NavbarComponent.ɵfac = function NavbarComponent_Factory(t) {
        return new (t || NavbarComponent)();
      };

      NavbarComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: NavbarComponent,
        selectors: [["app-navbar"]],
        decls: 18,
        vars: 2,
        consts: [[1, "container-fluid", "navbar", "sticky-top", "navbar-expand-md", "navbar-dark", 2, "background-color", "#ffffff"], [1, "container"], ["src", "../assets/images/DEC-Logos-01.png", "routerLink", "/Home", 1, "murmurlogo"], ["data-toggle", "collapse", "data-target", "#collapsibleNavbar", 1, "navbar-toggler", "Rectangle-91", 3, "click"], ["class", "menu", "data-toggle", "collapse", "data-target", "#collapsibleNavbar", 4, "ngIf"], ["id", "collapsibleNavbar", 1, "collapse", "navbar-collapse"], [1, "navbar-nav", "ml-auto", "pr-5"], [1, "nav-item", "active", "pl-3", "pr-3", 2, "padding-top", "5%"], ["routerLink", "/Home", "routerLinkActive", "active", 1, "HOME"], [1, "nav-item", "pl-3", "pr-3", 2, "padding-top", "5%"], ["routerLink", "/About", "routerLinkActive", "active", 1, "ABOUT-US"], [1, "nav-item", "pl-3", "pr-3", 2, "padding-top", "2%"], [1, "Rectangle-7"], ["href", "#", 1, "CONTACT"], ["data-toggle", "collapse", "data-target", "#collapsibleNavbar", 1, "menu"]],
        template: function NavbarComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function NavbarComponent_Template_div_click_3_listener() {
              return ctx.menustatus();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, NavbarComponent_span_4_Template, 2, 0, "span", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, NavbarComponent_span_5_Template, 2, 0, "span", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ul", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "a", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "HOME ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "li", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "a", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "ABOUT US");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "li", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "a", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "CONTACT");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.status);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
          }
        },
        directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkWithHref"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkActive"]],
        styles: ["nav[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    \n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n    \n  }\n  .nav-heading[_ngcontent-%COMP%] {\n    width: 29.7px;\n    height: 19.3px;\n    color: #7000d3;\n    font-family: Poppins;\n  }\n  .HOME[_ngcontent-%COMP%] {\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    \n  }\n  .HOME.active[_ngcontent-%COMP%]{\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #7000d3;\n    \n  }\n  .ABOUT-US[_ngcontent-%COMP%] {\n    width: 60px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #000000;\n    \n  }\n  .ABOUT-US.active[_ngcontent-%COMP%] {\n    width: 100px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: 600;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    color: #7000d3;\n    \n  }\n  .CONTACT[_ngcontent-%COMP%] {\n    width: 97px;\n    height: 28px;\n    font-family: Poppins;\n    font-size: 20px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.5;\n    letter-spacing: normal;\n    text-align: left;\n    text-decoration:none;\n    padding-left: 24%;\n    color: #fcc13c;\n  }\n  .Rectangle-7[_ngcontent-%COMP%] {\n    width: 195px;\n    height: 65px;\n    border: solid 1px #fcc13c;\n    padding-top: 16px;\n  }\n  .Rectangle-91[_ngcontent-%COMP%] {\n    width: 90px;\n    height: 45px;\n    border: solid 1px #fcc13c;\n    color: #fcc13c;\n    padding-top: 3%;\n  }\n  .Rectangle-91[_ngcontent-%COMP%]:hover {\n    width: 90px;\n    height: 45px;\n    \n    background: #000000;\n    color:white;\n    padding-top: 3%;\n  }\n  .menu[_ngcontent-%COMP%] {\n    width: 50px;\n    height: 25px;\n    font-family: Poppins;\n    font-size: 18px;\n    font-weight: normal;\n    font-stretch: normal;\n    font-style: normal;\n    line-height: 1.11;\n    letter-spacing: normal;\n    text-align: left;\n    padding-left: 7px;\n  }\n  .murmurlogo[_ngcontent-%COMP%]\n  {\n    width:20%;\n    cursor: pointer;\n  }\n  @media only screen and (max-width: 600px) {\n    .murmurlogo[_ngcontent-%COMP%]\n  {\n    width:40%\n  }\n  }\n  @media only screen and (max-width: 360px) {\n    .murmurlogo[_ngcontent-%COMP%]\n  {\n    width:40%\n  }\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50L25hdmJhci9uYXZiYXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG9CQUFvQjtFQUN0QjtFQUNBO0lBQ0Usb0JBQW9CO0VBQ3RCO0VBRUE7SUFDRSxhQUFhO0lBQ2IsY0FBYztJQUNkLGNBQWM7SUFDZCxvQkFBb0I7RUFDdEI7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFDZCwwQkFBMEI7RUFDNUI7RUFFQTtJQUNFLFlBQVk7SUFDWixZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0VBQzVCO0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2Ysb0JBQW9CO0lBQ3BCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QsMEJBQTBCO0VBQzVCO0VBRUE7SUFDRSxZQUFZO0lBQ1osWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDBCQUEwQjtFQUM1QjtFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWixvQkFBb0I7SUFDcEIsZUFBZTtJQUNmLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLG9CQUFvQjtJQUNwQixpQkFBaUI7SUFDakIsY0FBYztFQUNoQjtFQUdBO0lBQ0UsWUFBWTtJQUNaLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsaUJBQWlCO0VBQ25CO0VBR0E7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixjQUFjO0lBQ2QsZUFBZTtFQUNqQjtFQUVBO0lBQ0UsV0FBVztJQUNYLFlBQVk7SUFDWiwrQkFBK0I7SUFDL0IsbUJBQW1CO0lBQ25CLFdBQVc7SUFDWCxlQUFlO0VBQ2pCO0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsaUJBQWlCO0VBQ25CO0VBRUE7O0lBRUUsU0FBUztJQUNULGVBQWU7RUFDakI7RUFDQTtJQUNFOztJQUVBO0VBQ0Y7RUFDQTtFQUNBO0lBQ0U7O0lBRUE7RUFDRjtFQUNBIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50L25hdmJhci9uYXZiYXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIm5hdiB1bCBsaSBhOmhvdmVyIHtcbiAgICAvKiBjb2xvcjogIzAyMjI1YjsgKi9cbiAgfVxuICBuYXYgYTpob3ZlciB7XG4gICAgLyogY29sb3I6ICMwMjIyNWI7ICovXG4gIH1cblxuICAubmF2LWhlYWRpbmcge1xuICAgIHdpZHRoOiAyOS43cHg7XG4gICAgaGVpZ2h0OiAxOS4zcHg7XG4gICAgY29sb3I6ICM3MDAwZDM7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gIH1cblxuICAuSE9NRSB7XG4gICAgd2lkdGg6IDYwcHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICMwMDAwMDA7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOm5vbmU7ICovXG4gIH1cblxuICAuSE9NRS5hY3RpdmV7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICM3MDAwZDM7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOm5vbmU7ICovXG4gIH1cblxuICAuQUJPVVQtVVMge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjU7XG4gICAgbGV0dGVyLXNwYWNpbmc6IG5vcm1hbDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIC8qIHRleHQtZGVjb3JhdGlvbjpub25lOyAqL1xuICB9XG5cbiAgLkFCT1VULVVTLmFjdGl2ZSB7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGhlaWdodDogMjhweDtcbiAgICBmb250LWZhbWlseTogUG9wcGlucztcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXN0cmV0Y2g6IG5vcm1hbDtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgbGluZS1oZWlnaHQ6IDEuNTtcbiAgICBsZXR0ZXItc3BhY2luZzogbm9ybWFsO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICM3MDAwZDM7XG4gICAgLyogdGV4dC1kZWNvcmF0aW9uOm5vbmU7ICovXG4gIH1cblxuICAuQ09OVEFDVCB7XG4gICAgd2lkdGg6IDk3cHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGZvbnQtc3RyZXRjaDogbm9ybWFsO1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBsaW5lLWhlaWdodDogMS41O1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICB0ZXh0LWRlY29yYXRpb246bm9uZTtcbiAgICBwYWRkaW5nLWxlZnQ6IDI0JTtcbiAgICBjb2xvcjogI2ZjYzEzYztcbiAgfVxuICBcblxuICAuUmVjdGFuZ2xlLTcge1xuICAgIHdpZHRoOiAxOTVweDtcbiAgICBoZWlnaHQ6IDY1cHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2ZjYzEzYztcbiAgICBwYWRkaW5nLXRvcDogMTZweDtcbiAgfVxuICBcblxuICAuUmVjdGFuZ2xlLTkxIHtcbiAgICB3aWR0aDogOTBweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2ZjYzEzYztcbiAgICBjb2xvcjogI2ZjYzEzYztcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gIH1cblxuICAuUmVjdGFuZ2xlLTkxOmhvdmVyIHtcbiAgICB3aWR0aDogOTBweDtcbiAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgLyogYm9yZGVyOiBzb2xpZCAxcHggI2ZjYzEzYzsgKi9cbiAgICBiYWNrZ3JvdW5kOiAjMDAwMDAwO1xuICAgIGNvbG9yOndoaXRlO1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgfVxuXG4gIC5tZW51IHtcbiAgICB3aWR0aDogNTBweDtcbiAgICBoZWlnaHQ6IDI1cHg7XG4gICAgZm9udC1mYW1pbHk6IFBvcHBpbnM7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gICAgZm9udC1zdHJldGNoOiBub3JtYWw7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjExO1xuICAgIGxldHRlci1zcGFjaW5nOiBub3JtYWw7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBwYWRkaW5nLWxlZnQ6IDdweDtcbiAgfVxuXG4gIC5tdXJtdXJsb2dvXG4gIHtcbiAgICB3aWR0aDoyMCU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIEBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjAwcHgpIHtcbiAgICAubXVybXVybG9nb1xuICB7XG4gICAgd2lkdGg6NDAlXG4gIH1cbiAgfVxuICBAbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDM2MHB4KSB7XG4gICAgLm11cm11cmxvZ29cbiAge1xuICAgIHdpZHRoOjQwJVxuICB9XG4gIH0iXX0= */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](NavbarComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-navbar',
            templateUrl: './navbar.component.html',
            styleUrls: ['./navbar.component.css']
          }]
        }], function () {
          return [];
        }, null);
      })();
      /***/

    },

    /***/
    "./src/environments/environment.ts":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "./src/main.ts":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function srcMainTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "./src/app/app.module.ts");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.error(err);
      });
      /***/

    },

    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! /home/mnwuser/Videos/murmurDapp/src/main.ts */
      "./src/main.ts");
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map